<?php
/**
 * Anikoto 24/7 Autonomous Background Worker for DramaStream Theme (CLI / Cron Daemon)
 * 
 * Usage from Terminal or Cron:
 * php auto-sync-worker.php
 * 
 * Recommended Crontab entry (every minute):
 * * * * * php /path-to-your-wordpress/wp-content/themes/dramastream/auto-sync-worker.php > /dev/null 2>&1
 */

// Detect CLI or Web
$isCli = (php_sapi_name() === 'cli' || defined('STDIN'));

// Find and Bootstrap WordPress wp-load.php
$wpLoadPath = null;
$searchDirs = [
    __DIR__ . '/../../../wp-load.php',
    __DIR__ . '/../../../../wp-load.php',
    dirname(dirname(dirname(__DIR__))) . '/wp-load.php',
    dirname(dirname(dirname(dirname(__DIR__)))) . '/wp-load.php',
];

foreach ($searchDirs as $dir) {
    if (file_exists($dir)) {
        $wpLoadPath = $dir;
        break;
    }
}

if (!$wpLoadPath) {
    if ($isCli) {
        fwrite(STDERR, "[ERROR] No se pudo encontrar wp-load.php. Asegurate de que la plantilla este instalada en wp-content/themes/dramastream/.\n");
    } else {
        header('HTTP/1.1 500 Internal Server Error');
        echo "Error: wp-load.php not found.";
    }
    exit(1);
}

// Bootstrap WP Environment without loading theme templates
define('WP_USE_THEMES', false);
require_once $wpLoadPath;

// Verify DramaStream_Auto_Sync class is available
if (!class_exists('DramaStream_Auto_Sync')) {
    $autoSyncFile = __DIR__ . '/inc/auto-sync.php';
    if (file_exists($autoSyncFile)) {
        require_once $autoSyncFile;
    } else {
        if ($isCli) fwrite(STDERR, "[ERROR] auto-sync.php no encontrado.\n");
        exit(1);
    }
}

// Check if Auto-Sync is enabled in WordPress settings
$enabled = get_option('dramastream_auto_enabled', get_option('animestream_auto_enabled', '1'));
if ($enabled !== '1') {
    if ($isCli) echo "[INFO] Auto-Publicador pausado en la configuracion de WordPress.\n";
    exit(0);
}

$interval = max(1, (int) get_option('dramastream_auto_interval', get_option('animestream_auto_interval', 1)));
$startTime = time();
$maxExecutionSeconds = 55; // Runs for 55s per cron trigger to avoid overlapping runs

if ($isCli) {
    echo "========================================================\n";
    echo "âš¡ Anikoto Background Worker DramaStream Iniciado (Intervalo: {$interval}s)\n";
    echo "========================================================\n";
}

while ((time() - $startTime) < $maxExecutionSeconds) {
    $res = DramaStream_Auto_Sync::run_sync_check(false);
    
    if ($isCli) {
        $ts = current_time('H:i:s');
        $status = $res['status'] ?? 'unknown';
        $msg = $res['message'] ?? '';
        echo "[{$ts}] [{$status}] {$msg}\n";

        if (!empty($res['published'])) {
            foreach ($res['published'] as $item) {
                echo "  -> PUBLICADO: " . ($item['title'] ?? '') . " [ID: " . ($item['post_id'] ?? '') . "]\n";
            }
        }
    }

    sleep($interval);
}

if ($isCli) {
    echo "Ciclo de 55s completado. Esperando proxima ejecucion de Cron...\n";
}
exit(0);