<?php 
/*
Template Name: Schedule
*/

defined('ABSPATH') || die("!"); 

get_header();

$page_cache = "schedule_page";
GOV_cache::fragment_cache($page_cache, 3600 * 24, function(){
	
try{

	$timezone = wp_timezone_string();
	if (strpos($timezone, "/") !== FALSE){
		date_default_timezone_set($timezone);
	}else if (preg_match('/^[+-]\d{2}:\d{2}$/', $timezone)) {
		[$hours, $minutes] = explode(':', substr($timezone, 1));
		$sign = $timezone[0] === '+' ? '-' : '+'; 
		$timezone = 'Etc/GMT' . $sign . (int)$hours;
		date_default_timezone_set($timezone);
	}
}catch(Exception $e){

}

$hide_completed_anime = apply_filters('gov-schedule>>auto-hide-completed-anime', (bool) get_option('ts_schedule_auto_hide_completed', TRUE));



$sc = new GOV_schedule;
$sc->basic()->use_child_timestamp(TRUE);
$sc->basic()->get_ongoing_anime();
$keys = $sc->helper()->get_day_names();


?>
<div class="postbody"><div class="bixbox">
<div class="releases"><h1><span><?php echo get_the_title(); ?></span></h1></div>
<div class="listupd" style="line-height: 22px;"><?php echo GOV_lang::get('schedule_head');?><br/>
</div></div>

	<?php 
    foreach($keys as $kk => $vk) { 
        $day = $vk;
		$v = $sc->group()->get($day);
		if (sizeof($v) < 1) continue;
        ?>
		<div class="clear"></div>
		<div class="bixbox schedulepage sch_<?php echo $day; ?>">
			<div class="releases"><h3><span><?php echo $sc->helper()->sch_translate($day); ?></span></h3></div>
		<div class="listupd">
		<?php 
        $items = 0;
        foreach($v as $n => $m) { 
            $m = $sc->group()->get_object($m, FALSE);
            if ($hide_completed_anime && $m->is_complete() && $m->is_already_posted() == FALSE) continue;
            if ($m->is_late($day) && $m->get_mode() == "interval" && $m->get_times_called() > 1) continue;
            $items++;
        ?>
			<div class="bs">
				<div class="bsx">
					<a href="<?php echo get_the_permalink($m->the_post());?>" title="<?php echo get_the_title($m->the_post());?>">
					<div class="limit">
						<div class="ply"><i class="far fa-play-circle" aria-hidden="true"></i></div>
						<div class="bt">
                            <?php echo $m->get_countdown_text($day); ?>
							<?php if ($m->is_already_posted()) { ?>
								<span class="sb Sub"><?php echo $m->get_current_episode();?></span>
							<?php } elseif ($m->get_countdown($day) <= 0) { ?>
								<span class="sb Sub"><?php echo $m->get_next_episode() ?: GOV_lang::get('schedule_uncountable_next_episode'); ?></span>
							<?php } else { ?>
								<span class="sb Sub"><?php echo $m->get_next_episode() ?: GOV_lang::get('schedule_uncountable_next_episode'); ?></span>
							<?php } ?>

						</div>
						<img width="225" height="321" src="<?php echo $m->get_image();?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="<?php echo get_the_title($m->the_post());?>">		</div>
						<div class="tttx"><div class="tt"><?php echo get_the_title($m->the_post());?></div></div>
					</a>
				</div>
			</div>
		<?php } ?>
        <?php if ($items < 1){ ?> 
           <script>
			$('.sch_<?php echo $day; ?>').hide();
			</script>
        <?php } ?>
		</div>
	</div>
	<?php } ?>
</div>
<script>
var format = "<?php echo GOV_lang::get('schedule_countdown_format');?>";
function convert_dhms(s){
	var seconds = parseInt(s, 10);
	var days = Math.floor(seconds / (3600*24));
	seconds  -= days*3600*24;
	var hrs   = Math.floor(seconds / 3600);
	seconds  -= hrs*3600;
	var mnts = Math.floor(seconds / 60);
	seconds  -= mnts*60;
	var res = format;
	if (days) res = res.replace("{{days}}", days);
	else res = res.replace("{{days}}", "0");
	if (hrs) res = res.replace("{{hours}}", hrs);
	else res = res.replace("{{hours}}", "0");
	if (mnts) res = res.replace("{{minutes}}", mnts);
	else res = res.replace("{{minutes}}", "0");
	return res;
}
function update_ts(){
	$('.cndwn').each(function(k,v){
		try{
			var thcd = this.getAttribute('data-cndwn');
			if (isNaN(thcd)) return true;
			var rlsdt = parseInt(this.getAttribute('data-rlsdt'));
            if ( ! rlsdt) return true;
			var s = rlsdt - new Date().getTime() / 1000;
			if (s < 0) return true;
			this.innerHTML = convert_dhms(s);
		}catch(e){
			console.error(e);
		}
	});
}
update_ts();
setInterval(function(){update_ts();}, 60 * 1000);
</script>
<?php }); //GOV_cache?>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
