<?php 
/*
Template Name: Bookmark
*/
defined("ABSPATH") || die("!"); 
$loading_class = GOV_bookmark::is_enabled() ? " ts-loading" : "";
?>
<?php get_header(); ?>
<div class="postbody">
    <div class="bixbox">

        <div class="releases"><h1><span><?php echo get_the_title();?></span></h1> <span class="hapus" id="hapus"><?php echo GOV_lang::get('delete'); ?></span></div>
        <p class="ntf">
            <?php echo GOV_lang::get('bookmark_head', ["max" => get_option('bookmark')]); ?>
        </p>
		
        <?php if (get_option('bookmark_allow_import_export', TRUE)){ ?>

            <!-- import export bookmark -->

            <div id="ts-import-export-bookmark">
                <div id="imex-bm-notices" style="display:none"><!-- import and export log goes here --></div>
                <button id="export-bookmark" class="btn btn-primary"><?php echo GOV_lang::get('bookmark_export_label'); ?></button>
                <button id="import-bookmark" class="btn btn-primary"><?php echo GOV_lang::get('bookmark_import_label'); ?></button>
                <!-- file input to import the bookmark -->
                <div id="bookmark-import-upload" style="display:none">
                    <input type="file" id="ts-bookmark-import-file" accept=".json" />
                </div>
            </div>

            <!-- end import export bookmark -->

        <?php } ?>
		
        <div class="listupd<?php echo $loading_class; ?>" id="bookmark-pool">
		<?php if ( ! GOV_bookmark::is_enabled()) { ?>
			<h4><center><?php echo GOV_lang::get('bookmark_disabled_notice');?></center></h4>
		<?php } else{ ?>
            <div class="ts-loading-spinner"></div>
        <?php } ?>
		</div>

        <div id="ts-bookmark-pagination"><!-- pagination area --></div>

    </div>
</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>