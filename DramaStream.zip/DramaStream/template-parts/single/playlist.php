<?php
defined("ABSPATH") || die("!");
$date_format = get_option('date_format', 'F j, Y');

// 1. Get the current singular Episode ID safely
$current_ep_id = get_queried_object_id();
if (!$current_ep_id) {
    $current_ep_id = get_the_ID();
}

// 2. Resolve the Target Series ID for this Episode
$target_series_id = (int) get_post_meta($current_ep_id, 'ero_seri', true);
if (!$target_series_id) {
    $target_series_id = (int) get_post_meta($current_ep_id, '_anikoto_series_id', true);
}
if (!$target_series_id && !empty($series_link)) {
    $target_series_id = url_to_postid($series_link);
}
if (!$target_series_id && !empty($series_title)) {
    $s_post = get_page_by_title($series_title, OBJECT, 'series');
    if ($s_post) {
        $target_series_id = (int) $s_post->ID;
    }
}

// 3. Fallback: If current post is itself a series
if (!$target_series_id && get_post_type($current_ep_id) === 'series') {
    $target_series_id = $current_ep_id;
}

// 4. Query all episodes that strictly belong to this Series
$matched_episodes = [];
if ($target_series_id) {
    // A) Meta query by series relation
    $ep_q = new WP_Query([
        'post_type'              => 'post',
        'post_status'            => 'publish',
        'posts_per_page'         => 1000,
        'meta_query'             => [
            'relation' => 'OR',
            [
                'key'     => 'ero_seri',
                'value'   => $target_series_id,
                'compare' => '='
            ],
            [
                'key'     => '_anikoto_series_id',
                'value'   => $target_series_id,
                'compare' => '='
            ],
        ],
        'no_found_rows'          => true,
        'update_post_term_cache' => false,
    ]);

    // B) Category Fallback if meta query returned nothing
    if (empty($ep_q->posts)) {
        $cats = wp_get_post_categories($target_series_id);
        if (!empty($cats)) {
            $ep_q = new WP_Query([
                'post_type'              => 'post',
                'post_status'            => 'publish',
                'category__in'           => $cats,
                'posts_per_page'         => 1000,
                'no_found_rows'          => true,
                'update_post_term_cache' => false,
            ]);
        }
    }

    if (!empty($ep_q->posts)) {
        $raw_episodes = $ep_q->posts;

        // Sort episodes by Episode Number DESC (Latest on top)
        $playlist_order = strtoupper(get_option('ts_playlist_order', 'DESC'));
        usort($raw_episodes, function($a, $b) use ($playlist_order) {
            $numA = function_exists('dramastream_episode_number_value') ? dramastream_episode_number_value($a->ID) : (float)get_post_meta($a->ID, 'ero_episodebaru', true);
            $numB = function_exists('dramastream_episode_number_value') ? dramastream_episode_number_value($b->ID) : (float)get_post_meta($b->ID, 'ero_episodebaru', true);
            if ($numA === null) $numA = (float)$a->ID;
            if ($numB === null) $numB = (float)$b->ID;
            if ($playlist_order === 'ASC') {
                return ($numA < $numB) ? -1 : 1;
            }
            return ($numA > $numB) ? -1 : 1;
        });

        foreach ($raw_episodes as $p) {
            $ep_id = (int)$p->ID;
            $num = function_exists('dramastream_episode_number_value') ? dramastream_episode_number_value($ep_id) : get_post_meta($ep_id, 'ero_episodebaru', true);
            $ep_meta_title = get_post_meta($ep_id, 'ero_episodetitle', true);

            $has_thumb = has_post_thumbnail($ep_id);
            if ($has_thumb) {
                $ep_img = get_the_post_thumbnail($ep_id, 'medium');
            } elseif (has_post_thumbnail($target_series_id)) {
                $ep_img = get_the_post_thumbnail($target_series_id, 'medium');
            } else {
                $ep_img = !empty($series_image) ? $series_image : '';
            }

            $matched_episodes[] = [
                'id'              => $ep_id,
                'link'            => get_permalink($ep_id),
                'post_title'      => get_the_title($ep_id),
                'has_thumbnail'   => $has_thumb,
                'episode_image'   => $ep_img,
                'series_ep_image' => !empty($series_image) ? $series_image : $ep_img,
                'number'          => $num,
                'title'           => $ep_meta_title,
            ];
        }

        $episodes = $matched_episodes;
        $total_episodes = count($matched_episodes);
    }
}

// 5. Strict Security Filter: Purge any alien episodes that do not belong to the target series
if (!empty($episodes) && is_array($episodes)) {
    $strictly_filtered = [];
    foreach ($episodes as $item) {
        $item_id = (int)($item['id'] ?? 0);
        if (!$item_id) continue;

        if ($target_series_id) {
            $ep_seri = (int) get_post_meta($item_id, 'ero_seri', true);
            if (!$ep_seri) $ep_seri = (int) get_post_meta($item_id, '_anikoto_series_id', true);

            if ($ep_seri === $target_series_id || $item_id === $current_ep_id) {
                $strictly_filtered[] = $item;
            }
        } else {
            $strictly_filtered[] = $item;
        }
    }
    if (!empty($strictly_filtered)) {
        $episodes = $strictly_filtered;
    }
}

// Ensure total count reflects actual series episodes
if (empty($total_episodes)) {
    $total_episodes = !empty($episodes) ? count($episodes) : 1;
}

// Resolve Series Header Info
if (empty($series_link) && $target_series_id) {
    $series_link = get_permalink($target_series_id);
}
if (empty($series_title) && $target_series_id) {
    $series_title = get_the_title($target_series_id);
}
if (empty($series_image) && $target_series_id && has_post_thumbnail($target_series_id)) {
    $series_image = get_the_post_thumbnail($target_series_id, 'medium');
}
if (empty($status) && $target_series_id) {
    $status = rwmb_the_value('ero_status', '', $target_series_id, false) ?: get_post_meta($target_series_id, 'ero_status', true);
    if (!$status) $status = 'Ongoing';
}
if (empty($current_episode)) {
    $current_episode = function_exists('dramastream_episode_number_value') ? dramastream_episode_number_value($current_ep_id) : get_post_meta($current_ep_id, 'ero_episodebaru', true);
}
?>

<div id="singlepisode">
    <div class="headlist">
        <div class="thumb">
            <a href="<?php echo esc_url($series_link); ?>"><?php echo $series_image; ?></a>
        </div>
        <div class="det">
            <h2><a href="<?php echo esc_url($series_link); ?>"><?php echo esc_html($series_title); ?></a></h2>
            <span><i><?php echo esc_html($status); ?></i><?php if($current_episode){ echo ' - <em class="epnow">' . esc_html($current_episode) . '</em> / ' . esc_html($total_episodes); } ?></span>
        </div>
    </div>
    <div class="episodelist">
        <ul>
            <?php
            if (!empty($episodes)) {
                foreach($episodes as $k => $v) { 
                    $is_current = ((int)$v['id'] === (int)$current_ep_id);
                    ?>
                    <li data-id="<?php echo esc_attr($v['id']); ?>"<?php if ($is_current) echo ' class="selected"'; ?>>
                        <a href="<?php echo esc_url($v['link']); ?>" itemprop="url" title="<?php echo esc_attr($v['post_title']); ?>">
                            <div class="thumbnel">
                                <?php if ( $v['id'] && !empty($v['has_thumbnail'])) { 
                                        echo $v['episode_image'];										
                                    } elseif (!empty($v['series_ep_image'])) { 
                                        echo $v['series_ep_image'];	
                                    } elseif (!empty($v['episode_image'])) {
                                        echo $v['episode_image'];
                                    }
                                ?>
                                <?php if ($is_current) { ?>
                                    <span class="nowplay"><i class="far fa-play-circle"></i></span>
                                <?php } ?>
                            </div>
                            <div class="playinfo">
                                <h3><?php echo esc_html($v['post_title']); ?></h3>
                                <span><?php echo GOV_lang::get('playlist_eps_label');?> <?php echo esc_html($v['number']); if(!empty($v['title'])){ echo ' - ' . esc_html($v['title']); } ?> - <?php echo esc_html(get_the_date($date_format, $v['id'])); ?></span>
                            </div>
                        </a>
                    </li>
                <?php }
            } ?>
        </ul>
    </div>
</div>