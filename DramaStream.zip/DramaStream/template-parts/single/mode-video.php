<?php $seri = get_post_meta(get_the_ID(), 'ero_seri', true);
$sub = get_post_meta(get_the_ID(),'ero_subepisode',true);
if($sub=='' || $sub=='None'){
	$sub = get_post_meta($seri,'ero_sub',true);
	$subln = rwmb_the_value('ero_sub',[],$seri,false);
} else {
	$subln = rwmb_the_value('ero_subepisode',[],get_the_ID(),false);
	if($subln==''){ $sub = 'Sub'; $subln = 'Sub'; }
}
$author_id = get_post_field( 'post_author', get_the_ID() );
?>
<div class="megavid">
<div class="mvelement">
<div class="item meta">
					<div class="tb" itemprop="image" itemscope itemtype="https://schema.org/ImageObject">
					<?php echo GOV_anime::get_post_thumbnail((int)$seri, "medium", 350, 246); ?>
					<meta itemprop="url" content="<?php echo get_the_post_thumbnail_url($seri); ?>">
					<meta itemprop="width" content="190">
					<meta itemprop="height" content="260">
					</div>
					<div class="lm">
						<h1 class="entry-title" itemprop="headline"><?php the_title(); ?></h1>
						<span class="epx"> <?php echo get_post_meta($seri,'ero_type',true); ?> <span class="lg"><?php echo $sub; ?></span></span>
						
					<span class="year">
							<?php if(get_option('epssub')=='1'){ ?><i class="status <?php echo $sub; ?>"><?php echo $subln; ?></i><?php } ?>
							<?php if (get_option('tsepdate', 1)) { ?><?php echo GOV_lang::get('episode_page_uploaded_at_label');?> <span class="updated"><time itemprop="datePublished" datetime="<?php the_time('c'); ?>"><?php the_date(); ?></time></span> · <?php } ?>
							<?php if (get_option('ts_view_count', 1)) { ?> <span id="ts-ep-view">? views</span> · <?php } ?>
							<?php if (get_option('tsepauthor', 1)) { ?><?php echo GOV_lang::get('episode_page_posted_by_label'); ?> <span class="vcard author entry-author" itemprop="author" itemscope itemtype="https://schema.org/Person"><b class="fn"><span class="entry-author-name" itemprop="name"><?php echo get_the_author_meta('display_name', $author_id); ?></span></b></span> · <?php } ?><?php if (get_option('tsepserieslink', 1)) { ?><?php echo GOV_lang::get('episode_page_series_label'); ?> <a href="<?php echo esc_url(dramastream_get_series_url_from_episode(get_the_ID())); ?>"><?php echo get_the_title($seri); ?></a><?php } ?>
						</span>
					</div>
				<?php if(get_option('singlesocial')=='1'){ ?>
				<div class="sosmed">
					<a href="https://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>" target="_blank" aria-label="Share on Facebook"><span class="fab fa-facebook-f" aria-hidden="true"></span></a>
					<a href="https://twitter.com/share?url=<?php the_permalink(); ?>" target="_blank" aria-label="Share on Twitter"><span class="fab fa-twitter" aria-hidden="true"></span></a>
					<a href="whatsapp://send?text=<?php the_title(); ?> <?php the_permalink(); ?>" target="_blank" aria-label="Share on Whatsapp"><span class="fab fa-whatsapp" aria-hidden="true"></span></a>
					<a href="https://t.me/share/url?url=<?php the_permalink(); ?>&text=<?php the_title(); ?>" target="_blank" class="tlg" aria-label="Share on Telegram"><span class="fab fa-telegram-plane" aria-hidden="true"></span></a>
				</div>
				<?php } ?>
</div>
<?php $kln = get_option('reader1'); if($kln) { ?><div class="kln"><?php echo $kln; ?></div><br/><?php } ?>
<?php $ann = get_option('anntopplayer'); if($ann) { ?><div class="announ"><?php echo $ann; ?></div><?php } ?>
<?php
    $ak_is_advanced = function_exists('dramastream_is_advanced_episode') && dramastream_is_advanced_episode(get_the_ID());
    // Prefer imported Anikoto player URLs when present.
    $ak_servers = get_post_meta(get_the_ID(), '_anikoto_servers', true);
    if (is_string($ak_servers)) $ak_servers = json_decode($ak_servers, true);
    if (!is_array($ak_servers) || !$ak_servers) $ak_servers = get_post_meta(get_the_ID(), 'ab_embedgroup', true);
    if (!is_array($ak_servers) || !$ak_servers) {
        $ak_servers = [];
        $ak_embeds = get_post_meta(get_the_ID(), 'ero_embed', true);
        if (!is_array($ak_embeds)) $ak_embeds = $ak_embeds ? [$ak_embeds] : [];
        foreach ($ak_embeds as $i => $ak_url) $ak_servers[] = ['name'=>'Server '.($i+1), 'type'=>'SUB', 'url'=>$ak_url];
    }
    $ak_players = [];
    foreach ((array)$ak_servers as $ak_server) {
        $ak_name = sanitize_text_field((string)($ak_server['name'] ?? $ak_server['ab_hostname'] ?? $ak_server['type'] ?? 'Server'));
        $ak_type = strtoupper(sanitize_text_field((string)($ak_server['type'] ?? $ak_server['name'] ?? '')));
        $ak_url  = trim((string)($ak_server['url'] ?? $ak_server['ab_embed'] ?? ''));
        if (!$ak_url) continue;
        if (preg_match("~<iframe[^>]+src=[\"\']([^\"\']+)[\"\']~i", $ak_url, $m)) $ak_url=$m[1];
        if (!preg_match('~^https?://~i', $ak_url)) continue;
        $ak_players[]=['name'=>$ak_name ?: 'Server','type'=>($ak_type==='DUB'?'DUB':'SUB'),'url'=>esc_url($ak_url)];
    }
    $ak_players=array_values(array_filter($ak_players,function($p){return !empty($p['url']);}));
    $mirrorx = playable_mirror(get_the_ID());
    if($mirrorx || $ak_players || $ak_is_advanced){ ?>
	
				<div class="video-content">
					<?php $kln = get_option('overplay');if($kln){ $overplayx = generateRandomCssID('overplayx'); $chainx = generateRandomCssID('chainx'); ?>
					<div id="<?php echo $overplayx; ?>" style="position:absolute;z-index:200;width:100%;height:100%;background:rgba(0,0,0,0.7);">
						<div class="<?php echo $chainx; ?>" align="center" style="width:100%;max-width:100%;margin:auto;padding-top:50px;"><span onclick="document.getElementById('<?php echo $overplayx; ?>').style.display = 'none';" style="cursor:pointer;display:block;"><img src="<?php echo get_template_directory_uri().'/assets/images/btn_close.gif'; ?>"/></span>
						<?php echo $kln; ?>
						</div>
					</div>
					<style data-noptimize="1">@media only screen and (max-width:500px) {.<?php echo $chainx; ?>{max-width:50% !important;padding-top:25px !important;}}</style>
					<?php } ?>

					<?php
                    if ($ak_is_advanced) { ?>
                        <div class="ak-direct-player ak-advanced-placeholder" aria-label="Episode not arrived yet">
                            <div class="ak-advanced-glow ak-glow-one"></div>
                            <div class="ak-advanced-glow ak-glow-two"></div>
                            <div class="ak-advanced-ring"></div>
                            <div class="ak-advanced-placeholder-inner">
                                <div class="ak-advanced-play" aria-hidden="true"><span></span></div>
                                <div class="ak-advanced-copy">
                                    <div class="ak-advanced-ep">EPISODE <?php echo esc_html(dramastream_format_episode_number(dramastream_episode_number_value(get_the_ID()))); ?></div>
                                    <div class="ak-advanced-title">NOT ARRIVED YET!</div>
                                    <div class="ak-advanced-dots" aria-hidden="true"><i></i><i></i><i></i></div>
                                </div>
                            </div>
                        </div>
                    <?php } elseif ($ak_players) {
                        $ak_player_id='ak-player-'.get_the_ID();
                        ?>
                        <div class="ak-direct-player">
                            <iframe id="<?php echo esc_attr($ak_player_id); ?>"
                                src="<?php echo esc_url($ak_players[0]['url']); ?>"
                                width="100%" height="100%" frameborder="0" scrolling="no"
                                allow="autoplay; encrypted-media; fullscreen; picture-in-picture"
                                allowfullscreen loading="lazy"
                                referrerpolicy="origin-when-cross-origin"
                                style="display:block;width:100%;height:100%;border:0;"></iframe>
                        </div>
                    <?php } else { ?>
                        <?php videocontent(); ?>
                    <?php } ?>
				</div>
				<div class="item video-nav">
					<div class="mobius">
					<?php
						videomirror(get_the_ID());
					?>

                    <div class="iconx">
						<div class="icol expand"><i class="fa fa-expand" aria-hidden="true"></i> <span><?php echo GOV_lang::get('episode_page_expand_player'); ?></span></div>
						<div class="icol light"><i class="far fa-lightbulb"></i> <span><?php echo GOV_lang::get('episode_page_turn_off_light'); ?></span></div>
						<?php $dl = get_chdl(get_the_ID()); if($dl){ ?>
						<a href="<?php echo $dl; ?>" target="_blank" rel="nofollow"><div class="icol"><i class="fas fa-cloud-download-alt"></i> <span><?php echo GOV_lang::get('episode_page_download_button'); ?></span></div></a>
						<?php } ?>
					</div>
					</div>
				</div>
	
<?php $warning = get_post_meta($seri,'ero_mature',true); if($warning=='Yes'){ ?>
	<div class="warning">
		<?php echo GOV_lang::get('series_warning');?>
	</div>
	<?php } ?>
<?php $ann = get_option('annbotplayer'); if($ann) { ?><div class="announ"><?php echo $ann; ?></div><?php } ?>
<?php if (get_post_meta(get_the_ID(), 'ero_multipart', true) === "yes") : ?>
	<div class="bixbox infx">
		<?php echo videomirror_multipart(get_the_ID()); ?>
	</div>
	<?php endif; ?>
<div class="naveps bignav">
						<div class="nvs"><?php if (is_object(get_previous_post(TRUE)) && strlen(get_previous_post(TRUE)->post_title) > 0) { previous_post_link('%link', '<i class="fas fa-angle-left"></i> <span class="tex">'.GOV_lang::get('episode_page_nav_prev_label').'</span>', TRUE); } else { echo '<span class="nolink"><i class="fas fa-angle-left"></i> <span class="tex">'.GOV_lang::get('episode_page_nav_prev_label').'</span></span>'; } ?></div>
	<div class="nvs nvsc"><a href='<?php echo esc_url(dramastream_get_series_url_from_episode(get_the_ID())); ?>' aria-label='<?php echo GOV_lang::get('episode_page_nav_all_episodes_label'); ?>'><i class="fas fa-th-list"></i> <span class="tex"><?php echo GOV_lang::get('episode_page_nav_all_episodes_label'); ?></span></a></div>
						<div class="nvs"><?php if (is_object(get_next_post(TRUE)) && strlen(get_next_post(TRUE)->post_title) > 0) { next_post_link('%link','<span class="tex">'. GOV_lang::get('episode_page_nav_next_label').'</span> <i class="fas fa-angle-right"></i>', TRUE); } else { echo '<span class="nolink"><span class="tex">'.GOV_lang::get('episode_page_nav_next_label').'</span> <i class="fas fa-angle-right"></i> </span>'; } ?></div>
</div>
<?php } ?>	
<?php $kln = get_option('reader2'); if($kln) { ?><div class="kln"><?php echo $kln; ?></div><br/><?php } ?>	
	</div>
</div>
	<div id="mobilepisode"></div>
	<div class="entry-content" itemprop="text">
	<div class="bixbox infx">
		<p><?php echo GOV_lang::get('episode_page_below_player_keywords', ["anime_title" => get_the_title($seri), "episode_title" => get_the_title(), "blogname" => esc_attr( get_bloginfo( 'name', 'display' ) )]); ?> </p>
	</div>
	<?php if (have_posts()) : while (have_posts()) : the_post(); if( '' !== get_post()->post_content ) { ?>
		<div class="bixbox mctn">
			<?php the_content(); ?>
		</div>
	<?php } endwhile; endif; ?>
	
	<?php single_download_links(get_the_ID()); ?>
	<?php single_download_links_ep(get_the_ID()); ?>
		
	<?php if(get_option('tsthemelayout')=='tsnosidebar'){ ts_playlist('DESC','F j, Y'); } ?>
	</div>
<?php if (!defined('AK_DRAMA_PLAYER_ASSETS')) : define('AK_DRAMA_PLAYER_ASSETS', true); ?>
<style>
.video-content{position:relative;width:100%;height:auto;aspect-ratio:16/9;min-height:0;background:#000;overflow:hidden}
.ak-direct-player{position:absolute;inset:0;width:100%;height:100%;overflow:hidden;background:#000}
.ak-direct-player iframe{display:block;width:100% !important;height:100% !important;min-width:100%;min-height:100%;border:0;background:#000}
.ak-advanced-placeholder{display:flex;align-items:center;justify-content:center;min-height:0;background:#05040a;overflow:hidden;isolation:isolate}
.ak-advanced-placeholder:before{content:"";position:absolute;inset:0;background:radial-gradient(circle at 50% 50%,rgba(130,55,255,.16) 0,rgba(36,12,66,.08) 28%,rgba(0,0,0,0) 62%);z-index:-1}
.ak-advanced-placeholder:after{content:"";position:absolute;width:52%;height:78%;border:1px solid rgba(148,72,255,.12);border-radius:50%;box-shadow:0 0 80px rgba(112,35,255,.08),inset 0 0 80px rgba(112,35,255,.05);animation:ak-advanced-pulse 3.5s ease-in-out infinite;z-index:-1}
.ak-advanced-placeholder-inner{position:relative;display:flex;align-items:center;gap:28px;width:min(780px,86%);z-index:2}
.ak-advanced-play{position:relative;flex:0 0 clamp(82px,11vw,126px);width:clamp(82px,11vw,126px);height:clamp(82px,11vw,126px);border:1px solid rgba(171,91,255,.75);border-radius:50%;background:rgba(104,35,180,.15);box-shadow:0 0 0 9px rgba(130,50,235,.08),0 0 28px rgba(142,57,255,.55),inset 0 0 25px rgba(142,57,255,.18);animation:ak-advanced-breathe 2.4s ease-in-out infinite}
.ak-advanced-play:before{content:"";position:absolute;inset:10px;border:1px solid rgba(187,119,255,.35);border-radius:50%}
.ak-advanced-play span{position:absolute;left:50%;top:50%;transform:translate(-42%,-50%);width:0;height:0;border-top:13px solid transparent;border-bottom:13px solid transparent;border-left:20px solid #fff;filter:drop-shadow(0 0 8px rgba(173,88,255,.8))}
.ak-advanced-copy{min-width:0}
.ak-advanced-ep{margin-bottom:6px;font-size:clamp(10px,1.1vw,14px);font-weight:800;letter-spacing:4px;color:#a657ff;text-transform:uppercase}
.ak-advanced-title{font-size:clamp(25px,4vw,52px);line-height:1.05;font-weight:900;letter-spacing:1px;color:#fff;text-shadow:0 0 22px rgba(167,79,255,.25);white-space:nowrap}
.ak-advanced-dots{display:flex;gap:6px;margin-top:12px}
.ak-advanced-dots i{display:block;width:5px;height:5px;border-radius:50%;background:#a04cff;box-shadow:0 0 8px rgba(160,76,255,.8);animation:ak-advanced-dot 1.4s ease-in-out infinite}
.ak-advanced-dots i:nth-child(2){animation-delay:.18s}.ak-advanced-dots i:nth-child(3){animation-delay:.36s}
.ak-advanced-glow{position:absolute;border-radius:50%;filter:blur(42px);pointer-events:none;z-index:-1}
.ak-glow-one{width:30%;height:55%;left:28%;top:22%;background:rgba(107,31,210,.13);animation:ak-advanced-float 5s ease-in-out infinite}
.ak-glow-two{width:22%;height:45%;right:22%;bottom:18%;background:rgba(164,57,255,.09);animation:ak-advanced-float 6s ease-in-out infinite reverse}
@keyframes ak-advanced-pulse{0%,100%{transform:scale(.96);opacity:.55}50%{transform:scale(1.04);opacity:1}}
@keyframes ak-advanced-breathe{0%,100%{transform:scale(.98);box-shadow:0 0 0 9px rgba(130,50,235,.08),0 0 28px rgba(142,57,255,.45),inset 0 0 25px rgba(142,57,255,.18)}50%{transform:scale(1.03);box-shadow:0 0 0 14px rgba(130,50,235,.05),0 0 42px rgba(142,57,255,.7),inset 0 0 32px rgba(142,57,255,.25)}}
@keyframes ak-advanced-dot{0%,80%,100%{opacity:.25;transform:translateY(0)}40%{opacity:1;transform:translateY(-3px)}}
@keyframes ak-advanced-float{0%,100%{transform:translate3d(0,0,0)}50%{transform:translate3d(14px,-10px,0)}}
@media(max-width:600px){.ak-advanced-placeholder-inner{gap:17px;width:88%}.ak-advanced-title{white-space:normal;font-size:clamp(23px,7vw,36px)}.ak-advanced-ep{letter-spacing:2.5px}.ak-advanced-play{flex-basis:72px;width:72px;height:72px}.ak-advanced-play span{border-top-width:9px;border-bottom-width:9px;border-left-width:14px}}
.ak-server-buttons{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:0 0 10px}
.ak-server-btn{border:0;border-radius:3px;background:#333;color:#bbb;padding:8px 13px;cursor:pointer;font-size:12px;font-weight:600}
.ak-server-btn:hover,.ak-server-btn.active{background:#6f35c7;color:#fff}
</style>
<script>
document.addEventListener('click',function(e){
    var b=e.target.closest ? e.target.closest('.ak-server-btn') : null;
    if(!b) return;
    var id=b.getAttribute('data-player'), src=b.getAttribute('data-src'), f=document.getElementById(id);
    if(!f || !src) return;
    f.src=src;
    var wrap=b.parentElement;
    if(wrap) wrap.querySelectorAll('.ak-server-btn').forEach(function(x){x.classList.remove('active');});
    b.classList.add('active');
});
</script>
<?php endif; ?>
