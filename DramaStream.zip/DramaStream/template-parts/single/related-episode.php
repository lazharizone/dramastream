<?php
if(get_option('relatedepisode')=='1'){
    $current_id = get_the_ID();
    $seri = (int)get_post_meta($current_id, 'ero_seri', true);
    $current_num = function_exists('dramastream_episode_number_value') ? dramastream_episode_number_value($current_id) : (float)get_post_meta($current_id, 'ero_episodebaru', true);
    $previous = 0;
    $next = 0;

    if($seri && $current_num !== null){
        $base = [
            'post_type'=>'post', 'post_status'=>'publish', 'posts_per_page'=>1, 'fields'=>'ids',
            'meta_query'=>[
                ['key'=>'ero_seri','value'=>$seri,'compare'=>'='],
                ['key'=>'_dramastream_advanced_episode','compare'=>'NOT EXISTS'],
            ],
        ];
        $q = new WP_Query(array_merge($base, [
            'meta_query'=>array_merge($base['meta_query'], [['key'=>'ero_episodebaru','value'=>$current_num,'compare'=>'<']]),
            'orderby'=>'meta_value_num','meta_key'=>'ero_episodebaru','order'=>'DESC'
        ]));
        if(!empty($q->posts)) $previous=(int)$q->posts[0];
        wp_reset_postdata();

        $q = new WP_Query(array_merge($base, [
            'meta_query'=>array_merge($base['meta_query'], [['key'=>'ero_episodebaru','value'=>$current_num,'compare'=>'>']]),
            'orderby'=>'meta_value_num','meta_key'=>'ero_episodebaru','order'=>'ASC'
        ]));
        if(!empty($q->posts)) $next=(int)$q->posts[0];
        wp_reset_postdata();
    }

    if ($next||$previous){
        echo '<div class="bixbox"><div class="releases"><h3>'.GOV_lang::get('related_episodes').'</h3></div><div class="listupd">';
        if($previous){ ?>
            <div class="stylefiv"><div class="bsx"><div class="thumb">
                <a href="<?php echo esc_url(get_permalink($previous)); ?>" title="<?php echo esc_attr(get_the_title($previous)); ?>">
                    <?php if (has_post_thumbnail($previous)) echo get_the_post_thumbnail($previous); else echo get_the_post_thumbnail($seri); ?>
                </a></div><div class="inf">
                <h2><a href="<?php echo esc_url(get_permalink($previous)); ?>" title="<?php echo esc_attr(get_the_title($previous)); ?>"><?php echo esc_html(get_the_title($previous)); ?></a></h2>
                <span><i class="far fa-user"></i> <?php echo GOV_lang::get('episode_page_posted_by_label'); ?>: <?php $author_id=get_post_field('post_author',$previous); echo esc_html(get_the_author_meta('display_name',$author_id)); ?></span>
                <span><i class="far fa-calendar-alt"></i> <?php echo GOV_lang::get('series_info_posted_on_label');?>: <?php echo esc_html(human_time_diff(get_the_time('U',$previous),current_time('timestamp')).GOV_lang::get('home_timeago_label')); ?></span>
            </div></div></div>
        <?php }
        if($next){ ?>
            <div class="stylefiv"><div class="bsx"><div class="thumb">
                <a href="<?php echo esc_url(get_permalink($next)); ?>" title="<?php echo esc_attr(get_the_title($next)); ?>">
                    <?php if (has_post_thumbnail($next)) echo get_the_post_thumbnail($next); else echo get_the_post_thumbnail($seri); ?>
                </a></div><div class="inf">
                <h2><a href="<?php echo esc_url(get_permalink($next)); ?>" title="<?php echo esc_attr(get_the_title($next)); ?>"><?php echo esc_html(get_the_title($next)); ?></a></h2>
                <span><i class="far fa-user"></i> <?php echo GOV_lang::get('episode_page_posted_by_label'); ?>: <?php $author_id=get_post_field('post_author',$next); echo esc_html(get_the_author_meta('display_name',$author_id)); ?></span>
                <span><i class="far fa-calendar-alt"></i> <?php echo GOV_lang::get('series_info_posted_on_label');?>: <?php echo esc_html(human_time_diff(get_the_time('U',$next),current_time('timestamp')).GOV_lang::get('home_timeago_label')); ?></span>
            </div></div></div>
        <?php }
        echo '</div></div>';
    }
}
?>