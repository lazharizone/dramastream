<?php $seri = get_post_meta(get_the_ID(), 'ero_seri', true); 
$sub = get_post_meta(get_the_ID(),'ero_subepisode',true);
if($sub=='' || $sub=='None'){
	$sub = get_post_meta($seri,'ero_sub',true);
	$subln = rwmb_the_value('ero_sub','',$seri,false);
} else {
	$subln = rwmb_the_value('ero_subepisode','',get_the_ID(),false);
	if($subln==''){ $sub = 'Sub'; $subln = 'Sub'; }
}
$author_id = get_post_field( 'post_author', get_the_ID() );
?>
<div class="bixbox episodedl">
	<div class="epwrapper">
		<div class="epheader">
			<h1 class="entry-title" itemprop="headline"><?php the_title(); ?></h1>
			<div class="entry-info">
				<?php if(get_option('epssub')=='1'){ ?>
					<i class="status <?php echo $sub; ?>"><?php echo $subln; ?></i>
				<?php } ?> 
				<?php if (get_option('tsepauthor', 1)) { ?>
				<?php echo GOV_lang::get('episode_page_posted_by_label'); ?> 
				<span class="vcard author entry-author" itemprop="author" itemscope itemtype="https://schema.org/Person"><b class="fn"><span class="entry-author-name" itemprop="name"><?php echo get_the_author_meta('display_name', $author_id); ?></span></b></span>,<?php } ?> 
				<?php if (get_option('ts_view_count', 1)) { ?> <span id="ts-ep-view">? views</span>, <?php } ?>
				<?php if (get_option('tsepdate', 1)) { ?>
				<?php echo GOV_lang::get('episode_page_uploaded_at_label');?> 
				<span class="updated"><time itemprop="datePublished" datetime="<?php the_time('c'); ?>"><?php the_date(); ?></time></span>, 
				<?php } ?>
				<?php if (get_option('tsepserieslink', 1)) { ?>
				<?php echo GOV_lang::get('episode_page_more_episode_label'); ?> 
				<a href="<?php echo get_the_permalink($seri); ?>"><?php echo get_the_title($seri); ?></a>
				<?php } ?>
			</div>
		</div>
		<div class="notice">
			<p><?php echo GOV_lang::get('episode_page_below_player_keywords', ["anime_title" => get_the_title($seri), "episode_title" => get_the_title(), "blogname" => esc_attr( get_bloginfo( 'name', 'display' ) )]); ?> </p>
		</div>
		<div class="navimedia">
			<div class="left">
				<div class="naveps">
					<div class="nvs"><?php previous_post_link('%link', '<i class="fas fa-angle-left"></i> '.GOV_lang::get('episode_page_nav_prev_label'), TRUE); ?></div>
					<div class="nvs nvsc"><a href='<?php echo esc_url(dramastream_get_series_url_from_episode(get_the_ID())); ?>' aria-label='<?php echo GOV_lang::get('episode_page_nav_all_episodes_label'); ?>'><?php echo GOV_lang::get('episode_page_nav_all_episodes_label'); ?></a></div>
					<div class="nvs"><?php next_post_link('%link', GOV_lang::get('episode_page_nav_next_label').' <i class="fas fa-angle-right"></i>', TRUE); ?></div>
				</div>
			</div>
			<?php if(get_option('singlesocial')=='1'){ ?>
			<div class="right">
				<div class="sosmed">
					<a href="https://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>" target="_blank" aria-label="Share on Facebook"><span class="fab fa-facebook-f" aria-hidden="true"></span></a>
					<a href="https://twitter.com/share?url=<?php the_permalink(); ?>" target="_blank" aria-label="Share on Twitter"><span class="fab fa-twitter" aria-hidden="true"></span></a>
					<a href="whatsapp://send?text=<?php the_title(); ?> <?php the_permalink(); ?>" target="_blank" aria-label="Share on Whatsapp"><span class="fab fa-whatsapp" aria-hidden="true"></span></a>
					<a href="https://t.me/share/url?url=<?php the_permalink(); ?>&text=<?php the_title(); ?>" target="_blank" class="tlg" aria-label="Share on Telegram"><span class="fab fa-telegram-plane" aria-hidden="true"></span></a>
				</div>
			</div>
			<?php } ?>
		</div>
		<div class="epcontent entry-content" itemprop="text">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				<?php if(get_option('thumbdownload')){ ?>
				<div class="thumbnail">
					<?php if ( has_post_thumbnail() ) { 
						echo GOV_anime::get_post_thumbnail(get_the_ID(), "medium", 350, 246, [
									'itemprop' => 'image',
									'title' => get_the_title(get_the_ID()),
									'alt' => get_the_title(get_the_ID())
								]); 
					} else { 
						echo GOV_anime::get_post_thumbnail((int)$seri, "medium", 350, 246, [
									'itemprop' => 'image',
									'title' => get_the_title(get_the_ID()),
									'alt' => get_the_title(get_the_ID())
								]); 
					} ?>
				</div>
				<?php } ?>
				<?php if( '' !== get_post()->post_content ) { the_content(); } ?>
			<?php endwhile; endif; ?>
			<?php single_download_links(get_the_ID()); ?>
			<?php single_download_only_links(get_the_ID()); ?>
		</div>
	</div>
</div>
<div id="mobilepisode"></div>