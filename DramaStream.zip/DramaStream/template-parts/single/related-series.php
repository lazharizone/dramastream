<?php
defined("ABSPATH") || die("!");
if (get_option('relatedseries') == '1') {
	$metas = (int) get_post_meta(get_the_ID(), 'ero_seri', true);
	if (!$metas) {
		$metas = (int) get_post_meta(get_the_ID(), '_anikoto_series_id', true);
	}
	$terms = get_the_terms($metas, 'genres');
	$term_ids = wp_list_pluck($terms ?: [], 'term_id');
	$term_ids = array_slice($term_ids, 0, 2);

	$cache_key = 'ds_rel_series_' . (int)$metas . '_' . md5(serialize($term_ids));
	$rel_ids = get_transient($cache_key);

	if ($rel_ids === false) {
		$args = array(
			'post_type' => 'series',
			'tax_query' => !empty($term_ids) ? array(
				array(
					'taxonomy' => 'genres',
					'field' => 'id',
					'terms' => $term_ids,
					'operator' => 'AND'
				)
			) : [],
			'post__not_in' => array($metas),
			'posts_per_page' => 5,
			'ignore_sticky_posts' => 1,
			'no_found_rows' => true,
			'fields' => 'ids',
		);
		$args = apply_filters('tpl-related-series-args', $args);
		$temp_query = new WP_Query($args);
		$rel_ids = !empty($temp_query->posts) ? $temp_query->posts : [];
		set_transient($cache_key, $rel_ids, 1800); // Cache for 30 minutes
	}

	if (!empty($rel_ids)) {
		$my_query = new WP_Query(array(
			'post_type' => 'series',
			'post__in' => $rel_ids,
			'orderby' => 'post__in',
			'posts_per_page' => count($rel_ids),
			'no_found_rows' => true,
			'update_post_term_cache' => false,
		));
		if ($my_query->have_posts()) { ?>
			<div class="bixbox">
				<div class="releases">
					<h3><span><?php echo GOV_lang::get('recommended_series'); ?></span></h3>
				</div>
				<div class="listupd">
					<?php while ($my_query->have_posts()) {
						$my_query->the_post();
						get_template_part('template-parts/general/main');
					} ?>
				</div>
			</div>
		<?php }
		wp_reset_postdata();
	}
}
?>