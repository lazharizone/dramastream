<?php defined("ABSPATH") || die("!"); ?>
<?php $gpt = get_option('thotupdate'); if($gpt){ $stylehot = get_option('stylehot'); if($stylehot==''){$stylehot='1';}	?>
	<?php $kln = get_option('topf'); if($kln) { ?><div class="kln"><?php echo $kln; ?></div><br/><?php } ?>
	<div class="bixbox">
		<div class="releases hothome"><h2><?php echo GOV_lang::get('home_hot_series_update_label');?></h2></div>
		<div class="listupd <?php if($stylehot=='4'){ echo 'flex'; } else { echo 'normal'; } ?>">
		<div class="excstf">
		<?php $featured = new WP_Query(array(
					'post_status' => 'publish',
					'post_type' => 'series',
					'meta_key' => 'ts_today_view_count',
					'orderby' => 'meta_value_num',
					'order' => 'DESC',
					"showposts"     => $gpt,
					"ignore_sticky_posts" => 1,
					"no_found_rows"  => true,
					"update_post_term_cache" => false,
					"update_post_meta_cache" => false,
					"cache_results" => false
				)); while($featured->have_posts()) : $featured->the_post();
					get_template_part('template-parts/style-home/style', $stylehot);
				endwhile; ?>
			</div>
		</div>
	</div>
<?php } ?>	