<?php $kln = get_option('tople'); if($kln) { ?><div class="kln"><?php echo $kln; ?></div><br/><?php } ?>
<?php $gpt = get_option('tlatestepisode'); if($gpt){ $slugseries = get_option('changeslug'); if($slugseries===''){ $slugseries = 'series'; } ?>
<div class="bixbox">
	<?php 
	if (have_posts()) : 
	$style = get_option('stylelatest');
	if($style==''){$style='1';}	
	?>
	<div class="releases latesthome"><h3><?php echo GOV_lang::get('home_latest_release_label');?></h3><a class="vl" href="<?php bloginfo('url'); ?>/<?php echo $slugseries; ?>/?status=&type=&order=update"><?php echo GOV_lang::get('view_all_label');?></a></div>
	<div class="listupd <?php if($style=='4'){ echo 'flex'; } else { echo 'normal'; } ?>">
		<div class="excstf">
		<?php									
			$paged = get_query_var('paged')?:1;
			$paged = intval($paged);
			if ($paged < 1) $paged = 1;
			while($wp_query->have_posts()) : $wp_query->the_post(); 
				get_template_part('template-parts/style-home/style', $style);
			endwhile; ?>
		</div>
		<div class="hpage">
			<?php if( ($wp_query->post_count && $paged>1) || ($wp_query->post_count < 1 && $paged>1) ){ ?>
					<a href="<?php echo get_site_url()?>/page/<?php echo $paged-1; ?>/" class="l"><i class="fa fa-chevron-left" aria-hidden="true"></i> <?php echo GOV_lang::get('previous');?></a>
				<?php } ?>
				<?php if($wp_query->post_count>=$gpt){ ?>
					<a href="<?php echo get_site_url()?>/page/<?php echo $paged+1; ?>/" class="r"><?php echo GOV_lang::get('next');?> <i class="fa fa-chevron-right" aria-hidden="true"></i></a>
			<?php } ?>
		</div>
	</div>
	 <?php endif; ?>
</div>
<?php } ?>