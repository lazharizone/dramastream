<?php defined("ABSPATH") || die("!"); ?>
<?php 
$ep = get_post_meta(get_the_ID(),'ero_latest',true);
$epid = get_post_meta(get_the_ID(),'ero_latestid',true);
if(!is_home()){$epid = get_the_ID();}
$status = get_post_meta(get_the_ID(),'ero_status',true);
$type = get_post_meta(get_the_ID(),'ero_type',true);
$sub = get_post_meta($epid,'ero_subepisode',true);
if($sub=='' || $sub=='None'){
	$sub = get_post_meta(get_the_ID(),'ero_sub',true);
	$subln = rwmb_the_value('ero_sub','',get_the_ID(),false);
} else {
	$subln = rwmb_the_value('ero_subepisode','',$epid,false);
	if($subln==''){ $sub = 'Sub'; $subln = 'Sub'; }
}
$hot = get_post_meta(get_the_ID(),'ero_hot',true);
?>
<article class="bs" itemscope="itemscope" itemtype="http://schema.org/CreativeWork">
	<div class="bsx">
		<a href="<?php echo get_permalink(); ?>" itemprop="url" title="<?php echo get_the_title($epid); ?>" class="tip" rel="<?php the_ID(); ?>">
		<div class="limit">
			<?php if($type!=='Movie'){ if($status=='Completed'){ if(get_option('removecompleted')==='1') { ?><div class="status <?php echo $status; ?>"><?php echo GOV_lang::get('advanced_search_series_status_completed_label');?></div><?php } } } ?>
			<?php if($status!=='Completed' || get_option('removecompleted')!=='1') { if($hot=='Yes') { ?><div class="hotbadge"><i class="fas fa-fire-alt"></i></div><?php } } ?>
			<div class="typez <?php echo esc_attr(dramastream_card_type_class(get_the_ID())); ?>"><?php echo esc_html(dramastream_card_type_label(get_the_ID())); ?></div>
			<div class="ply"><i class="far fa-play-circle"></i></div>
			<div class="bt">
				<?php if($status=='Upcoming'){ echo '<div class="upco '.$status.'">'.rwmb_get_value('ero_status').'</div>'; } else { ?>
					<span class="epx ts-rtv" data-id="<?php echo get_the_ID(); ?>"><?php echo GOV_lang::get('home_realtime_user_online', ["users" => $wp_post->rtv]); ?></span>
					<?php if(get_option('removesub', 1)) { ?><span class="sb<?php echo ' '.$sub; ?>"><?php echo $subln; ?></span><?php } ?>
				<?php } ?>
			</div>
			<?php echo GOV_anime::get_post_thumbnail(get_the_ID(), "medium", 350, 246, [
				'itemprop' => 'image',
				'title' => get_the_title($epid),
				'alt' => get_the_title($epid)
			]); ?>
		</div>
		<div class="ttt">
			<div class="tt">
				<?php the_title(); ?>
				<h2 itemprop="headline"><?php echo get_the_title($epid); ?></h2>
			</div>
			<div class="timeago">
				<?php echo human_time_diff( get_the_time('U',$epid), current_time('timestamp') ) . GOV_lang::get('home_timeago_label'); ?>
			</div>
		</div>
		</a>
	</div>
</article>