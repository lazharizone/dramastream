<?php defined("ABSPATH") || die("!"); 

global $post;?>
<?php $gpt = get_option('thotupdate'); if($gpt){ $stylehot = get_option('stylehot'); if($stylehot==''){$stylehot='1';}	?>
	<?php $kln = get_option('topf'); if($kln) { ?><div class="kln"><?php echo $kln; ?></div><br/><?php } ?>
	<div class="bixbox" id="homertv">
		<div class="releases hothome"><h2><?php echo GOV_lang::get('home_hot_series_realtime_users_label');?></h2></div>
		<div class="listupd <?php if($stylehot=='4'){ echo 'flex'; } else { echo 'normal'; } ?>">
		<div class="excstf ts-rtv-pool" id="ts-rtv-pool" data-hash="<?php echo $current_hash;?>">
			<span class="ts-rtv-cont">
		<?php 
		
		foreach($popular_posts as $post){ 
			setup_postdata($post);
			ts_load_part('template-parts/home/home-hot-box-realtime', ["wp_post" => $post]);
		}
		wp_reset_postdata();
		?>
			</span>
		</div>
		</div>
	</div>
<?php } ?>	
