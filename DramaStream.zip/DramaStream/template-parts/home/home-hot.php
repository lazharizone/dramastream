<?php defined("ABSPATH") || die("!"); 
$hot_mode = get_option('tshotmode', 'views');
if ($hot_mode === "realtime" && rtv_get_instance()->rtv_can_run()){
	$by_user_html = GOV_cache::object_cache_get("popular-by-users-online");
}else{
	$by_user_html = NULL;
}
if ($hot_mode === "realtime" && $by_user_html && trim($by_user_html)){
	echo $by_user_html;
}else{
	ts_load_part("/template-parts/home/home-hot-views");
}