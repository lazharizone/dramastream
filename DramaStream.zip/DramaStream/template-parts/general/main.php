<?php 
$ep = get_post_meta(get_the_ID(),'ero_latest',true);
$epid = get_post_meta(get_the_ID(),'ero_latestid',true);
if(!is_home()){$epid = get_the_ID();}
$status = get_post_meta(get_the_ID(),'ero_status',true);
$type = get_post_meta(get_the_ID(),'ero_type',true);
$epidx = get_post_meta(get_the_ID(),'ero_latestid',true);
$sub = get_post_meta($epidx,'ero_subepisode',true);
if($sub=='' || $sub=='None'){
	$sub = get_post_meta(get_the_ID(),'ero_sub',true);
	$subln = rwmb_the_value('ero_sub','',get_the_ID(),false);
} else {
	$subln = rwmb_the_value('ero_subepisode','',$epidx,false);
	if($subln==''){ $sub = 'Sub'; $subln = 'Sub'; }
}
$hot = get_post_meta(get_the_ID(),'ero_hot',true);
?>
<article class="bs" itemscope="itemscope" itemtype="http://schema.org/CreativeWork">
	<div class="bsx">
		<a href="<?php echo get_permalink($epid); ?>" itemprop="url" title="<?php echo get_the_title($epid); ?>" class="tip" rel="<?php the_ID(); ?>">
		<div class="limit">
			<?php if($type!=='Movie'){ if($status=='Completed'){ if(get_option('removecompleted')==='1') { ?><div class="status <?php echo $status; ?>"><?php rwmb_the_value('ero_status'); ?></div><?php } } } ?>
			<?php if($status!=='Completed' || get_option('removecompleted')!=='1') { if($hot=='Yes') { ?><div class="hotbadge"><i class="fas fa-fire-alt"></i></div><?php } } ?>
			<div class="typez <?php echo esc_attr(dramastream_card_type_class(get_the_ID())); ?>"><?php echo esc_html(dramastream_card_type_label(get_the_ID())); ?></div>
			<div class="ply"><i class="far fa-play-circle"></i></div>
			<div class="bt">
				<span class="epx"><?php if($type=='Movie'){ ?><?php rwmb_the_value('ero_type'); ?><?php } elseif($ep || is_numeric($ep)) { ?><?php echo GOV_lang::get('home_style_ep_label');?> <?php echo $ep; ?><?php } ?></span>
				<?php if(get_option('removesub', 1)) { ?><span class="sb<?php echo ' '.$sub; ?>"><?php echo $subln; ?></span><?php } ?>
			</div>
			<?php echo GOV_anime::get_post_thumbnail(get_the_ID(), "medium", 350, 246, [
				'itemprop' => 'image',
				'title' => get_the_title($epid),
				'alt' => get_the_title($epid)
			]); ?>
		</div>
		<div class="tt tts">
			<?php the_title(); ?>
			<h2 itemprop="headline"><?php the_title(); ?></h2>
		</div>
		</a>
	</div>
</article>