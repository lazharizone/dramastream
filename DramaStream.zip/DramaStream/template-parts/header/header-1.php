<div class="th">
	<div class="centernav bound">
		<div class="shme"><i class="fa fa-bars" aria-hidden="true"></i></div>
		<header class="mainheader" role="banner" itemscope itemtype="http://schema.org/WPHeader">
			<div class="site-branding logox">
			<?php
			$topmenu = wp_nav_menu( array( 'theme_location' => 'top','fallback_cb' => '','echo' => '0' ) );
			$logo = get_option('logo'); 
			$lightlogo = get_option('logox');
			if($logo) { if(is_home()){ ?>
					<h1 class="logos">
						<a title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?> - <?php echo esc_attr( get_bloginfo( 'description', 'display' ) ); ?>" itemprop="url" href="<?php echo esc_url( home_url( '/' ) ); ?>"><img itemprop="image" src="<?php echo $logo; ?>" width="195" height="35" alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?> - <?php echo esc_attr( get_bloginfo( 'description', 'display' ) ); ?>"><span class="hdl"><?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?> - <?php echo esc_attr( get_bloginfo( 'description', 'display' ) ); ?></span></a>
					</h1>
					<?php } else { ?>
					<span class="logos">
						<a title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?> - <?php echo esc_attr( get_bloginfo( 'description', 'display' ) ); ?>" itemprop="url" href="<?php echo esc_url( home_url( '/' ) ); ?>"><img itemprop="image" src="<?php echo $logo; ?>" width="195" height="35" alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?> - <?php echo esc_attr( get_bloginfo( 'description', 'display' ) ); ?>"><span class="hdl"><?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?> - <?php echo esc_attr( get_bloginfo( 'description', 'display' ) ); ?></span></a>
					</span>
				<?php } } ?>
					<span class="mobilelogo">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo $logo; ?>" width="195" height="35" alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?> - <?php echo esc_attr( get_bloginfo( 'description', 'display' ) ); ?>" /></a>
					</span>
					<meta itemprop="name" content="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" />
			</div>
		</header>
		<?php if(get_option('tssearchbox')!=='0'){ ?>
		<div class="searchx<?php if($topmenu){echo ' topcon';}?> minmb">
			<form action="<?php bloginfo('url'); ?>/" id="form" method="get" itemprop="potentialAction" itemscope itemtype="http://schema.org/SearchAction">
				<meta itemprop="target" content="<?php bloginfo('url'); ?>/?s={query}"/>
				<input id="s" itemprop="query-input" class="search-live" type="text" placeholder="<?php echo GOV_lang::get('search_placeholder_label');?>" name="s"/>
				<button type="submit" id="submit-search" aria-label="search"><i class="fa fa-search" aria-hidden="true"></i></button>
				<div class="srcmob srccls"><i class="fas fa-times-circle"></i></div>
			</form>
		</div>
		<div class="srcmob"><i class="fas fa-search" aria-hidden="true"></i></div>
		<?php } ?>
		<div id="thememode">
			<span id="switchtext">Switch Mode</span>
			<label class="switch">
				 <input type="checkbox" aria-labelledby="switchtext">
				 <span class="slider round"></span>
			</label>
		</div>
			<script>
				if (localStorage.getItem("thememode") == null){
					if (ts_configs.get('general.defaultTheme') == "lightmode"){
						jQuery(".logos img").attr('src', '<?php echo $lightlogo; ?>');
						jQuery("#thememode input[type='checkbox']").prop('checked', false);
					}else{
						jQuery(".logos img").attr('src', '<?php echo $logo; ?>');
						jQuery("#thememode input[type='checkbox']").prop('checked', true);
					}
				}else if (localStorage.getItem("thememode") == "lightmode"){
					jQuery(".logos img").attr('src', '<?php echo $lightlogo; ?>');
					jQuery("#thememode input[type='checkbox']").prop('checked', false);
				}else{
					jQuery(".logos img").attr('src', '<?php echo $logo; ?>');
					jQuery("#thememode input[type='checkbox']").prop('checked', true);
				}
			</script>
		<?php if($topmenu){ echo '<span class="topmobile"><i class="fa fa-th-large" aria-hidden="true"></i></span><div id="top-menu" class="topmobcon">'.$topmenu.'</div>'; } ?>
	</div>
</div>
<nav id="main-menu" class="mm">
	<div class="centernav">
		<div class="bound">
			<span itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement" role="navigation">
			<?php 
				$nav_menu = wp_nav_menu(array('theme_location'=>'main', 'container'=>'', 'link_before'=>'<span itemprop="name">','link_after'=>'</span>','fallback_cb' => '', 'echo' => 0)); 
					if(empty($nav_menu))
						$nav_menu = '<ul>'.wp_list_categories(array('show_option_all'=>__('Home', 'dp'), 'title_li'=>'', 'echo'=>0)).'</ul>';
					echo $nav_menu;
			?>
			</span>
			<?php if(get_option('disable_surprise')!=='0'){ ?>
				<a href="<?php bloginfo('url'); ?>/random" class="surprise"><i class="fa fa-star-o" aria-hidden="true"></i> <?php echo GOV_lang::get('surprise_me_label');?></a>
			<?php } ?>
			<div class="clear"></div>
		</div>
	</div>
</nav>