<?php 
$latest_real_id = function_exists('dramastream_get_latest_real_episode_id') ? dramastream_get_latest_real_episode_id(get_the_ID()) : (int)get_post_meta(get_the_ID(),'ero_latestid',true);
$ep = $latest_real_id ? get_post_meta($latest_real_id,'ero_episodebaru',true) : get_post_meta(get_the_ID(),'ero_latest',true);
if(!is_home()){
	$epidur = get_the_ID();
} else {
	if (get_option('tshtdes', 1)) {
		$epidur = get_post_meta(get_the_ID(),'ero_latestid',true);
	} else {
		$epidur = get_the_ID();
	}
}
$epid = $latest_real_id ?: (int)get_post_meta(get_the_ID(),'ero_latestid',true);
$hot = get_post_meta(get_the_ID(),'ero_hot',true);
$date_format = get_option('date_format');
$time_format = get_option('time_format');
?>
<article class="stylenine" itemscope="itemscope" itemtype="http://schema.org/CreativeWork">
	<div class="bsx">
		<div class="thumb">
			<a href="<?php echo get_permalink($epidur); ?>" itemprop="url" title="<?php echo get_the_title($epid); ?>" class="tip" rel="<?php the_ID(); ?>">
				<?php if($hot=='Yes') { ?><div class="hotbadge"><i class="fas fa-fire-alt"></i></div><?php } ?>
				<?php if ( $epid && has_post_thumbnail($epid) ) { 
						echo GOV_anime::get_post_thumbnail((int)$epid, "thumbnail", NULL, NULL, [
							'itemprop' => 'image',
							'title' => get_the_title($epid),
							'alt' => get_the_title($epid)
						]); 
					} else { 
						echo GOV_anime::get_post_thumbnail(get_the_ID(), "full", 97, 137, [
							'itemprop' => 'image',
							'title' => get_the_title($epid),
							'alt' => get_the_title($epid)
						]); 
					} ?>
			</a>
		</div>
		<div class="inf">
				<h2 itemprop="headline"><a href="<?php echo get_permalink($epidur); ?>" itemprop="url" title="<?php echo get_the_title($epid); ?>"><?php echo get_the_title($epid); ?></a></h2>
				<span><?php echo GOV_lang::get('series_info_posted_on_label');?> <?php echo get_the_date($date_format,$epid); ?> <?php echo get_the_time($time_format,$epid); ?>, <?php echo GOV_lang::get('episode_page_posted_by_label'); ?> <?php $author_id = get_post_field( 'post_author', $epid ); echo get_the_author_meta('display_name', $author_id); ?></span>
				<span><?php echo GOV_lang::get('home_latest_release_stylenine');?> <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></span>
			</div>
	</div>
</article>