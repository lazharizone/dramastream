<?php 
$latest_real_id = function_exists('dramastream_get_latest_real_episode_id') ? dramastream_get_latest_real_episode_id(get_the_ID()) : (int)get_post_meta(get_the_ID(),'ero_latestid',true);
$ep = $latest_real_id ? get_post_meta($latest_real_id,'ero_episodebaru',true) : get_post_meta(get_the_ID(),'ero_latest',true);
if(!is_home()){
	$epidur = get_the_ID();
} else {
	if (get_option('tshtdes', 1)) {
		$epidur = get_post_meta(get_the_ID(),'ero_latestid',true);
	} else {
		$epidur = get_the_ID();
	}
}
$epid = $latest_real_id ?: (int)get_post_meta(get_the_ID(),'ero_latestid',true);
if(!is_home()){$epid = get_the_ID();}
$status = get_post_meta(get_the_ID(),'ero_status',true);
$type = get_post_meta(get_the_ID(),'ero_type',true);
$sub = get_post_meta($epid,'ero_subepisode',true);
if($sub=='' || $sub=='None'){
	$sub = get_post_meta(get_the_ID(),'ero_sub',true);
	$subln = rwmb_the_value('ero_sub','',get_the_ID(),false);
} else {
	$subln = rwmb_the_value('ero_subepisode','',$epid,false);
	if($subln==''){ $sub = 'Sub'; $subln = 'Sub'; }
}
$hot = get_post_meta(get_the_ID(),'ero_hot',true);
?>
<article class="bs styletere" itemscope="itemscope" itemtype="http://schema.org/CreativeWork">
	<div class="bsx">
		<a href="<?php echo get_permalink($epidur); ?>" title="<?php echo get_the_title($epid); ?>">
		<div class="tt"><?php the_title(); ?></div>
		<div class="limit">
			<?php if($hot=='Yes') { ?><div class="hotbadge"><i class="fas fa-fire-alt"></i></div><?php } ?>
			<div class="typez <?php echo esc_attr(dramastream_card_type_class(get_the_ID())); ?>"><?php echo esc_html(dramastream_card_type_label(get_the_ID())); ?></div>
			<div class="ply"><i class="far fa-play-circle"></i></div>
			<?php if($status=='Upcoming'){ echo '<div class="bt"><div class="upco '.$status.'">'.rwmb_the_value('ero_status','',get_the_ID(),false).'</div></div>'; } else {
			if(get_option('removesub', 1)) { ?>
			<div class="bt">
				<span class="sb<?php echo ' '.$sub; ?>"><?php echo $subln; ?></span>
			</div>
			<?php } } ?>
			<?php 
				if ( $epid && has_post_thumbnail($epid) ) { 
					echo GOV_anime::get_post_thumbnail( (int) $epid, "thumbnail", 170, 170, [
						'itemprop' => 'image',
						'title' => get_the_title($epid),
						'alt' => get_the_title($epid)
					]);
				} else { 
					echo GOV_anime::get_post_thumbnail(get_the_ID(), "full", 200, 200, [
						'itemprop' => 'image',
						'title' => get_the_title($epid),
						'alt' => get_the_title($epid)
					]);
				} ?>
		</div>
		<div class="epdate">
				<h2 itemprop="headline"><?php echo get_the_title($epid); ?></h2>
				<span class="epx"><?php if($type=='Movie'){ ?><?php rwmb_the_value('ero_type'); ?><?php } else if($ep || is_numeric($ep)) { ?><?php echo GOV_lang::get('home_style_ep_label');?> <?php echo $ep; ?><?php } ?></span>
				<span class="datex"><?php echo human_time_diff( get_the_time('U',$epid), current_time('timestamp') ) . GOV_lang::get('home_timeago_label'); ?></span>
		</div>
		</a>
	</div>
</article>