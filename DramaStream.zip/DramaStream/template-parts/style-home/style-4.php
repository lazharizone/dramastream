<?php 
$latest_real_id = function_exists('dramastream_get_latest_real_episode_id') ? dramastream_get_latest_real_episode_id(get_the_ID()) : (int)get_post_meta(get_the_ID(),'ero_latestid',true);
$ep = $latest_real_id ? get_post_meta($latest_real_id,'ero_episodebaru',true) : get_post_meta(get_the_ID(),'ero_latest',true);
if(!is_home()){
	$epidur = get_the_ID();
} else {
	if (get_option('tshtdes', 1)) {
		$epidur = get_post_meta(get_the_ID(),'ero_latestid',true);
	} else {
		$epidur = get_the_ID();
	}
}
$epid = $latest_real_id ?: (int)get_post_meta(get_the_ID(),'ero_latestid',true);
if(!is_home()){$epid = get_the_ID();}
$type = get_post_meta(get_the_ID(),'ero_type',true);
$status = get_post_meta(get_the_ID(),'ero_status',true);
$hot = get_post_meta(get_the_ID(),'ero_hot',true);
?>
<article class="stylefor" itemscope="itemscope" itemtype="http://schema.org/CreativeWork">
	<div class="bsx">
		<a href="<?php echo get_permalink($epidur); ?>" itemprop="url" title="<?php echo get_the_title($epid); ?>" class="tip" rel="<?php the_ID(); ?>">
		<div class="limit">
			<?php if($hot=='Yes') { ?><div class="hotbadge"><i class="fas fa-fire-alt"></i></div><?php } ?>
			<div class="typez <?php echo esc_attr(dramastream_card_type_class(get_the_ID())); ?>"><?php echo esc_html(dramastream_card_type_label(get_the_ID())); ?></div>
			<?php echo GOV_anime::get_post_thumbnail(get_the_ID(), "full", 350, 246, [
					'itemprop' => 'image',
					'title' => get_the_title($epid),
					'alt' => get_the_title($epid)
				]);
			?>
			<div class="tt">
				<h2 itemprop="headline"><?php echo get_the_title($epid); ?></h2>
				<span><?php rwmb_the_value('ero_status'); ?> <?php if($type=='Movie'){ echo '<i>'.rwmb_the_value('ero_type','',get_the_ID(),false).'</i>'; } else if($ep || is_numeric($ep)) { echo '<i>'.$ep.'</i>'; } ?></span>
			</div>
		</div>
		</a>
	</div>
</article>