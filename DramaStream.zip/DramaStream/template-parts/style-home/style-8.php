<?php 
$latest_real_id = function_exists('dramastream_get_latest_real_episode_id') ? dramastream_get_latest_real_episode_id(get_the_ID()) : (int)get_post_meta(get_the_ID(),'ero_latestid',true);
$ep = $latest_real_id ? get_post_meta($latest_real_id,'ero_episodebaru',true) : get_post_meta(get_the_ID(),'ero_latest',true);
if(!is_home()){
	$epidur = get_the_ID();
} else {
	if (get_option('tshtdes', 1)) {
		$epidur = get_post_meta(get_the_ID(),'ero_latestid',true);
	} else {
		$epidur = get_the_ID();
	}
}
$epid = $latest_real_id ?: (int)get_post_meta(get_the_ID(),'ero_latestid',true);
if(!is_home()){$epid = get_the_ID();}
$status = get_post_meta(get_the_ID(),'ero_status',true);
$type = get_post_meta(get_the_ID(),'ero_type',true);
$sub = get_post_meta($epid,'ero_subepisode',true);
if($sub=='' || $sub=='None'){
	$sub = get_post_meta(get_the_ID(),'ero_sub',true);
	$subln = rwmb_the_value('ero_sub','',get_the_ID(),false);
} else {
	$subln = rwmb_the_value('ero_subepisode','',$epid,false);
	if($subln==''){ $sub = 'Sub'; $subln = 'Sub'; }
}
$hot = get_post_meta(get_the_ID(),'ero_hot',true);
?>
<article class="bs styleegg" itemscope="itemscope" itemtype="http://schema.org/CreativeWork">
	<div class="bsx">
		<a href="<?php echo get_permalink($epidur); ?>" itemprop="url" title="<?php echo get_the_title($epid); ?>" class="tip" rel="<?php the_ID(); ?>">
		<div class="limit">
			<?php if($type!=='Movie'){ if($status=='Completed'){ if(get_option('removecompleted')==='1') { ?><div class="status <?php echo $status; ?>"><?php rwmb_the_value('ero_status'); ?></div><?php } } } ?>
			<?php if($status!=='Completed' || get_option('removecompleted')!=='1') { if($hot=='Yes') { ?><div class="hotbadge"><i class="fas fa-fire-alt"></i></div><?php } } ?>
			<div class="bt">
				<?php if(get_option('removesub')=='1'){ $ak_langs=function_exists('dramastream_episode_language_badges') ? dramastream_episode_language_badges($epid,get_the_ID()) : [$subln]; foreach($ak_langs as $ak_lang){ $ak_cls = strtoupper($ak_lang)==='DUB' ? ' Dub' : ' Sub'; ?><span class="sb<?php echo esc_attr($ak_cls); ?>"><?php echo esc_html($ak_lang); ?></span><?php } } ?>
			</div>
			<div class="ply"><i class="far fa-play-circle"></i></div>
			<div class="egghead">
				<div class="eggtitle"><?php the_title(); ?></div>
				<div class="eggmeta">
					<div class="eggtype <?php echo esc_attr($type); ?>"><?php echo esc_html(strtoupper($type === 'Anime' ? 'TV' : rwmb_the_value('ero_type','',get_the_ID(),false))); ?></div>
					<?php if($status=='Upcoming'){ echo '<div class="eggepisode">'.rwmb_the_value('ero_status','',get_the_ID(),false).'</div>'; } else { ?>
						<?php if($type=='Movie'){ } else if($ep || is_numeric($ep)) { ?><div class="eggepisode"><?php echo GOV_lang::get('widget_episode_label');?> <?php echo $ep; ?></div><?php } ?>
					<?php } ?>
				</div>
			</div>
			<?php echo GOV_anime::get_post_thumbnail(get_the_ID(), "full", 350, 246, [
					'itemprop' => 'image',
					'title' => get_the_title($epid),
					'alt' => get_the_title($epid)
				]); 
			?>
		</div>
			<div class="tt">
				<h2 itemprop="headline"><?php echo get_the_title($epid); ?></h2>
			</div>
		</a>
	</div>
</article>