<?php
$type = get_post_meta(get_the_ID(),'ero_type',true);
$latest_real_id = function_exists('dramastream_get_latest_real_episode_id') ? dramastream_get_latest_real_episode_id(get_the_ID()) : (int)get_post_meta(get_the_ID(),'ero_latestid',true);
$ep = $latest_real_id ? get_post_meta($latest_real_id,'ero_episodebaru',true) : get_post_meta(get_the_ID(),'ero_latest',true); if($ep==''){ $ep = '?'; }
if(!is_home()){
	$epidur = get_the_ID();
} else {
	if (get_option('tshtdes', 1)) {
		$epidur = get_post_meta(get_the_ID(),'ero_latestid',true);
	} else {
		$epidur = get_the_ID();
	}
}
$epid = $latest_real_id ?: (int)get_post_meta(get_the_ID(),'ero_latestid',true);
$sub = get_post_meta($epid,'ero_subepisode',true);
if($sub=='' || $sub=='None'){
	$sub = get_post_meta(get_the_ID(),'ero_sub',true);
	$subln = rwmb_the_value('ero_sub','',get_the_ID(),false);
} else {
	$subln = rwmb_the_value('ero_subepisode','',$epid,false);
	if($subln==''){ $sub = 'Sub'; $subln = 'Sub'; }
}
$episodes = get_post_meta( get_the_ID(), 'ero_episode', true ); if($episodes==''){ $episodes = '?'; }
$status = rwmb_the_value('ero_status','',get_the_ID(),false);
$hot = get_post_meta(get_the_ID(),'ero_hot',true);
?>
<article class="seventh" itemscope="itemscope" itemtype="http://schema.org/CreativeWork">
	<div class="main-seven">
		<a href="<?php echo get_permalink($epidur); ?>" itemprop="url" title="<?php echo get_the_title($epid); ?>">
		<div class="limit">
			<?php if($hot=='Yes') { ?><div class="hotbadge"><i class="fas fa-fire-alt"></i></div><?php } ?>
			<?php if ( $epid && has_post_thumbnail($epid) ) { 
					echo GOV_anime::get_post_thumbnail((int)$epid, "thumbnail", NULL, NULL, [
						'itemprop' => 'image',
						'title' => get_the_title($epid),
						'alt' => get_the_title($epid)
					]); 
				} else { 
					echo GOV_anime::get_post_thumbnail(get_the_ID(), "full", 138, 250, [
						'itemprop' => 'image',
						'title' => get_the_title($epid),
						'alt' => get_the_title($epid)
					]); 
				} ?>
			<div class="epin"><?php if($type!=='Movie'){ echo $ep.'/'.$episodes; } ?></div>
			<div class="bt">
				<?php if(get_option('removesub', 1)) { ?><span class="sb <?php echo $sub; ?>"><?php echo $subln; ?></span><?php } ?>
				<span class="type <?php echo esc_attr($type); ?>"><?php echo esc_html(strtoupper($type === 'Anime' ? 'TV' : rwmb_the_value('ero_type','',get_the_ID(),false))); ?></span>
			</div>
		</div>
		</a>
			<div class="tt">
				<div class="thethumb"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php echo GOV_anime::get_post_thumbnail(get_the_ID(), "thumbnail", 80, 80, [
						'alt' => get_the_title(get_the_ID())
					]); ; ?></a></div>
				<div class="sosev">
					<h2 itemprop="headline"><a href="<?php echo get_permalink($epidur); ?>" itemprop="url" title="<?php echo get_the_title($epid); ?>"><?php echo get_the_title($epid); ?></a></h2>
					<span><a href="<?php the_permalink(); ?>" itemprop="url" title="<?php the_title(); ?>" class="tip" rel="<?php the_ID(); ?>"><?php the_title(); ?></a></span>
					<span><?php echo $status; ?> · <?php echo human_time_diff( get_the_time('U',$epid), current_time('timestamp') ) . GOV_lang::get('home_timeago_label'); ?></span>
				</div>
			</div>
	</div>
</article>