<div class="clear"></div>
</div>
</div>

<?php get_template_part('template-parts/footer/footer','1'); ?>
<?php if(get_option('tsthemelayout')=='tsboxed'){ ?></div><?php } ?>
</div>

<?php wp_footer(); ?>
</body>
</html>