<!DOCTYPE html>
<html xmlns="https://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width" />
<?php $metac = get_option('themecolor'); if($metac==''){$metac='#0c70de';} ?>
<meta name="theme-color" content="<?php echo $metac; ?>">
<meta name="msapplication-navbutton-color" content="<?php echo $metac; ?>">
<meta name="mobile-web-app-capable" content="yes">
<?php wp_head(); ?>
</head>

<body class="<?php echo get_option('defaulttheme'); ?> <?php echo get_option('tsthemelayout'); ?>" itemscope="itemscope" itemtype="http://schema.org/WebPage">
<script>
			if (localStorage.getItem("thememode") == null){
				if (ts_configs.get('general.defaultTheme') == "lightmode"){
					jQuery("body").addClass("lightmode");
					jQuery("body").removeClass("darkmode");
				}else{
					jQuery("body").addClass("darkmode");
					jQuery("body").removeClass("lightmode");
				}
			}else if (localStorage.getItem("thememode") == "lightmode"){
				jQuery("body").addClass("lightmode");
				jQuery("body").removeClass("darkmode");
			}else{
				jQuery("body").addClass("darkmode");
				jQuery("body").removeClass("lightmode");
			}
	</script>
<div id='shadow'></div>

<div class="mainholder">
<?php if(get_option('tsthemelayout')=='tsboxed'){ ?><div class="tsboxedwrap"><?php } ?>
<?php get_template_part('template-parts/header/header','1'); ?>
	
<?php if(is_home()){ $kln = get_option('toprec'); if($kln) { ?><div class="blox mlb kln"><?php echo $kln; ?></div><br/><?php } } ?>

<div id="content">
	<div class="wrapper">
		<?php $ann = get_option('anngeneral'); if($ann) { ?><div class="announ"><?php echo $ann; ?></div><?php } ?>