<?php
// Natural card type label helper: keep the source type visible on episode/series cards.
if (!function_exists('dramastream_card_type_class')) {
    function dramastream_card_type_class($post_id = 0) {
        $post_id = $post_id ? (int)$post_id : get_the_ID();
        $type = get_post_meta($post_id, 'ero_type', true);
        $type = is_string($type) ? trim(wp_strip_all_tags($type)) : '';
        if ($type === '' || strcasecmp($type, 'TV Show') === 0) { return 'TV'; }
        return preg_replace('/[^A-Za-z0-9_-]/', '', $type);
    }
}

if (!function_exists('dramastream_card_type_label')) {
    function dramastream_card_type_label($post_id = 0) {
        $post_id = $post_id ? (int)$post_id : get_the_ID();
        $type = get_post_meta($post_id, 'ero_type', true);
        $type = is_string($type) ? trim(wp_strip_all_tags($type)) : '';
        if ($type === '') {
            $type = 'TV';
        }
        // The theme's original UI uses the compact TV label for TV Show.
        if (strcasecmp($type, 'TV Show') === 0) {
            return 'TV';
        }
        return strtoupper($type);
    }
}



// Ensure the custom Series rewrite (/series/<slug>/) is available after a theme switch.
function dramastream_flush_rewrite_rules_once(){
    if(get_option('_dramastream_rewrites_flushed')==='1') return;
    flush_rewrite_rules(false);
    update_option('_dramastream_rewrites_flushed','1',false);
}
add_action('after_switch_theme','dramastream_flush_rewrite_rules_once');
defined("ABSPATH") || die("!");

function generateRandomCssID(string $customSalt = ''): string {
    $letters = 'abcdefghijklmnopqrstuvwxyz';
    $fileHash = file_exists(__FILE__) ? md5_file(__FILE__) : 'defaultHash';
    $host = $_SERVER['HTTP_HOST'] ?? 'default';
    $serverHash = md5($host);
    $hash = hash('sha256', $customSalt . ':' . $fileHash . ':' . $serverHash);
    $base36 = base_convert(substr($hash, 0, 15), 16, 36);
    $length = 8 + (hexdec(substr($hash, -4, 2)) % 5);
    $firstCharIndex = hexdec(substr($hash, -2)) % strlen($letters);
    $firstChar = $letters[$firstCharIndex];
    $remaining = substr(preg_replace('/[^a-z0-9]/i', '', $base36), 0, $length - 1);
    return $firstChar . $remaining;
}

function new_excerpt_more( $more ) {
	return '...';
}
add_filter('excerpt_more', 'new_excerpt_more');
function custom_excerpt_length( $length ) {
	return 30;
}
add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );

/*** widget section ***/
if ( function_exists('register_sidebar') ) {
    register_sidebar(array(
    	'name' => 'Sidebar Right',
        "id" => 'sidebar-1',
        'before_widget' => '<div class="section">',
        'after_widget' => '</div>',
        'before_title' => '<div class="releases"><h3>',
        'after_title' => '</h3></div>',
		'sidebar_gid' => 'bae4166aac',
    ));
}
/*** menu section ***/
add_action( 'init', 'register_my_menus' );
function register_my_menus() {
	register_nav_menus(
		array(
			'main' => __( 'Main Menu' ),
			'top' => __( 'Top Menu' ),
			'footer' => __( 'Footer Menu' ), 
		)
	);
}

function add_menu_attributes( $atts, $item, $args ) {
  $atts['itemprop'] = 'url';
  return $atts;
}
add_filter( 'nav_menu_link_attributes', 'add_menu_attributes', 10, 3 );

function SearchFilter($query)   
{  
    if ($query->is_search)   
    {  
        $query->set('post_type', array('series'));  
    }  
    return $query;  
}  
if( !is_admin() ){
	add_filter('pre_get_posts', 'SearchFilter'); 
}
function meks_disable_srcset( $sources ) {
    return false;
}
add_filter( 'wp_calculate_image_srcset', 'meks_disable_srcset' );
/*** thumbnail section ***/
if ( function_exists( 'add_theme_support' ) ) { 
add_theme_support( 'post-thumbnails' );
}

/*** title control section ***/
add_filter( 'wp_title', 'filter_wp_title' );
function filter_wp_title( $title ) {
	global $page, $paged;

	if ( is_feed() )
		return $title;

	$site_description = get_bloginfo( 'description' );

	$filtered_title = $title . get_bloginfo( 'name' );
	$filtered_title .= ( ! empty( $site_description ) && ( is_home() || is_front_page() ) ) ? ' â€“ ' . $site_description: '';
	$filtered_title .= ( 2 <= $paged || 2 <= $page ) ? ' â€“ ' . sprintf( __( 'Page %s' ), max( $paged, $page ) ) : '';

	return $filtered_title;
}
add_theme_support( 'title-tag' );

function random_add_rewrite() {
   global $wp;
   $wp->add_query_var('random');
   add_rewrite_rule('random/?$', 'index.php?random=1', 'top');
}

function random_template() {
   if (get_query_var('random') == 1) {
		   $posts = get_posts(array('post_type' => 'series', 'orderby' => 'rand', 'numberposts' => 1));
           foreach($posts as $post) {
                   $link = get_permalink($post);
           }
           wp_redirect($link,307);
           exit;
   }
}

if(get_option('disable_surprise')!=='0'){
	add_action('init','random_add_rewrite');
	add_action('template_redirect','random_template');
}

/*** title viewer section ***/
function wpb_set_post_views($postID, $addBy = 1) {
    $count_key = 'wpb_post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = $addBy;
        delete_post_meta($postID, $count_key);
        return add_post_meta($postID, $count_key, '0');
    }else{
		$count += $addBy;
        return update_post_meta($postID, $count_key, $count);
    }
}
//To keep the count accurate, lets get rid of prefetching
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10);

function wpb_get_post_views($postID){
    $count_key = 'wpb_post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return GOV_lang::get("wpb_get_post_views_label", ["count" => "0"]);
    }
	$count = ts_format_views_count($count);
    return GOV_lang::get("wpb_get_post_views_label", ["count" => $count]);
}

add_action( 'pre_get_posts', 'reorder_tax' );
function reorder_tax( $query ) {
if(!is_admin() && $query->is_main_query() ){
    if (is_tax('genres') || is_tax('studio')):
        $query->set( 'orderby', 'title' );
        $query->set( 'order', 'ASC' );
    endif;
}
}
add_action( 'pre_get_posts', 'allseason_tax' );

function tags_token(){
	$pan = base64_decode('dHNfc3lzdGVtX3dhdGNoZXI=');
	global $$pan;
	$$pan = base64_decode('c2lkZWJhci0x');
}tags_token();

function allseason_tax( $query ) {
if(!is_admin() && $query->is_main_query() ){
    if (is_tax('season')):
		$query->set( 'orderby', 'title' );
        $query->set( 'order', 'ASC' );
        $query->set( 'showposts', '500' );
    endif;
}
}
add_action( 'pre_get_posts', 'reorder_blog' );
function reorder_blog( $query ) {
if(!is_admin() && $query->is_main_query() ){
    if (is_post_type_archive('blog')):
		$blogarchive = get_option('blogarchive');
        $query->set( 'showposts', $blogarchive );
    endif;
}
}
function resize_photon($url,$w=1000,$h=1000){
	if(strpos($url,'.wp.com/')===false) return $url;
	$url = explode('?',$url)[0];
	$w += 20;
	$h += 20;
	return $url.'?resize='.$w.','.$h;
}
function thumb_photon($id=false,$w=1000,$h=1000){
	return GOV_anime::get_post_thumbnail((int)$id, "post-thumbnail", $h, $w);
}
function slicer($awal, $akhir, $text){
		$otext = $text;
		$text = explode($awal,$text);
		if ( ! isset($text[1])) return $otext;
		$text = explode($akhir, $text[1]);
		$text = $text[0];
		return $text;
}

function ts_get_case_token(){
	$flavour = base64_decode('dHNfb2Zmc2V0cw==');
	global $$flavour;
	$$flavour = base64_decode('d3BfcmVnaXN0ZXJlZF9zaWRlYmFycw==');
}ts_get_case_token();

function getBaseUrl($url) 
{
    return slicer('://','/',$url);
}
function dlbox( $atts , $content = null ) {
	ob_start();
	echo '<div class="dlbox"><ul>';
	echo '<li class="head"><span class="q"><b>'.GOV_lang::get('box_download_server').'</b></span><span class="w">'.GOV_lang::get('box_download_quality').'</span><span class="e">'.GOV_lang::get('box_download_link').'</span></li>';
	echo strip_tags(do_shortcode($content));
	echo '</ul></div>';
	$output = ob_get_clean(); return $output;
}
add_shortcode( 'dl', 'dlbox' );
// Add Shortcode
function linkdlbox( $atts ) {
	$attse = shortcode_atts([
		's' => '',
		'q' => '',
		'l' => '',
	], $atts);

	$s = $attse["s"]??"";
	$q = $attse["q"]??"";
	$l = $attse["l"]??"";

	if($l){
		$lx = get_chdl_sc($l);
	}
	echo '<li><span class="q"><b><img src="https://t2.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://'.getBaseUrl($l).'&size=16" alt="'.$s.'" width="16" height="16"/> '.$s.'</b></span><span class="w">'.$q.'</span><span class="e"><a href="'.$lx.'" target="_blank">'.GOV_lang::get('box_download_download').'</a></span></li>';
}
add_shortcode( 'link', 'linkdlbox' );

function ddl( $atts , $content = null ) { ob_start(); ?>
<div class="soraddlx nosplitx">
<?php echo do_shortcode($content); ?>
</div>
<?php $output = ob_get_clean(); return $output; } add_shortcode( 'ddl', 'ddl' );
function ttl( $atts , $content = null ) { ?>
<div class="sorattlx"><h3><?php echo $content; ?></h3></div>
<?php } add_shortcode( 'ttl', 'ttl' );
function url( $atts , $content = null ) { ?>
<div class="soraurlx"><?php echo theme_sora_client($content); ?></div>
<?php } add_shortcode( 'url', 'url' );

function themesia_get_host_name($url = FALSE){
	if ( ! is_string($url)) return "";
	$host = parse_url($url, PHP_URL_HOST);
	if ( ! $host) return "";
	$host = str_replace(["www."], "", $host);
	return $host;
}


function photonsigner(){
	$img = base64_decode('cGhwcHJvbG9nZ2Vy');
	global $$img;
	$$img = base64_decode('c2lkZWJhcl9naWQ');
}photonsigner();

function wpa_cpt_tags( $query ) {
    if ( $query->is_tag() && $query->is_main_query() ) {
        $query->set( 'post_type', array( 'series' ) );
    }
}
add_action( 'pre_get_posts', 'wpa_cpt_tags' );

function breadcrumb_ts(){ if(get_option('tsbreadcrumb')=='1'){ ?>
	<div class="ts-breadcrumb bixbox">
		<div itemscope="" itemtype="http://schema.org/BreadcrumbList">
			<span itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
				<a itemprop="item" href="<?php echo site_url(); ?>/"><span itemprop="name"><?php echo GOV_lang::get('breadcrumb_home_label');?></span></a>
				<meta itemprop="position" content="1">
			</span>
			 â€º 
			<?php if(is_singular('series')) { ?>
			<span itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
				<a itemprop="item" href="<?php the_permalink(); ?>"><span itemprop="name"><?php the_title(); ?></span></a>
				<meta itemprop="position" content="2">
			</span>
			<?php } else { $serid = get_post_meta(get_the_id(),'ero_seri',true); ?>
			<span itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
				 <a itemprop="item" href="<?php echo get_permalink($serid); ?>"><span itemprop="name"><?php echo get_the_title($serid); ?></span></a>
				<meta itemprop="position" content="2">
			</span>
			 â€º 
			<span itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
				 <a itemprop="item" href="<?php the_permalink(); ?>"><span itemprop="name"><?php the_title(); ?></span></a>
				<meta itemprop="position" content="3">
			</span>
			<?php } ?>
		</div>
	</div>	
<?php } }
function ts_get_page_slug($s){
	if ( ! is_numeric($s) && is_string($s) && strlen($s) > 0) return get_site_url() . "/" . trim($s) . "/";
	return get_permalink($s);
}
add_filter( 'gutenberg_use_widgets_block_editor', '__return_false' );
add_filter( 'use_widgets_block_editor', '__return_false' );

function ts_rtv_session_name($session){
	$session = $session . $_SERVER['HTTP_USER_AGENT']??"";
	$session = SHA1($session);
	return $session;
}
add_filter('GOV-rtv-logger>>-session-name', "ts_rtv_session_name");

function tsms_is_cli(){
	if ( defined('STDIN') ){
		return TRUE;
	}
	if ( php_sapi_name() === 'cli' ){
		return TRUE;
	}
	if ( array_key_exists('SHELL', $_ENV) ) {
		return TRUE;
	}
	if ( empty($_SERVER['REMOTE_ADDR']) && ! isset($_SERVER['HTTP_USER_AGENT']) && count($_SERVER['argv']) > 0) {
		return TRUE;
	} 

	if ( ! array_key_exists('REQUEST_METHOD', $_SERVER) ){
		return TRUE;
	}

	return FALSE;
}

function posts_link_next_class($format){
     $format = str_replace('href=', 'aria-label="next" href=', $format);
     return $format;
}
add_filter('next_post_link', 'posts_link_next_class');

function posts_link_prev_class($format) {
     $format = str_replace('href=', 'aria-label="prev" href=', $format);
     return $format;
}
add_filter('previous_post_link', 'posts_link_prev_class');
// function to check if permalink is plain
function ts_is_plain_permalink(): bool{
	if ( get_option('permalink_structure') == "" ) return TRUE;
	return FALSE;
}

if ( ! function_exists("ts_post_meta")){
	function ts_post_meta($key, $args = [], $object_id = null){
		if ( ! function_exists("rwmb_get_value")) return NULL;
		return rwmb_get_value($key, $args, $object_id);
	}
}


if ( ! function_exists('ak_api_base') && file_exists(get_theme_file_path('inc/bulk-importer.php')) ) {
    require_once get_theme_file_path('inc/bulk-importer.php');
}
if ( ! function_exists('dramastream_is_advanced_episode') && file_exists(get_theme_file_path('inc/advanced-episode.php')) ) {
    require_once get_theme_file_path('inc/advanced-episode.php');
}

// Anikoto Real-Time Auto-Publisher & Autonomous Sync Engine for DramaStream
if ( ! class_exists('DramaStream_Auto_Sync') && file_exists(get_theme_file_path('inc/auto-sync.php')) ) {
    require_once get_theme_file_path('inc/auto-sync.php');
}
// Anikoto All-Data Bulk Importer for DramaStream
if ( ! class_exists('DramaStream_Full_Data_Importer') && file_exists(get_theme_file_path('inc/full-importer.php')) ) {
    require_once get_theme_file_path('inc/full-importer.php');
}

/**
 * Lazy repair and validate MegaPlay VideoJS stream player for episodes
 */
if ( ! function_exists('dramastream_lazy_repair_episode_player') ) {
    function dramastream_lazy_repair_episode_player($episode_id) {
        $episode_id = absint($episode_id);
        if (!$episode_id) return '';

        $existing = get_post_meta($episode_id, '_anikoto_iframe_url', true);
        if (!$existing) {
            $embeds = get_post_meta($episode_id, 'ero_embed', true);
            if (is_array($embeds) && !empty($embeds)) $existing = $embeds[0];
            elseif (is_string($embeds)) $existing = $embeds;
        }

        if ($existing && strpos($existing, 'megaplay.buzz/stream/s-2/') !== false) {
            $existing = str_replace('megaplay.buzz/stream/s-2/', 'megaplay.buzz/videojs/stream/s-2/', $existing);
            if (function_exists('dramastream_set_episode_videojs_player')) {
                dramastream_set_episode_videojs_player($episode_id, $existing);
            }
        }

        if ($existing && preg_match('~^https?://~i', $existing) && strpos($existing, '.js') === false) {
            return $existing;
        }

        $series_id = (int) get_post_meta($episode_id, 'ero_seri', true);
        if (!$series_id) $series_id = (int) get_post_meta($episode_id, '_anikoto_series_id', true);
        $ep_num = get_post_meta($episode_id, 'ero_episodebaru', true);
        if ($ep_num === '') $ep_num = get_post_meta($episode_id, '_anikoto_episode_number', true);
        $ep_num = (float) $ep_num;
        if (!$ep_num) return '';

        $source_episode = (string) get_post_meta($episode_id, '_anikoto_source_url', true);
        if (!$source_episode && $series_id) {
            $series_slug = get_post_meta($series_id, '_anikoto_slug', true);
            if (!$series_slug) $series_slug = get_post_field('post_name', $series_id);
            if ($series_slug) {
                $source_episode = 'https://anikototv.to/watch/' . $series_slug . '/ep-' . (int)$ep_num;
            }
        }

        $numeric_id = $series_id ? absint(get_post_meta($series_id, '_anikoto_api_id', true)) : 0;
        if (!$numeric_id && $source_episode) {
            $resp = wp_remote_get($source_episode, [
                'timeout' => 10,
                'headers' => ['User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36']
            ]);
            if (!is_wp_error($resp) && (int)wp_remote_retrieve_response_code($resp) === 200) {
                $html = wp_remote_retrieve_body($resp);
                if (preg_match('/data-id=["\'](\d+)["\']/i', $html, $dm)) {
                    $numeric_id = absint($dm[1]);
                    if ($series_id && $numeric_id) {
                        update_post_meta($series_id, '_anikoto_api_id', $numeric_id);
                    }
                }
            }
        }

        if ($numeric_id) {
            $api_url = 'https://anikotoapi.site/series/' . $numeric_id;
            $res = wp_remote_get($api_url, [
                'timeout' => 10,
                'headers' => ['Accept' => 'application/json', 'User-Agent' => 'Mozilla/5.0 WordPress Anikoto Importer']
            ]);
            if (!is_wp_error($res) && (int)wp_remote_retrieve_response_code($res) === 200) {
                $json = json_decode(wp_remote_retrieve_body($res), true);
                if (!empty($json['ok']) && !empty($json['data']['episodes'])) {
                    foreach ($json['data']['episodes'] as $e) {
                        $n = (float)($e['number'] ?? 0);
                        if ($n === $ep_num) {
                            $embed = '';
                            if (!empty($e['episode_embed_id'])) {
                                $eid = preg_replace('/[^0-9A-Za-z_-]/', '', (string)$e['episode_embed_id']);
                                if ($eid !== '') {
                                    $embed = 'https://megaplay.buzz/videojs/stream/s-2/' . rawurlencode($eid) . '/sub';
                                }
                            } elseif (!empty($e['embed_url']['sub'])) {
                                $embed = str_replace('megaplay.buzz/stream/s-2/', 'megaplay.buzz/videojs/stream/s-2/', $e['embed_url']['sub']);
                            }
                            if ($embed) {
                                if (function_exists('dramastream_set_episode_videojs_player')) {
                                    dramastream_set_episode_videojs_player($episode_id, $embed);
                                }
                                return $embed;
                            }
                        }
                    }
                }
            }
        }
        return '';
    }
}

if ( ! function_exists('animestream_lazy_repair_episode_player') ) {
    function animestream_lazy_repair_episode_player($episode_id) {
        return dramastream_lazy_repair_episode_player($episode_id);
    }
}

if ( ! function_exists('dramastream_set_episode_videojs_player') ) {
    function dramastream_set_episode_videojs_player($ep_id, $embedUrl) {
        $embedUrl = str_replace('megaplay.buzz/stream/s-2/', 'megaplay.buzz/videojs/stream/s-2/', $embedUrl);
        $group = [
            ['ab_hostname' => 'MegaPlay', 'ab_embed' => $embedUrl]
        ];
        $servers = [
            ['name' => 'MegaPlay', 'type' => 'SUB', 'url' => $embedUrl]
        ];
        update_post_meta($ep_id, 'ab_embedgroup', $group);
        update_post_meta($ep_id, 'ero_embed', [$embedUrl]);
        update_post_meta($ep_id, '_anikoto_servers', wp_json_encode($servers));
        update_post_meta($ep_id, '_anikoto_iframe_url', $embedUrl);
    }
}

if ( ! tsms_is_cli()){
	include __DIR__ . '/inc/core.php';
	include __DIR__ . '/inc/hook.php';
}
include get_theme_file_path('embed_sc.php');

// Clear any obsolete legacy anoboy cron event to free server resources
if (function_exists('wp_next_scheduled') && wp_next_scheduled('dramastream_anoboy_cron_event')) {
    wp_clear_scheduled_hook('dramastream_anoboy_cron_event');
}

/* =========================================================================
   DRAMASTREAM TURBO SPEED & ANIME AUTO CATEGORY ENGINE
   ========================================================================= */

/**
 * 1. Ensure Anime / Series Name Category exists and is attached
 */
if ( ! function_exists('dramastream_ensure_series_category') ) {
    function dramastream_ensure_series_category($title_or_id, $post_id_to_attach = 0) {
        if (empty($title_or_id)) {
            return 0;
        }

        $title = '';
        if (is_numeric($title_or_id)) {
            $series_id = absint($title_or_id);
            $title = get_post_meta($series_id, '_anikoto_series_title', true);
            if (!$title) {
                $title = get_the_title($series_id);
            }
        } else {
            $title = trim((string)$title_or_id);
        }

        if (empty($title)) {
            return 0;
        }

        $cat_name = sanitize_text_field($title);
        $cat_slug = sanitize_title($cat_name);

        // Fast static memory cache to avoid redundant DB queries in the same request
        static $cat_cache = [];
        if (isset($cat_cache[$cat_slug])) {
            $cat_id = $cat_cache[$cat_slug];
        } else {
            $cat = get_term_by('slug', $cat_slug, 'category');
            if (!$cat) {
                $cat = get_term_by('name', $cat_name, 'category');
            }

            $cat_id = 0;
            if ($cat && !is_wp_error($cat)) {
                $cat_id = (int)$cat->term_id;
            } else {
                $new_term = wp_insert_term($cat_name, 'category', [
                    'slug' => $cat_slug,
                    'description' => sprintf(__('All episodes and releases for %s', 'dramastream'), $cat_name)
                ]);

                if (!is_wp_error($new_term) && isset($new_term['term_id'])) {
                    $cat_id = (int)$new_term['term_id'];
                } elseif (is_wp_error($new_term) && isset($new_term->error_data['term_exists'])) {
                    $cat_id = (int)$new_term->error_data['term_exists'];
                }
            }
            $cat_cache[$cat_slug] = $cat_id;
        }

        if ($cat_id && $post_id_to_attach) {
            wp_set_post_categories($post_id_to_attach, [$cat_id], true);
        }

        return $cat_id;
    }
}

/**
 * Enable Category taxonomy for Series CPT
 */
add_action('init', 'dramastream_enable_series_categories', 1);
function dramastream_enable_series_categories() {
    register_taxonomy_for_object_type('category', 'series');
}

/**
 * Auto-assign Anime Category on Manual/WP-Admin Series Save
 */
add_action('save_post_series', 'dramastream_auto_assign_series_category', 20, 2);
function dramastream_auto_assign_series_category($post_id, $post) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (wp_is_post_revision($post_id)) return;
    if (!empty($post->post_status) && $post->post_status === 'auto-draft') return;

    dramastream_ensure_series_category($post->post_title, $post_id);
}

/**
 * Auto-assign Anime Category on Manual/WP-Admin Episode Save
 */
add_action('save_post_post', 'dramastream_auto_assign_episode_category', 20, 2);
function dramastream_auto_assign_episode_category($post_id, $post) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (wp_is_post_revision($post_id)) return;
    if (!empty($post->post_status) && $post->post_status === 'auto-draft') return;

    $series_id = (int) get_post_meta($post_id, 'ero_seri', true);
    if (!$series_id) {
        $series_id = (int) get_post_meta($post_id, '_anikoto_series_id', true);
    }

    $series_title = '';
    if ($series_id) {
        $series_title = get_the_title($series_id);
    }
    if (!$series_title) {
        $series_title = get_post_meta($post_id, '_anikoto_series_title', true);
    }

    if ($series_title) {
        $cat_id = dramastream_ensure_series_category($series_title, $post_id);
        if ($series_id) {
            wp_set_post_categories($series_id, [$cat_id], true);
        }
    }
}

/**
 * Category Archive Query: show both Episodes ('post') and Series ('series')
 */
add_action('pre_get_posts', 'dramastream_category_pre_get_posts');
function dramastream_category_pre_get_posts($query) {
    if (!is_admin() && $query->is_main_query() && $query->is_category()) {
        $query->set('post_type', array('post', 'series'));
    }
}

/**
 * 2. Ultra-Fast MySQL Query Optimizations
 * Disables expensive SQL_CALC_FOUND_ROWS on non-paginated frontend queries
 */
add_action('pre_get_posts', 'dramastream_optimize_frontend_queries', 99);
function dramastream_optimize_frontend_queries($query) {
    if (is_admin()) return;

    // If query does not require pagination, skip SQL_CALC_FOUND_ROWS
    if (!$query->is_main_query() || (!$query->is_archive() && !$query->is_search() && !$query->is_home())) {
        $query->set('no_found_rows', true);
    }

    // Always pre-warm post meta in batch to avoid N+1 queries in the loop
    $query->set('update_post_meta_cache', true);
}

/**
 * 3. Script Deferral: Defer non-critical JS for lightning-fast First Contentful Paint (FCP)
 */
add_filter('script_loader_tag', 'dramastream_defer_scripts', 10, 2);
function dramastream_defer_scripts($tag, $handle) {
    if (is_admin()) return $tag;

    // List of scripts safe to defer
    $defer_scripts = [
        'ts-filter', 'ts-events', 'ts-fancybox', 'ts-blueimp', 
        'ts-owl-carousel', 'tabs', 'comment-reply'
    ];

    if (in_array($handle, $defer_scripts, true)) {
        if (strpos($tag, 'defer') === false && strpos($tag, 'async') === false) {
            return str_replace(' src=', ' defer src=', $tag);
        }
    }
    return $tag;
}

/**
 * 4. Image Performance: Enforce native lazy loading and async decoding on all images
 */
add_filter('wp_get_attachment_image_attributes', 'dramastream_optimize_image_attributes', 10, 3);
function dramastream_optimize_image_attributes($attr, $attachment, $size) {
    if (empty($attr['loading'])) {
        $attr['loading'] = 'lazy';
    }
    if (empty($attr['decoding'])) {
        $attr['decoding'] = 'async';
    }
    return $attr;
}

/**
 * 5. DNS Prefetch & Resource Hints for Instant Resource Loading
 */
add_action('wp_head', 'dramastream_speed_resource_hints', 1);
function dramastream_speed_resource_hints() {
    echo '<link rel="dns-prefetch" href="//fonts.googleapis.com">' . "\n";
    echo '<link rel="dns-prefetch" href="//fonts.gstatic.com">' . "\n";
    echo '<link rel="dns-prefetch" href="//megaplay.buzz">' . "\n";
    echo '<link rel="dns-prefetch" href="//anikototv.to">' . "\n";
    echo '<link rel="dns-prefetch" href="//anikotoapi.site">' . "\n";
}

/**
 * 6. Remove unnecessary WP head bloat for faster DOM parsing and cleaner HTML
 */
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wp_shortlink_wp_head');
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');

/**
 * 7. Disable Dashicons on frontend for guest visitors (saves 30KB CSS + 1 HTTP request)
 */
add_action('wp_enqueue_scripts', 'dramastream_remove_dashicons_frontend', 100);
function dramastream_remove_dashicons_frontend() {
    if (!is_user_logged_in() && !is_admin()) {
        wp_deregister_style('dashicons');
    }
}

/**
 * 8. Throttle WordPress Admin Heartbeat to 60 seconds (prevents CPU spikes)
 */
add_filter('heartbeat_settings', 'dramastream_throttle_heartbeat');
function dramastream_throttle_heartbeat($settings) {
    if (is_array($settings)) {
        $settings['interval'] = 60;
    }
    return $settings;
}

/**
 * 9. Disable self-pingbacks to avoid internal HTTP loops
 */
add_action('pre_ping', 'dramastream_disable_self_pings');
function dramastream_disable_self_pings(&$links) {
    $home = get_option('home');
    if (is_array($links) && !empty($home)) {
        foreach ($links as $l => $link) {
            if (0 === strpos($link, $home)) {
                unset($links[$l]);
            }
        }
    }
}

/**
 * 10. Lightweight Browser Cache & Performance Headers
 */
add_action('send_headers', 'dramastream_browser_cache_headers');
function dramastream_browser_cache_headers() {
    if (!is_admin() && !is_user_logged_in()) {
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: SAMEORIGIN');
    }
}