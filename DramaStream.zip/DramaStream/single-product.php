<?php 
defined("ABSPATH") || die("!") ;
get_header(); 
?>
<div class="postbody">
    <div class="bixbox">
        <?php if (have_posts()) : ?>
        <div class="releases"><h1><?php the_title(); ?></h1></div>
        <?php while (have_posts()) : the_post(); ?>
        <div class="listupd">
            <?php the_content(); ?>
        </div>
        <?php endwhile; ?>
        <?php endif; ?>
    </div>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>