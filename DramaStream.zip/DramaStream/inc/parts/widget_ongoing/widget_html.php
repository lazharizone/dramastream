<?php defined("ABSPATH") || die("!");?>
<?php echo $wgog_before_widget;  ?>
<?php if ( ! empty( $wgog_name ) ) { 
    echo $wgog_before_title . $wgog_name . $wgog_after_title; 
}; ?>
<?php $wgog_ajax_cache->generate(function() use (&$wgog_ongoing_items){ ?>
    <div class='ongoingseries'>
        <ul>
            <?php foreach($wgog_ongoing_items as $k => $v) { ?>
                <li>
                    <a href="<?php echo $v['link'] ?>" title="<?php echo $v['title']; ?>">
                        <span class="l"><i class="fas fa-angle-right"></i> <?php echo $v['series_title']; ?></span>
                        <?php if($v['episode_number']) { ?>
                            <span class="r">
                                <?php echo GOV_lang::get('widget_episode_label');?> <?php echo $v['episode_number']; ?>
                            </span>
                        <?php } ?>
                    </a>
                </li>
            <?php } ; ?> 
        </ul>
    </div> 
<?php }); ?>
<?php echo $wgog_after_widget; ?>