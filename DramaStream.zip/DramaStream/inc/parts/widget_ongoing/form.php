<?php defined("ABSPATH") || die("!");?>
<p>Title Widget: <input class="widefat" name="<?php echo esc_attr($wgog_name_field); ?>" type="text" value="<?php echo esc_attr( $wgog_name );?>" /></p> 
<p>Display Series: <input class="widefat" name="<?php echo esc_attr($wgog_total_field); ?>" type="number" min="5" value="<?php echo esc_attr( $wgog_total ); ?>" /></p>  
