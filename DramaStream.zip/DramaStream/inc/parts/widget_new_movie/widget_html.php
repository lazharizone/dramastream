<?php defined("ABSPATH") || die("!");?>

<?php echo $wgnm_before_widget; ?>
		
<?php if ( ! empty( $wgnm_name ) ) { ?>
	<div class="releases">
		<h3><span><?php echo esc_attr($wgnm_name); ?></span></h3>
		<a class="vl" href="<?php echo esc_attr($wgnm_view_all_link); ?>">
			<?php echo GOV_lang::get('view_all_label'); ?>
		</a>
	</div>
<?php }; ?>

	<div class='serieslist'>
		<ul>
		<?php foreach($wgnm_new_movies as $k => $v) { ?>
			<li> 
				<div class="imgseries">
					<a class="series" href="<?php echo esc_attr($v['link']); ?>" rel="<?php esc_attr($v['ID']); ?>">
						<?php echo $v['image']; ?>
					</a>
				</div>  
				<div class="leftseries"> 
					<h4>
						<a class="series" href="<?php echo esc_attr($v['link']);?>" rel="<?php echo esc_attr($v['ID']); ?>">
							<?php echo esc_html($v['title']); ?>
						</a>
					</h4> 
					<?php echo $v['genres']; ?>
					<?php if($v['release']) { ?>
						<span><?php echo $v['release']; ?></span>
					<?php } ?>
				</div> 
			</li> 
		<?php } ?> 
		</ul>
	</div> 
	<?php echo $wgnm_after_widget; //Widget ends printing information ?>