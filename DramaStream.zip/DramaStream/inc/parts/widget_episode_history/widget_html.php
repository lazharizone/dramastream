<div class="ts-series-history-widget" data-id="<?php echo $widget_id; ?>" data-total="<?php echo $num_episodes; ?>" data-distinct="<?php echo $hide_duplicate; ?>">
    <ul id="list-<?php echo $widget_id; ?>" class="widgetephis"></ul>
</div>

<script>
    var container = document.getElementById("list-<?php echo $widget_id; ?>");
    var widget_id = "an_series_history_<?php echo $widget_id; ?>";
    //check cache 
    var localCache = window.localStorage.getItem('an_series_history');
    if (localCache) {
        var cache = JSON.parse(localCache);
        if (cache[widget_id]) {
            container.innerHTML = cache[widget_id];
        }
    }
</script>