<?php defined("ABSPATH") || die("!"); ?>
<p>
    <label for="<?php echo $field_title_id; ?>">Title:</label>
    <input class="widefat" id="<?php echo $field_title_id; ?>" name="<?php echo $field_title; ?>" type="text" value="<?php echo esc_attr($title); ?>">
</p>
<p>
    <label for="<?php echo $field_num_episodes_id; ?>">Number of Episodes to Show:</label>
    <input class="widefat" id="<?php echo $field_num_episodes_id; ?>" name="<?php echo $field_num_episodes; ?>" type="number" min="1" step="1" value="<?php echo esc_attr($num_episodes); ?>">
</p>
<p>
    <label for="widget-<?php echo $field_hide_duplicate_id; ?>">Show Single Episode Per Series:</label>
    <select id="widget-<?php echo $field_hide_duplicate_id; ?>" name="<?php echo $field_hide_duplicate_name; ?>">
        <option value="0" <?php if ($hide_duplicate == "0") echo "selected"; ?>>No</option>
        <option value="1" <?php if ($hide_duplicate == "1") echo "selected"; ?>>Yes</option>
    </select>
</p>