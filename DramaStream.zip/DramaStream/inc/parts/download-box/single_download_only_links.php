<?php defined('ABSPATH') || die("!"); 
foreach($dlgroup as $dlg){ 
    if ( ! isset($dlg['ab_resolution_ep'])) continue; ?>
    <div class="soraddlx soradlg">
        <div class="sorattlx"><h2><?php echo $dlg['ab_eptitle_ep']; ?></h2></div>
        <?php 
        $linkgroup = $dlg['ab_resolution_ep'];
        foreach($linkgroup as $lig){ 
            if ( ! isset($lig['ab_downloadlink_ep'])) continue;
            if ( ! isset($lig['ab_pixel_ep'])) $lig['ab_pixel_ep'] = "DL"; ?>
            <div class="soraurlx">
                <strong><?php echo $lig['ab_pixel_ep']; ?></strong>
                <?php 
                $alinkgroup = $lig['ab_downloadlink_ep'];
                foreach($alinkgroup as $aig){ 
                    if ( ! isset($aig['ab_linkurl_ep'])) continue;
                    if ( ! isset($aig['ab_hostingname_ep']) || ! $aig['ab_hostingname_ep']) $aig['ab_hostingname_ep'] = themesia_get_host_name($aig['ab_linkurl_ep']); ?>
                    <a href="<?php echo theme_sora_client_url($aig['ab_linkurl_ep']); ?>" target="_blank" rel="nofollow noopener noreferrer"><?php echo $aig['ab_hostingname_ep']; ?></a>
                <?php } ?>
            </div>
        <?php } ?>
    </div>
<?php } 