<?php defined('ABSPATH') || die("!"); ?>
<div class="bixbox">
    <div class="releases">
        <h2><?php echo GOV_lang::get('series_download_sc', ["post_title" => get_the_title($post_id)]);?></h2>
    </div>
    <div class="mctnx">
        <?php echo do_shortcode($shorcodemode); ?>
    </div>
</div>