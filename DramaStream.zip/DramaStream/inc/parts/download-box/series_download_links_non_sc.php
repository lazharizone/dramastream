<?php defined('ABSPATH') || die("!"); ?>
<div class="bixbox">
    <div class="releases">
        <h2><?php echo GOV_lang::get('series_download_sc', ["post_title" => get_the_title($post_id)]);?></h2>
    </div>
    <div class="mctnx">
        <div class="dlbox">
            <ul>
                <li class="head">
                    <span class="q"><b><?php echo GOV_lang::get('episode_page_download_server_label');?></b></span>
                    <span class="w"><?php echo GOV_lang::get('episode_page_download_quality_label');?></span>
                    <span class="e"><?php echo GOV_lang::get('episode_page_download_links_label');?></span></li>
                <?php foreach($dlgroup as $dlg){ 
                if ( ! isset($dlg['ab_linkurl']) || ! trim($dlg['ab_linkurl'])) continue;
                if ( ! isset($dlg['ab_quality']) || ! $dlg['ab_quality']) $dlg['ab_quality'] = "-";
                if ( ! isset($dlg['ab_hostingname']) || ! $dlg['ab_hostingname']) 
                    $dlg['ab_hostingname'] = parse_url($dlg['ab_linkurl'], PHP_URL_HOST);
                ?>
                <li>
                    <span class="q">
                        <b><img src="https://t2.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://<?php echo gov_get_hostname($dlg['ab_linkurl'])?:"example.com"; ?>&size=16" alt="<?php echo $dlg['ab_hostingname']; ?>" width="16" height="16"/> <?php echo $dlg['ab_hostingname']; ?></b>
                    </span>
                    <span class="w"><?php echo $dlg['ab_quality']; ?></span>
                    <span class="e"><a href="<?php echo sora_client_custom_link($dlg['ab_linkurl']); ?>" target="_blank" rel="nofollow noopener noreferrer"><?php echo GOV_lang::get('episode_page_download_button_label');?></a></span>
                </li>
                <?php } ?>
            </ul>
        </div>
    </div>
</div>