<?php defined("ABSPATH") || die("!");
add_filter("ts-sgen-parsed-data", function($array, $apiResponse, $provider){
    if ($provider !== "myanimelist") return $array;

    if ( ! $array['type']) $array["type"] = "Anime";

    return $array;

}, 10, 3);