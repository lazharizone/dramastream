<?php defined("ABSPATH") || die("!");
add_filter("ts-sgen-parsed-data", function($array, $apiResponse, $provider){
    if ($provider !== "mydramalist") return $array;
    
    $native_title = $apiResponse['native_title'] ?? "";
    $alternative_titles = $apiResponse['alternative_title'] ?? "";
    // add native title to alt_title, ts_sgen_trim will trim spaces, trim commas and removes duplicates
    $array['alt_title'] = ts_sgen_trim($native_title . ", " . $alternative_titles, TRUE);

    return $array;
}, 10, 3);