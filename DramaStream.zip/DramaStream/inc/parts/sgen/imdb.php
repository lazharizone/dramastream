<?php defined("ABSPATH") || die("!");
add_filter("ts-sgen-parsed-data", function($array, $apiResponse, $provider){
    if ($provider !== "imdb") return $array;

    if ( ! $array['type'] && isset($apiResponse['Type'])) {
        if ($apiResponse['Type'] === 'movie') {
            $array['type'] = 'Movie';
        } elseif ($apiResponse['Type'] === 'series') {
            $array['type'] = 'TV Show';
        } elseif ($apiResponse['Type'] === 'episode') {
            $array['type'] = 'TV Episode';
        }
    }
    
    return $array;

},10, 3);