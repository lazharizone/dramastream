<?php defined("ABSPATH") || die("!"); ?>
<?php if (!empty($args['posts'])): ?>
    <div class="slidtop">
        <div class="loop owl-carousel full<?php if (!$args['is_bookmark_enabled'] || ! $args['is_trending_enabled']) echo " notrend";?>">
            <?php while ($args['posts']->have_posts()): $args['posts']->the_post(); ?>
                <div class="slide-item full">
                    <div class="slide-bg">
                        <?php echo GOV_anime::get_post_thumbnail(get_the_ID(), "medium", 205, 145, [
                            'itemprop' => 'image',
                            'title' => get_the_title(),
                            'alt' => get_the_title()
                        ]); ?>
                    </div>
                    <div class="slide-shadow"></div>
                    <div class="slide-content">
                        <div class="poster" style="position:relative">
                            <a href="<?php the_permalink(); ?>">
                                <?php echo GOV_anime::get_post_thumbnail(get_the_ID(), "medium", 205, 145, [
                                    'itemprop' => 'image',
                                    'title' => get_the_title(),
                                    'alt' => get_the_title()
                                ]); ?>
                            </a>
                        </div>
                        <div class="info-left">
                            <div class="title">
                                <span class="ellipsis"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></span>
                                <span class="release-year"><?php echo get_post_meta(get_the_ID(), 'ero_tayang', true); ?></span>
                            </div>
                            <div class="extras">
                                <div class="extra-category"><?php echo get_the_term_list(get_the_ID(), 'genres', '', ', ', ''); ?></div>
                            </div>
                            <div class="excerpt">
                                <span class="title"><?php echo GOV_lang::get('home_slider_summary_label'); ?></span>
                                <p class="story"><?php the_excerpt(); ?></p>
                            </div>
                            <div class="cast">
                                <span class="director"><strong><?php echo GOV_lang::get('series_info_status_label'); ?>:</strong> <?php rwmb_the_value('ero_status'); ?></span>
                                <span class="actor"><strong><?php echo GOV_lang::get('series_info_type_label'); ?>:</strong> <?php rwmb_the_value('ero_type'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
        <?php echo $args['trending_html']; ?>
    </div>
<?php endif; ?>
