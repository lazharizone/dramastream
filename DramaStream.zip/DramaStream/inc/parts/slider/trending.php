<?php defined("ABSPATH") || die("!"); ?>
<?php if (!empty($args['featured_post'])): ?>
    <div class="trending">
        <div class="tdb">
            <a href="<?php echo get_permalink($args['featured_post']->ID); ?>">
                <div class="crown"></div>
                <div class="textbg blxc">
                    <div class="bghover">
                        <span class="numa"><?php echo GOV_lang::get('home_slider_trending_label', ['blogname' => esc_attr(get_bloginfo('name', 'display'))]); ?></span>
                        <span class="numb"><b><?php echo $args['featured_post']->post_title; ?></b></span>
                    </div>
                </div>
                <div class="imgxa">
                    <div class="imgxb" style="background-image: url('<?php echo get_the_post_thumbnail_url($args['featured_post']->ID, 'full'); ?>');"></div>
                </div>
            </a>
        </div>
    </div>
<?php endif; ?>
