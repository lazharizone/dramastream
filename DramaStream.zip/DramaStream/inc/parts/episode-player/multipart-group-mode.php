<?php  if ( ! defined( 'ABSPATH' ) ) { die; } ?>
<div class="gov-multipart">
    <?php foreach ($mirror_data as $hostkey => $host_groups): ?>
        <?php foreach ($host_groups as $group_name => $embeds): ?>
            <div>
                <span class="gov-mr-host"><?php echo htmlspecialchars($hostkey); ?> <?php echo htmlspecialchars($group_name); ?></span>
                <span class="gov-all-host">
                    <?php foreach ($embeds as $embed): ?>
                        <span
                            class="gov-the-embed <?php echo $embed['is_active'] ? 'active' : ''; ?>"
                            data-index="<?php echo esc_attr($embed['index']); ?>"
                            onclick="putMi(this, '<?php echo esc_attr($embed['opt_value']); ?>');"
                        >
                            <?php echo htmlspecialchars($embed['title']); ?>
                        </span>
                    <?php endforeach; ?>
                </span>
            </div>
        <?php endforeach; ?>
    <?php endforeach; ?>
</div>
