<?php  if ( ! defined( 'ABSPATH' ) ) { die; } ?>
<select class="mirror" name="mirror" onchange="loadMi(this);" aria-label="mirror">
    <option value=""><?php echo esc_html($server_label); ?></option>

    <?php foreach ($mirror_options as $option): ?>
        <option value="<?php echo esc_attr($option['value']); ?>" data-index="<?php echo esc_attr($option['index']); ?>"<?php echo $option['selected'] ? ' selected' : ''; ?>>
            <?php echo esc_html($option['label']); ?>
        </option>
    <?php endforeach; ?>
</select>