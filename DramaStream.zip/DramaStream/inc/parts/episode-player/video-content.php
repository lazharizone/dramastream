<?php if ( ! defined( 'ABSPATH' ) ) { die; } ?>
<?php
$rendered = do_shortcode($source);
$trimmed = trim((string)$rendered);
if ((bool)preg_match('~^https?://[^\s<>"\']+$~i',$trimmed) && !(bool)preg_match('~<(iframe|video|embed)\b~i',$trimmed)) {
    $rendered = '<iframe src="'.esc_url($trimmed).'" width="100%" height="100%" frameborder="0" scrolling="no" allow="autoplay; encrypted-media; fullscreen; picture-in-picture" allowfullscreen loading="lazy" referrerpolicy="origin-when-cross-origin"></iframe>';
}
?>
<div id="embed_holder" class="lowvid">
    <div class="player-embed" id="pembed"><?php echo $rendered; ?></div>
</div>
<style>
#pembed{width:100%;height:100%;background:#000;overflow:hidden}
#pembed iframe,#pembed video,#pembed embed{display:block;width:100%;height:100%;border:0}
</style>
