<?php defined('ABSPATH') or die('No script kiddies please!'); 
$compatibilities = TS_Compatibility_Checker_Storage::get_all_sorted_compatibilities();
//removes index "callback" from the array without changing the keys support nested arrays
$compatibilities = array_map(function($array) {
    return array_map(function($item) {
        if ($item['callback']) $item['callback'] = true;
        else $item['callback'] = false;
        return $item;
    }, $array);
}, $compatibilities);

?>
<!DOCTYPE html> 
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>System Compatibility Check</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="System Compatibility Check">
    <meta name="author" content="Themesia">
    <meta name="robots" content="noindex, nofollow">
    <style>
        body {
            background-color: #f2f2f2;
            font-family: Arial, sans-serif;
        }
        h1 {
            color: #333;
            text-align: center;
            margin-top: 30px;
            font-size: 24px;
            text-transform: uppercase;
            letter-spacing: 2px;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
        }
        .group {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .item {
            background-color: #f9f9f9;
            padding: 10px;
            border-radius: 5px;
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }
        .item .status {
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 0.9em;
            margin-right: 10px;
        }
        .item .status.checked {
            background-color: #4caf50;
            color: white;
        }
        .item .status.not-checked {
            background-color: #f44336;
            color: white;
        }
        .item .item-info {
            display: flex;
            flex-direction: column;
            margin-left: 10px;
        }
        .item .item-title {
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
        }
        .item .item-description {
            font-size: 0.8em;
            color: #777;
        }
        .item .item-checked-message {
            visibility: hidden;
            font-size: 0.9em;
            margin-top: 5px;
        }
        .item .item-checked-message.passed {
            color: green;
        }
        .item .item-checked-message.failed {
            color: red;
        }
        .item .item-checked-message.warning {
            color: orange;
        }
        .item .item-checked-message.error{
            color: red;
        }
        #compatibilities {
            display: none;
        }
        #loading {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .status.passed{
            background-color: #4caf50;
            color: white;
        }
        .status.failed{
            background-color: #f44336;
            color: white;
        }
        .status.warning{
            background-color: #ff9800;
            color: white;
        }
        .status.skipped{
            background-color: #2196f3;
            color: white;
        }
        .status.error {
            background-color: #f44336;
            color: white;
        }

        

    </style>
    <script>
        const ajaxUrl = '<?php echo ($ajaxUrl); ?>'; 
        const ajaxNonce = '<?php echo esc_attr($ajaxNonce); ?>'; 
        const pageUrl = '<?php echo ($pageUrl); ?>';
    </script>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.7/dist/loadingoverlay.min.js"></script>
    <script src="<?php echo $scriptUrl; ?>?r=<?php echo time(); ?>"></script>
</head>
<body>
    <h1>Compatibility Check</h1>
        <div id="loading"></div>
        <div id="compatibilities">
            <?php foreach ($compatibilities as $key => $requirement): ?>
                <div class="group <?php echo $key; ?>">
                    <?php foreach($requirement as $req): ?>
                        
                        <div class="item <?php echo $req['name']; ?>">
                            <span class="status not-checked sti-<?php echo $req['name']; ?>">Not Checked</span>
                            <div class="item-info">
                                <span class="item-title"><?php echo $req['title']; ?></span>
                                <span class="item-description"><?php echo $req['description']; ?></span>
                                <span class="item-checked-message icm-<?php echo $req['name']; ?>"></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <script>
        const ts_compatibilities = <?php echo json_encode($compatibilities); ?>;
        const ts_compatibilities_tested = {};
    </script>
</body>
</html>