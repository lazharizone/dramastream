function findCompatibilityByName(name) {
    const compatibilities = ts_compatibilities;
    if (!compatibilities || typeof compatibilities !== 'object') {
        return null;
    }

    for (const category in compatibilities) {
        const requirements = compatibilities[category];
        if (!requirements || typeof requirements !== 'object') {
            continue;
        }

        for (const requirementKey in requirements) {
            const requirement = requirements[requirementKey];
            if (requirement && requirement.name === name) {
                return requirement;
            }
        }
    }

    return null;
}

function getAllCompatibilityNames() {
    const compatibilities = ts_compatibilities;
    const namesSet = new Set();
    for (const category in compatibilities) {
        const requirements = compatibilities[category];
        for (const requirementKey in requirements) {
            const requirement = requirements[requirementKey];
            if (requirement && requirement.name) {
                namesSet.add(requirement.name);
            }
        }
    }
    return Array.from(namesSet);
}

async function testCompatibilityByName(name) {
    //console.log("Testing compatibility: " + name);
    return new Promise(async (resolve, reject) => {
        const compatibilityItem = findCompatibilityByName(name);
        if (!compatibilityItem) {
            reject('Compatibility not found');
            return;
        }
        
        // Check if this compatibility has already been tested
        if (ts_compatibilities_tested[name]) {
            resolve(ts_compatibilities_tested[name]);
            return;
        }

        const dependencies = compatibilityItem.hideif || [];
        const dependencies_logic = compatibilityItem.hideiflogic || 'AND';

        try {
            // Test dependencies first
            let dependencyResults = [];
            for (const dependency of dependencies) {
                const targetCompatibility = findCompatibilityByName(dependency.target);
                if (!targetCompatibility) {
                    reject(`Dependency ${dependency.target} not found`);
                    return;
                }

                // Recursively test dependencies
                const dependencyResult = await testCompatibilityByName(dependency.target);
                ts_compatibilities_tested[dependency.target] = dependencyResult;

                // Check if dependency status matches the specified status in hideif
                const dependencyPassed = dependencyResult.status === dependency.status;
                dependencyResults.push(dependencyPassed);
            }

            if (dependencyResults.length){
                // Evaluate dependency results based on hideiflogic
                let dependencyStatus;
                if (dependencies_logic === 'AND') {
                    dependencyStatus = dependencyResults.every(status => status === true);
                } else if (dependencies_logic === 'OR') {
                    dependencyStatus = dependencyResults.some(status => status === true);
                } else {
                    reject('Invalid hideiflogic specified');
                    return;
                }

                // If any dependency passed, mark compatibility as skipped
                if (dependencyStatus) {
                    ts_compatibilities_tested[name] = { name: name, status: 'skipped' };
                    resolve('skipped');
                    return;
                }
            }

            // Test the compatibility itself
            let compatibilityStatus;
            if (compatibilityItem.callback) {
                const response = await $.post(pageUrl + "&comname=" + name, {
                    action: 'ts_check_compatibility',
                    compatibility: name,
                    ajax_nonce: ajaxNonce
                });
                ts_compatibilities_tested[name] = response;
                compatibilityStatus = response.status;
            } else if (compatibilityItem.js_callback) {
                const result = await window[compatibilityItem.js_callback]();
                ts_compatibilities_tested[name] = result;
                compatibilityStatus = result.status;
            } else {
                // Compatibility doesn't have callback or js_callback 
                ts_compatibilities_tested[name] = { name: name, status: 'error', message: 'No callback or js_callback specified.'};
                compatibilityStatus = 'error';
            }
            resolve(compatibilityStatus);
        } catch (error) {
            console.error(error);
            ts_compatibilities_tested[name] = { name: name, status: 'error', message: 'An error occurred while testing this compatibility.'};
            resolve("error");
        }
    });
}




async function testAllCompatibility() {
    try {
        const compatibilities = getAllCompatibilityNames();
        const results = [];
        const count = compatibilities.length;
        let progress = 0;
        for (const name of compatibilities) {
            const result = await testCompatibilityByName(name);
            results.push({ name: name, status: result });

            progress++;
            const percentage = Math.round(progress / count * 100);
            $('#loading').LoadingOverlay('progress', percentage); // 50% progress
            $('#loading').LoadingOverlay('text', parseInt(percentage) + "%");

            doUpdateHTML(name, result);
        }
        setTimeout(function(){
            $('#loading').LoadingOverlay('hide');
            $("#loading").hide();
            $("#compatibilities").show();
        }, 1000);
        return results;
    } catch (error) {
        throw error;
    }
}

function doUpdateHTML(name, status){
    let compatibilityItem = findCompatibilityByName(name);
    if (!compatibilityItem) {
        return;
    }
    let test_result = ts_compatibilities_tested[name];

    //console.log(test_result);

    var msg_el = jQuery(".item-checked-message.icm-" + name);
    msg_el.addClass(status);
    if (test_result.message) msg_el.html(test_result.message);
    if (status !== 'skipped') msg_el.css('visibility', 'visible');

    var item_info = jQuery(".status.sti-" + name);
    item_info.removeClass('not-checked');
    item_info.addClass(status);
    item_info.html(status.charAt(0).toUpperCase() + status.slice(1));
    
    var item_wrapper = jQuery(".item." + name);
    if (status === 'skipped') item_wrapper.hide();
    

}

async function testWpAjax() {
    return new Promise((resolve, reject) => {
        $.ajax({
            url: ajaxUrl,
            type: 'POST',
            data: {
                action: 'ts_check_wp_ajax_compatibility',
            },
            success: function(response) {
                //check if response is a valid json
                if (typeof response === 'string') {
                    try {
                        response = JSON.parse(response);
                    } catch (error) {
                        resolve({ status: 'error', message: 'Wordpress AJAX is not working properly.' });
                        return;
                    }
                }
                resolve(response);
            },
            error: function(response) {
                resolve({ status: 'error', message: 'An error occurred while testing this compatibility.' });
            }
        });
    });
}


const startLoading = {};
startLoading.init = function() {
    $('#loading').LoadingOverlay("show", {
            text: "0%",
            spinner: "default",
            progress: true,
            background: "rgba(255, 255, 255, 0.5)",
            progressSpeed: 100,
            progressFixedPosition: "top"
        }
    );
    testAllCompatibility();
}

addEventListener('DOMContentLoaded', startLoading.init);

