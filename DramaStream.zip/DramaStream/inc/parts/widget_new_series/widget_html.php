<?php defined("ABSPATH") || die("!");?>
<?php echo $wgns_before_widget; ?>
<?php 
if ( !empty( $wgns_name ) ) { 
    echo $wgns_before_title . $wgns_name . $wgns_after_title; 
};
?>
<?php $wgns_ajax_cache->generate(function() use (&$wgns_total, $wgns_new_series){ ?>
    <div class='serieslist'>
        <ul>
        <?php foreach($wgns_new_series as $k => $v) {
        ?> 
            <li> 
                <div class="imgseries">
                    <a class="series" href="<?php echo $v['link'] ?>" rel="<?php echo $v['ID']; ?>"><?php echo $v['image']; ?></a>
                </div> 
                <div class="leftseries"> 
                    <h4><a class="series" href="<?php echo $v['link'] ?>" rel="<?php echo $v['ID'] ?>"><?php echo $v['title'] ?></a></h4> 
                    <?php echo $v['genres'] ?>
                    <span><?php echo $v['studio'] ?></span> 
                </div> 
            </li> 
        <?php } ?>
        </ul>
    </div>
<?php }); //$ajax_cache->generate ?>
<?php echo $wgns_after_widget; ?>