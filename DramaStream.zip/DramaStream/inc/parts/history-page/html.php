<?php defined("ABSPATH") || die("!"); ?>

<p id="ts-history-header" class="ntf">
    <?php echo GOV_lang::get("history_page_head"); ?>
</p>

<?php if (get_option('ts_enable_browser_history_export_import', 1)) { ?>

    <div id="ts-import-export">
        <div id="imex-notices" style="display:none"><!-- import and export log goes here --></div>
        <div class="ts-history-actons left" style="float:left">
            <button id="export-history" class="btn btn-primary"><?php echo GOV_lang::get('history_export_label'); ?></button>
            <button id="import-history" class="btn btn-primary"><?php echo GOV_lang::get('history_import_label'); ?></button>  
        </div>
        <div class="ts-history-actons right" style="float:right">
            <button id="clear-history" class="btn btn-primary"><?php echo GOV_lang::get('history_wipe_all_label'); ?></button>
        </div>
        <!-- file input to import the history -->
        <div id="import-upload" style="display:none">
            <input type="file" id="ts-history-import-file" accept=".json" />
        </div>
    </div>

<?php } ?>

<div id="history-pool" class="ts-loading"><!-- history html goes here --><div class="ts-loading-spinner"></div></div>

<div id="ts-history-pagination"><!-- pagination area --></div>