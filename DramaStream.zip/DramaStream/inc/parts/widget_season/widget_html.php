<?php defined("ABSPATH") || die("!"); ?>
<?php echo $wgssn_before_widget; ?>
<?php 
if ( ! empty($wgssn_name)) {
    echo $wgssn_before_title . esc_html($wgssn_name) . $wgssn_after_title;
}
?>
<div class='mseason'>
    <ul class='season'>
    <?php
    foreach ($wgssn_terms as $tax_term) { ?>
        <li>
            <a href="<?php echo esc_attr(get_term_link($tax_term, $wgssn_taxonomy)); ?>" title="<?php echo GOV_lang::get('widget_season_link_title', ["season" => esc_attr($tax_term->name)]); ?>">
                <?php echo esc_html($tax_term->name); ?><span><?php echo $tax_term->count; ?></span>
            </a>
        </li>
    <?php } ?>
    </ul>
</div>
<div class='clear'></div>
<?php echo $wgssn_after_widget; ?>