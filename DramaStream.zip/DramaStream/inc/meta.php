<?php

add_filter( 'rwmb_meta_boxes', 'dramastream_register_meta_boxes' );
function dramastream_register_meta_boxes( $meta_boxes )
{
	$prefix = 'ero_';
	$meta_boxes[] = array(
		'id' => 'autogenerateimgcat',
		'title' => __( 'Automatic', 'meta-box' ),
	        'pages' => array( 'series' ),
	        'context' => 'normal',
		'priority' => 'high',
		'autosave' => false,
		'fields' => array(
			array(
				
				'id'   => "{$prefix}autogenerateimgcat",
				'name'  => __( 'Auto Create Featured Image and Category', 'meta-box' ),
				'type' => 'checkbox',
				'std' => 1,
			),
			array(
				'name'  => __( 'Featured Image URL Source', 'meta-box' ),
				'id'    => "{$prefix}image",
				'type'  => 'text',
			),
		)
	);
	$meta_boxes[] = array(
		'id' => 'series',
		'title' => __( 'Series Info', 'meta-box' ),
		'pages' => array( 'series' ),
		'context' => 'normal',
		'priority' => 'high',
		'autosave' => true,
		'fields' => array(
			array(
                'name'  => __( 'Big Cover', 'meta-box' ),
                'id'    => "{$prefix}cover",
                'type'  => 'image_advanced',
				'max_file_uploads' => '1'
            ),
			array(
				'name'     => __( 'Mature Content?', 'meta-box' ),
				'id'       => "{$prefix}mature",
				'type'     => 'select',
				'options'  => array(
					'No' => __( 'No', 'meta-box' ),
					'Yes' => __( 'Yes', 'meta-box' ),
				),
				'multiple'    => false,
				'std'         => 'No',
			),
			array(
				'name'     => __( 'Subbed?', 'meta-box' ),
				'id'       => "{$prefix}sub",
				'type'     => 'select',
				'options'  => array(
					'Sub' => __( 'Sub', 'meta-box' ),
					'Dub' => __( 'Dub', 'meta-box' ),
					'RAW' => __( 'RAW', 'meta-box' ),
				),
				'multiple'    => false,
				'std'         => 'Sub',
			),
			array(
				'name'     => __( 'Hot?', 'meta-box' ),
				'id'       => "{$prefix}hot",
				'type'     => 'select',
				'options'  => array(
					'No' => __( 'No', 'meta-box' ),
					'Yes' => __( 'Yes', 'meta-box' ),
				),
				'multiple'    => false,
				'std'         => 'No',
			),
			array(
				'name'  => __( 'Alternative Title', 'meta-box' ),
				'id'    => "{$prefix}japanese",
				'desc'  => __( 'Input Alternative Title', 'meta-box' ),
				'type'  => 'text',
			),
			array(
				'name'     => __( 'Status', 'meta-box' ),
				'id'       => "{$prefix}status",
				'type'     => 'select',
				'options'  => array(
					'Ongoing' => __( 'Ongoing', 'meta-box' ),
					'Completed' => __( 'Completed', 'meta-box' ),
					'Upcoming' => __( 'Upcoming', 'meta-box' ),
				),
				'multiple'    => false,
				'std'         => 'Ongoing',
			),
			array(
                'name' => __('Censor', 'meta-box'),
                'id' => "{$prefix}censor",
                'type' => 'select',
                'options' => array(
                    'Censored' => __('Censored', 'meta-box'),
                    'Uncensored' => __('Uncensored', 'meta-box'),
                ),
                'multiple' => false,
                'std' => 'Censored'
            ),
			array(
				'name'     => __( 'Type', 'meta-box' ),
				'id'       => "{$prefix}type",
				'type'     => 'select',
				'options'  => array(
					'Drama' => __( 'Drama', 'meta-box' ),
					'TV Show' => __( 'TV Show', 'meta-box' ),
					'Anime' => __( 'Anime', 'meta-box' ),
					'Movie' => __( 'Movie', 'meta-box' ),
					'Special' => __( 'Special', 'meta-box' ),
				),
				'multiple'    => false,
				'std'         => 'Drama',
			),
			array(
				'name'  => __( 'Duration', 'meta-box' ),
				'id'    => "{$prefix}durasi",
				'type'  => 'text',
			),
			array(
				'name'  => __( 'Score', 'meta-box' ),
				'id'    => "{$prefix}skor",
				'type'  => 'text',
			),
			array(
				'name' => __( 'Release Date', 'meta-box' ),
				'id'   => "{$prefix}tayang",
				'type' => 'date',

				'js_options' => array(
					'appendText'      => __( '(M dd, yyyy)', 'meta-box' ),
					'dateFormat'      => __( 'M dd, yy', 'meta-box' ),
					'changeMonth'     => true,
					'changeYear'      => true,
					'showButtonPanel' => true,
				),
			),
			array(
				'name' => __( 'Total Episode', 'meta-box' ),
				'id'   => "{$prefix}episode",
				'type' => 'number',

				'min'  => 0,
				'step' => 1,
			),
			array(
                'name' => __('Trailer', 'meta-box'),
                'id' => "{$prefix}trailer",
                'desc' => __('input trailer ID from youtube,<br/>example: youtube.com/watch?v=DO3rIz7aExU => ID "<b>DO3rIz7aExU</b>"', 'meta-box'),
                'type' => 'text'
            ),
         )
			
	);
	$meta_boxes[] = array(
		'id' => 'galleryarea',
		'title' => __( 'Gallery', 'meta-box' ),
	        'pages' => array( 'series' ),
	        'context' => 'normal',
		'fields' => array(
			array(
				'name' => __( 'Upload', 'meta-box' ),
				'id'   => "{$prefix}gallery",
				'type' => 'image_advanced',
				'force_delete' => false,
				'image_size' => 'thumbnail',
			),
		)
	);
	$meta_boxes[] = array(
		'id' => 'episode',
		'title' => __( 'Episode', 'meta-box' ),
	        'pages' => array( 'post' ),
	        'context' => 'normal',
		'priority' => 'high',
		'autosave' => true,
		'fields' => array(
			array(
				'name'     => __( 'Subbed?', 'meta-box' ),
				'id'       => "{$prefix}subepisode",
				'type'     => 'select',
				'options'  => array(
					'None' => __( 'None', 'meta-box' ),
					'Sub' => __( 'Sub', 'meta-box' ),
					'Dub' => __( 'Dub', 'meta-box' ),
					'RAW' => __( 'RAW', 'meta-box' ),
				),
				'multiple'    => false,
				'std'         => 'None',
			),
			array(
				'name' => __( 'Episode Number', 'meta-box' ),
				'id'   => "{$prefix}episodebaru",
				'desc'  => __( 'Input episode', 'meta-box' ),
				'type' => 'text',
				'required' => 1,
			),
			array(
				'name' => __( 'Episode Title', 'meta-box' ),
				'id'   => "{$prefix}episodetitle",
				'type' => 'text',
			),
			array(
                'name' => __('Download Link', 'meta-box'),
                'id' => "{$prefix}download",
                'desc' => __('Download Link', 'meta-box'),
                'type' => 'url'
            ),
			array(
				'name'    => __( 'Series', 'meta-box' ),
				'id'      => "{$prefix}seri",
				'type'    => 'post',
				'required' => 1,
				'post_type' => 'series',
				'field_type' => 'select_advanced',
				'query_args' => array(
					'post_status'    => 'publish',
					'posts_per_page' => - 1,
					'orderby' => 'title',
					'order' => 'ASC',
				)
			),
		)
	);
	
	$meta_boxes[] = array(
		'id' => 'multipart',
		'title' => __( 'Multipart Mode', 'meta-box' ),
	        'pages' => array( 'post' ),
	        'context' => 'normal',
		'priority' => 'high',
		'autosave' => true,
		'fields' => array(
			array(
				'name'     => __( 'Multipart', 'meta-box' ),
				'id'       => "{$prefix}multipart",
				'type'     => 'select',
				'desc'	   => 'Multipart shortcode generator, <a href="https://themesia.com/tools/shortcode.php" target="_blank" rel="nofollow external noopener noreferrer">click here</a>',
				'options'  => array(
					'no' => __( 'Disable', 'meta-box' ),
					'yes' => __( 'Enable', 'meta-box' ),
				),
				'multiple'    => false,
				'std'         => 'no',
			),
		),
	);
	
	$meta_boxes[] = array(
        'title'  => 'Embed Video',
		'pages' => array( 'post' ),
		'tabs'      => array(
            'input-version' => array(
                'label' => 'Input Version',
                'icon'  => 'dashicons-admin-customizer',
            ),
            'sc-version'  => array(
                'label' => 'Shortcode Version',
                'icon'  => 'dashicons-editor-code',
            ),
        ),
		'tab_style' => 'default',
        'fields' => array(
            array(
                'id'     => 'ab_embedgroup',
                'type'   => 'group',
                'clone'  => true,
				'sort_clone'  => true,
				'save_state' => true,
				'desc' => '<b style="color:red;">You can insert embed code or shortcode</b>',
				'tab'  => 'input-version',
                'fields' => array(
                    array(
                        'name'  => 'Host Name',
                        'id'    => 'ab_hostname',
                        'type'  => 'text',
						'columns' => '2',
                    ),
					array(
                        'name'  => 'Part',
                        'id'    => 'ab_partname',
                        'type'  => 'text',
						'columns' => '2',
                    ),
					array(
                        'name'  => 'Order',
                        'id'    => 'ab_order',
                        'type'  => 'text',
						'columns' => '2',
                    ),
					array(
                        'name'  => 'Title',
                        'id'    => 'ab_title',
                        'type'  => 'text',
						'columns' => '2',
                    ),
                    array(
                        'name'   => 'Embed',
                        'id'     => 'ab_embed',
                        'type'   => 'textarea',
						'columns' => '4',
						'rows' => '5',
						'sanitize_callback' => 'none',
                    ),
                ), //episode
            ), //input-version
			array(
                'name'  => __( 'Shortcode Video', 'meta-box' ),
                'id'    => "{$prefix}embed",
                'type'  => 'textarea',
				'clone' => 'true',
				'sort_clone'  => true,
				'sanitize_callback' => 'none',
				'tab' => 'sc-version',
				'clone_empty_start' => true,
            ),
        ),
    );
	$meta_boxes[] = array(
        'title'  => 'Box Download',
		'pages' => array( 'post' ),
        'fields' => array(
            array(
                'id'     => 'ab_downloadgroup',
                'type'   => 'group',
				'clone'  => true,
				'sort_clone'  => true,
				'save_state' => true,
                'fields' => array(
						array(
							'name'  => 'Hosting Name',
							'id'    => 'ab_hostingname',
							'type'  => 'text',
							'columns' => '3',
						),
						array(
							'name'  => 'Quality',
							'id'    => 'ab_quality',
							'type'  => 'text',
							'columns' => '3',
						),
						array(
							'name'  => 'URL',
							'id'    => 'ab_linkurl',
							'type'  => 'text',
							'columns' => '5',
						),
					),
            ), //input-version
        ),
    );
	$meta_boxes[] = array(
        'title'  => 'Box Download',
		'pages' => array( 'series' ),
		'tabs'      => array(
            'input-version' => array(
                'label' => 'Input Version',
                'icon'  => 'dashicons-admin-customizer',
            ),
            'sc-version'  => array(
                'label' => 'Shortcode Version',
                'icon'  => 'dashicons-editor-code',
            ),
        ),
		'tab_style' => 'default',
        'fields' => array(
            array(
                'id'     => 'ab_downloadgroup',
                'type'   => 'group',
                'clone'  => true,
				'sort_clone'  => true,
				'save_state' => true,
				'tab'  => 'input-version',
                'fields' => array(
						array(
							'name'  => 'Hosting Name',
							'id'    => 'ab_hostingname',
							'type'  => 'text',
							'columns' => '3',
						),
						array(
							'name'  => 'Quality',
							'id'    => 'ab_quality',
							'type'  => 'text',
							'columns' => '3',
						),
						array(
							'name'  => 'URL',
							'id'    => 'ab_linkurl',
							'type'  => 'text',
							'columns' => '5',
						),
				),
            ), //input-version
			array(
                'name'  => __( 'Link Download', 'meta-box' ),
                'id'    => "{$prefix}batch",
                'type'  => 'wysiwyg',
				'tab' => 'sc-version',
            ),
        ),
    );	
	$meta_boxes[] = array(
        'title'  => 'Episode Download',
		'pages' => array( 'post','series' ),
        'fields' => array(
            array(
                'id'     => 'ab_downloadgroup_ep',
                'type'   => 'group',
				'clone'  => true,
				'sort_clone'  => true,
				'collapsible' => true,
				'group_title' => '{ab_eptitle_ep}',
				'save_state' => true,
                'fields' => array(
                    array(
                        'name'  => 'Episode Title',
                        'id'    => 'ab_eptitle_ep',
                        'type'  => 'text',
                    ),
                    array(
                        'name'   => 'Resolution',
                        'id'     => 'ab_resolution_ep',
                        'type'   => 'group',
                        'clone'  => true,
						'sort_clone'  => true,
						'collapsible' => true,
						'group_title' => '{ab_pixel_ep}',
                        'fields' => array(
                            array(
                                'name'  => 'Pixel',
                                'id'    => 'ab_pixel_ep',
                                'type'  => 'text',
                            ),
							array(
								'name'   => 'Download Link',
								'id'     => 'ab_downloadlink_ep',
								'type'   => 'group',
								'clone'  => true,
								'sort_clone'  => true,
								'fields' => array(
									// Normal field (cloned)
									array(
										'name'  => 'Hosting Name',
										'id'    => 'ab_hostingname_ep',
										'type'  => 'text',
									),
									array(
										'name'  => 'URL',
										'id'    => 'ab_linkurl_ep',
										'type'  => 'text',
									),
								),
							),
                        ), //pixel
                    ),
                ), //episode
            ), //input-version
        ),
    );


	$meta_boxes[] = array(
		'id' => 'series_schedule',
		'title' => __( 'Schedule', 'meta-box' ),
	        'pages' => array( 'series' ),
	        'context' => 'normal',
		'priority' => 'high',
		'autosave' => false,
		'fields' => array(
			array(
				'name'     => __( 'Mode', 'meta-box' ),
				'id'       => "{$prefix}schedule_mode",
				'type'     => 'select',
				'options'  => array(
					'auto' => __( 'Auto', 'meta-box' ),
					'interval' => __( 'Interval', 'meta-box' ),
					'manual' => __( 'Manual', 'meta-box' ),
					'off' => __( 'Off', 'meta-box' ),
				),
				'multiple'    => false,
				'std'         => 'auto',			
			),
			array(
				"name" => "Interval (day)",
				'id'   => "{$prefix}schedule_interval",
				'desc'  => __( 'Enter the estimated release of every episode in day(s) after the last release, default (7 days)', 'meta-box' ),
				'type' => 'number',
				'attributes' => array(
					'data-section' => 'schedule',
					'class'        => 'mbsc-interval-value',
				),		
			),
			array(
				"name" => "Select Days",
				'id'   => "{$prefix}schedule_manual",
				'desc'  => __( 'Select the days of this anime will release', 'meta-box' ),
				'type' => 'checkbox_list',
				'options'  => array(
					'mon' => __( 'Monday', 'meta-box' ),
					'tue' => __( 'Tuesday', 'meta-box' ),
					'wed' => __( 'Wednesday', 'meta-box' ),
					'thu' => __( 'Thursday', 'meta-box' ),
					'fri' => __( 'Friday', 'meta-box' ),
					'sat' => __( 'Saturday', 'meta-box' ),
					'sun' => __( 'Sunday', 'meta-box' ),
				),
				'multiple'    => true,
				'inline' => false,
				'attributes' => array(
					'data-section' => 'schedule',
					'class'        => 'mbsc-manual-value',
				),	
			),
		)
	);


	return $meta_boxes;
}