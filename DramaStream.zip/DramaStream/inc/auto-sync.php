<?php
/**
 * Anikoto Real-Time Auto-Publisher & Autonomous Sync Engine for DramaStream Theme
 * Version: 2.0.0
 * 
 * Features:
 * 1. Dedicated Admin Slot ("âš¡ Auto Bot Anikoto") in WordPress dashboard.
 * 2. Ultra-Fast 1-Second Real-Time Monitoring of https://anikototv.to/home.
 * 3. Instant Auto-Publishing of new Episodes and Series as soon as they appear.
 * 4. 100% Zero-Touch Autonomous Operation (runs via Admin poller, visitor heartbeat, and CLI worker).
 * 5. Strict SEO Protection: ZERO source SEO metadata or canonicals from anikototv.to are imported.
 * 6. High-Performance Hash Fingerprinting: sub-150ms verification with zero DB write overhead when idle.
 * 7. MegaPlay VideoJS Stream Embeds: Native support for /videojs/stream/s-2/ endpoints (Zero Error 410).
 * 8. Native DramaStream compatibility: CPT 'series' and CPT 'post', linking via 'ero_seri' and '_anikoto_series_id'.
 */

if (!defined('ABSPATH')) {
    exit;
}

class DramaStream_Auto_Sync {

    const SOURCE_URL          = 'https://anikototv.to/home';
    const OPTION_ENABLED     = 'dramastream_auto_enabled';
    const OPTION_INTERVAL    = 'dramastream_auto_interval';
    const OPTION_LAST_HASH   = 'dramastream_auto_last_hash';
    const OPTION_LAST_CHECK  = 'dramastream_auto_last_check';
    const OPTION_STATS       = 'dramastream_auto_stats';
    const OPTION_LOGS        = 'dramastream_auto_logs';

    public function __construct() {
        // Register Dedicated Admin Menu Slot
        add_action('admin_menu', [$this, 'register_admin_menu']);

        // AJAX Handlers for Live Monitoring and Settings
        add_action('wp_ajax_dramastream_auto_check', [$this, 'ajax_auto_check']);
        add_action('wp_ajax_animestream_auto_check', [$this, 'ajax_auto_check']);

        add_action('wp_ajax_dramastream_auto_save_settings', [$this, 'ajax_save_settings']);
        add_action('wp_ajax_animestream_auto_save_settings', [$this, 'ajax_save_settings']);

        add_action('wp_ajax_dramastream_auto_clear_logs', [$this, 'ajax_clear_logs']);
        add_action('wp_ajax_animestream_auto_clear_logs', [$this, 'ajax_clear_logs']);

        // Non-blocking background heartbeat actions
        add_action('wp_ajax_dramastream_auto_async_heartbeat', [$this, 'ajax_async_heartbeat']);
        add_action('wp_ajax_nopriv_dramastream_auto_async_heartbeat', [$this, 'ajax_async_heartbeat']);

        // Inject non-blocking asynchronous client-side heartbeat on frontend and admin footers (zero PHP visitor latency)
        add_action('wp_footer', [$this, 'render_client_heartbeat_script'], 999);
        add_action('admin_footer', [$this, 'render_client_heartbeat_script'], 999);

        // 24/7 Background WP-Cron schedule
        add_filter('cron_schedules', [$this, 'add_cron_intervals']);
        add_action('dramastream_auto_sync_cron_event', [__CLASS__, 'run_sync_cron']);
        if (!wp_next_scheduled('dramastream_auto_sync_cron_event')) {
            wp_schedule_event(time() + 60, 'every_five_minutes', 'dramastream_auto_sync_cron_event');
        }
    }

    /**
     * Non-blocking background async heartbeat worker
     */
    public function ajax_async_heartbeat() {
        $lockKey = 'dramastream_auto_async_lock';
        if (get_transient($lockKey)) {
            wp_send_json_success(['status' => 'busy']);
        }
        set_transient($lockKey, 1, 60);

        if (function_exists('fastcgi_finish_request')) {
            fastcgi_finish_request();
        }
        @ignore_user_abort(true);
        @set_time_limit(90);
        self::run_sync_check(false);
        delete_transient($lockKey);
        wp_send_json_success(['status' => 'ok']);
    }

    /**
     * Register Cron Intervals
     */
    public function add_cron_intervals($schedules) {
        if (!isset($schedules['every_five_minutes'])) {
            $schedules['every_five_minutes'] = [
                'interval' => 300,
                'display'  => 'Every 5 Minutes (DramaStream Anikoto)'
            ];
        }
        return $schedules;
    }

    /**
     * WP-Cron Background Worker
     */
    public static function run_sync_cron() {
        $enabled = get_option(self::OPTION_ENABLED, get_option('animestream_auto_enabled', '1'));
        if ($enabled !== '1') {
            return;
        }
        self::run_sync_check(false);
    }

    /**
     * Client-Side Non-Intrusive Heartbeat Script
     * Runs 4 seconds AFTER page is fully loaded and only once every 120s per user
     */
    public function render_client_heartbeat_script() {
        $enabled = get_option(self::OPTION_ENABLED, get_option('animestream_auto_enabled', '1'));
        if ($enabled !== '1') {
            return;
        }
        $ajax_url = admin_url('admin-ajax.php');
        $token = wp_hash('ds_async_bg');
        ?>
        <script>
        (function() {
            try {
                var last = parseInt(localStorage.getItem('ds_auto_hb_last') || '0', 10);
                var now = Math.floor(Date.now() / 1000);
                if (now - last < 120) return;

                window.addEventListener('load', function() {
                    setTimeout(function() {
                        localStorage.setItem('ds_auto_hb_last', Math.floor(Date.now() / 1000).toString());
                        if (typeof navigator.sendBeacon === 'function') {
                            var fd = new FormData();
                            fd.append('action', 'dramastream_auto_async_heartbeat');
                            fd.append('token', '<?php echo esc_js($token); ?>');
                            navigator.sendBeacon('<?php echo esc_js($ajax_url); ?>', fd);
                        } else {
                            var xhr = new XMLHttpRequest();
                            xhr.open('POST', '<?php echo esc_js($ajax_url); ?>', true);
                            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                            xhr.send('action=dramastream_auto_async_heartbeat&token=<?php echo esc_js($token); ?>');
                        }
                    }, 4000);
                });
            } catch(e) {}
        })();
        </script>
        <?php
    }

    /**
     * Dedicated Admin Menu Slot: âš¡ Auto Bot Anikoto
     */
    public function register_admin_menu() {
        add_menu_page(
            'Anikoto Auto Publicador en Tiempo Real',
            'âš¡ Auto Bot Anikoto',
            'manage_options',
            'anikoto-auto-sync',
            [$this, 'render_admin_page'],
            'dashicons-update-alt',
            5
        );
    }

    /**
     * Legacy traffic_heartbeat_check (retained for backward compatibility, now instant no-op)
     */
    public function traffic_heartbeat_check() {
        return;
    }

    /**
     * Helper to fetch HTML from anikototv.to with full browser headers
     */
    public static function fetch_page(string $url): string {
        $response = wp_remote_get($url, [
            'timeout'     => 15,
            'redirection' => 5,
            'headers'     => [
                'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
                'Accept'     => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            ]
        ]);

        if (is_wp_error($response)) {
            return '';
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        if ($code < 200 || $code >= 400) {
            return '';
        }

        return wp_remote_retrieve_body($response);
    }

    /**
     * Parse recent updates from https://anikototv.to/home
     */
    public static function parse_recent_updates(string $html): array {
        if (empty($html)) {
            return [];
        }

        $recentSection = '';
        if (preg_match('/<section id="recent-update"[\s\S]*?<\/section>/i', $html, $m)) {
            $recentSection = $m[0];
        }

        if (empty($recentSection)) {
            return [];
        }

        $items = [];
        if (preg_match_all('/<div class="item"[\s\S]*?<\/div>\s*<\/div>\s*<\/div>/i', $recentSection, $matches)) {
            foreach ($matches[0] as $itemHtml) {
                // 1. Episode URL
                $url = '';
                if (preg_match('/href="([^"]+)"/i', $itemHtml, $um)) {
                    $url = esc_url_raw($um[1]);
                }

                // 2. Title
                $title = '';
                if (preg_match('/alt="([^"]+)"/i', $itemHtml, $am)) {
                    $title = html_entity_decode(trim($am[1]), ENT_QUOTES, 'UTF-8');
                }
                if (empty($title) && preg_match('/<a class="name d-title"[^>]*>([^<]+)<\/a>/i', $itemHtml, $tm)) {
                    $title = html_entity_decode(trim($tm[1]), ENT_QUOTES, 'UTF-8');
                }

                // 3. Episode Number
                $epNum = 1;
                if (preg_match('/<span class="ep-status sub"><span>\s*(\d+)<\/span>/i', $itemHtml, $em)) {
                    $epNum = absint($em[1]);
                } elseif (preg_match('/\/ep-(\d+)/i', $url, $em2)) {
                    $epNum = absint($em2[1]);
                }

                // 4. Thumbnail
                $thumb = '';
                if (preg_match('/src="([^"]+)"/i', $itemHtml, $im)) {
                    $thumb = esc_url_raw($im[1]);
                }

                if (!empty($title) && !empty($url)) {
                    $items[] = [
                        'title'         => $title,
                        'episode_num'   => $epNum,
                        'episode_url'   => $url,
                        'thumbnail_url' => $thumb,
                    ];
                }
            }
        }

        return $items;
    }

    /**
     * Core Auto-Publish & Check Engine
     */
    public static function run_sync_check(bool $force = false): array {
        @set_time_limit(60);

        $now = time();
        update_option(self::OPTION_LAST_CHECK, $now);

        $stats = get_option(self::OPTION_STATS, [
            'total_episodes_published' => 0,
            'total_series_published'   => 0,
            'total_checks'             => 0,
            'last_published_title'     => 'Ninguno aÃºn',
            'last_published_time'      => 'AÃºn no registrado',
        ]);
        $stats['total_checks'] = ($stats['total_checks'] ?? 0) + 1;

        // 1. Fetch live HTML from anikototv.to/home
        $html = self::fetch_page(self::SOURCE_URL);
        if (empty($html)) {
            $logEntry = [
                'time'    => current_time('H:i:s'),
                'type'    => 'error',
                'message' => 'Error de conexiÃ³n con anikototv.to/home'
            ];
            self::append_log($logEntry);
            update_option(self::OPTION_STATS, $stats);
            return [
                'status'  => 'error',
                'message' => 'No se pudo conectar con anikototv.to/home',
                'log'     => $logEntry,
                'stats'   => $stats
            ];
        }

        $recentItems = self::parse_recent_updates($html);
        if (empty($recentItems)) {
            update_option(self::OPTION_STATS, $stats);
            return [
                'status'    => 'no_change',
                'message'   => 'Comprobado âš¡ No se detectaron episodios en recent-update.',
                'timestamp' => current_time('H:i:s'),
                'stats'     => $stats,
                'published' => []
            ];
        }

        // 2. High-Performance Fingerprint Hash
        $fingerprint = [];
        foreach ($recentItems as $it) {
            $fingerprint[] = $it['title'] . ':' . $it['episode_num'];
        }
        $currentHash = md5(implode('|', $fingerprint));
        $lastHash    = get_option(self::OPTION_LAST_HASH, '');

        if (!$force && !empty($lastHash) && $lastHash === $currentHash) {
            update_option(self::OPTION_STATS, $stats);
            return [
                'status'    => 'no_change',
                'message'   => 'Comprobado âš¡ Sin novedades en anikototv.to (Ãšltimo hash verificado)',
                'timestamp' => current_time('H:i:s'),
                'stats'     => $stats,
                'published' => []
            ];
        }

        // 3. Updates Detected: Process and Auto-Publish in DramaStream
        global $wpdb;
        $publishedItems = [];
        $baseTime = time();

        // SEO keys to strictly strip from imported posts
        $seo_keys = [
            '_yoast_wpseo_title', '_yoast_wpseo_metadesc', '_yoast_wpseo_focuskw',
            'rank_math_title', 'rank_math_description', 'rank_math_focus_keyword',
            '_aioseo_title', '_aioseo_description', '_aioseo_keywords'
        ];

        foreach ($recentItems as $k => $item) {
            $title = sanitize_text_field($item['title']);
            $epNum = absint($item['episode_num']);
            $epUrl = esc_url_raw($item['episode_url']);
            $thumb = esc_url_raw($item['thumbnail_url']);

            // Exact descending timestamps so index 0 is freshest on top
            $epTime = $baseTime - ($k * 60);
            $epDate = gmdate('Y-m-d H:i:s', $epTime + (get_option('gmt_offset') * 3600));
            $epDateGmt = gmdate('Y-m-d H:i:s', $epTime);

            // Extract Series slug from episode URL (e.g. /watch/solo-leveling/ep-12)
            $seriesSlug = '';
            if (preg_match('~/watch/([^/?#]+)~i', $epUrl, $sm)) {
                $seriesSlug = sanitize_title($sm[1]);
            }
            if (!$seriesSlug) {
                $seriesSlug = sanitize_title($title);
            }

            // A) Find or create parent Series (In DramaStream: CPT 'series')
            $existing_series = get_posts([
                'post_type'      => 'series',
                'post_status'    => 'any',
                'posts_per_page' => 1,
                'title'          => $title,
            ]);

            if (empty($existing_series) && $seriesSlug) {
                $existing_series = get_posts([
                    'post_type'      => 'series',
                    'post_status'    => 'any',
                    'posts_per_page' => 1,
                    'name'           => $seriesSlug,
                ]);
            }

            if (empty($existing_series)) {
                $existing_series = get_posts([
                    'post_type'      => 'series',
                    'post_status'    => 'any',
                    'posts_per_page' => 1,
                    'meta_key'       => '_anikoto_slug',
                    'meta_value'     => $seriesSlug,
                ]);
            }

            if (empty($existing_series)) {
                $series_id = wp_insert_post([
                    'post_title'        => $title,
                    'post_name'         => $seriesSlug,
                    'post_status'       => 'publish',
                    'post_type'         => 'series',
                    'post_date'         => $epDate,
                    'post_date_gmt'     => $epDateGmt,
                    'post_modified'     => $epDate,
                    'post_modified_gmt' => $epDateGmt,
                ]);

                if ($series_id && !is_wp_error($series_id)) {
                    update_post_meta($series_id, 'ero_type', 'TV');
                    update_post_meta($series_id, 'ero_status', 'Ongoing');
                    update_post_meta($series_id, 'ero_episode', $epNum);
                    update_post_meta($series_id, '_anikoto_series_title', $title);
                    update_post_meta($series_id, '_anikoto_slug', $seriesSlug);

                    if ($thumb) {
                        update_post_meta($series_id, '_anikoto_poster_url', $thumb);
                        if (function_exists('ak_set_image')) {
                            $att = ak_set_image($series_id, $thumb, $title);
                            if ($att) {
                                if (function_exists('ak_auto_set_big_cover')) {
                                    ak_auto_set_big_cover($series_id, $att);
                                }
                                update_post_meta($series_id, 'ero_cover', [$att]);
                                update_post_meta($series_id, 'ero_image', [$att]);
                            }
                        }
                    }

                    foreach ($seo_keys as $sk) {
                        delete_post_meta($series_id, $sk);
                    }
                    if (function_exists('dramastream_ensure_series_category')) {
                        dramastream_ensure_series_category($title, $series_id);
                    }
                    $stats['total_series_published']++;
                }
            } else {
                $series_id = (int) $existing_series[0]->ID;
                // Update modified date so it reflects latest position on homepage
                $wpdb->update(
                    $wpdb->posts,
                    ['post_modified' => $epDate, 'post_modified_gmt' => $epDateGmt],
                    ['ID' => $series_id],
                    ['%s', '%s'],
                    ['%d']
                );
                $currTotal = (int) get_post_meta($series_id, 'ero_episode', true);
                if ($epNum > $currTotal) {
                    update_post_meta($series_id, 'ero_episode', $epNum);
                }

                if (!has_post_thumbnail($series_id) && $thumb && function_exists('ak_set_image')) {
                    $att = ak_set_image($series_id, $thumb, $title);
                    if ($att && function_exists('ak_auto_set_big_cover')) {
                        ak_auto_set_big_cover($series_id, $att);
                    }
                }
            }

            if (!$series_id || is_wp_error($series_id)) {
                continue;
            }

            // B) Find or create Episode (In DramaStream: CPT 'post' linked via 'ero_seri' and '_anikoto_series_id')
            $existing_ep = get_posts([
                'post_type'      => 'post',
                'post_status'    => 'any',
                'posts_per_page' => 1,
                'meta_query'     => [
                    'relation' => 'AND',
                    [
                        'relation' => 'OR',
                        ['key' => 'ero_seri', 'value' => $series_id, 'compare' => '='],
                        ['key' => '_anikoto_series_id', 'value' => $series_id, 'compare' => '='],
                    ],
                    [
                        'relation' => 'OR',
                        ['key' => 'ero_episodebaru', 'value' => (string)$epNum, 'compare' => '='],
                        ['key' => '_anikoto_episode_number', 'value' => (string)$epNum, 'compare' => '='],
                    ]
                ],
                'fields' => 'ids',
            ]);

            if (empty($existing_ep)) {
                // NEW EPISODE FOUND -> AUTO-PUBLISH
                $ep_title = sprintf('%s Episode %d', $title, $epNum);
                $ep_id = wp_insert_post([
                    'post_title'     => $ep_title,
                    'post_name'      => sanitize_title($seriesSlug . '-episode-' . $epNum),
                    'post_status'    => 'publish',
                    'post_type'      => 'post',
                    'post_date'      => $epDate,
                    'post_date_gmt'  => $epDateGmt,
                ]);

                if ($ep_id && !is_wp_error($ep_id)) {
                    update_post_meta($ep_id, 'ero_seri', $series_id);
                    update_post_meta($ep_id, 'ero_episodebaru', (string)$epNum);
                    update_post_meta($ep_id, 'ero_episodetitle', 'Episode ' . $epNum);
                    update_post_meta($ep_id, 'ero_subepisode', 'Sub');
                    update_post_meta($ep_id, '_anikoto_series_id', $series_id);
                    update_post_meta($ep_id, '_anikoto_series_title', $title);
                    update_post_meta($ep_id, '_anikoto_episode_number', (string)$epNum);
                    if ($epUrl) {
                        update_post_meta($ep_id, '_anikoto_source_url', $epUrl);
                    }
                    if (has_post_thumbnail($series_id)) {
                        set_post_thumbnail($ep_id, get_post_thumbnail_id($series_id));
                    }
                    foreach ($seo_keys as $sk) {
                        delete_post_meta($ep_id, $sk);
                    }

                    // Auto-assign anime name category to episode
                    if (function_exists('dramastream_ensure_series_category')) {
                        dramastream_ensure_series_category($title, $ep_id);
                    }

                    // Update parent series latest pointers
                    update_post_meta($series_id, 'ero_latest', (string)$epNum);
                    update_post_meta($series_id, 'ero_latestid', $ep_id);

                    // Resolve and set video player embed with VideoJS stream
                    if (function_exists('dramastream_lazy_repair_episode_player')) {
                        dramastream_lazy_repair_episode_player($ep_id);
                    } elseif (function_exists('animestream_lazy_repair_episode_player')) {
                        animestream_lazy_repair_episode_player($ep_id);
                    }

                    $stats['total_episodes_published']++;
                    $stats['last_published_title'] = $ep_title;
                    $stats['last_published_time']  = current_time('H:i:s d/m/Y');

                    $publishedItems[] = [
                        'type'    => 'episode',
                        'title'   => $ep_title,
                        'url'     => get_permalink($ep_id),
                        'post_id' => $ep_id,
                        'ep_num'  => $epNum
                    ];

                    self::append_log([
                        'time'    => current_time('H:i:s'),
                        'type'    => 'published',
                        'message' => "âš¡ AUTO-PUBLICADO NUEVO EPISODIO: {$ep_title} [ID: {$ep_id}]"
                    ]);
                }
            } else {
                // Episode already in DB: update its date so order stays aligned
                $existing_ep_id = (int) $existing_ep[0];
                $wpdb->update(
                    $wpdb->posts,
                    ['post_date' => $epDate, 'post_date_gmt' => $epDateGmt],
                    ['ID' => $existing_ep_id],
                    ['%s', '%s'],
                    ['%d']
                );

                // Auto-repair player embed if missing or legacy /stream/s-2/
                $curr_embed = get_post_meta($existing_ep_id, '_anikoto_iframe_url', true);
                if (empty($curr_embed) || strpos($curr_embed, 'megaplay.buzz/stream/s-2/') !== false) {
                    if (function_exists('dramastream_lazy_repair_episode_player')) {
                        dramastream_lazy_repair_episode_player($existing_ep_id);
                    }
                }
            }
        }

        // Auto-heal any older episodes in database with legacy /stream/s-2/ embeds
        $broken_meta = $wpdb->get_col("
            SELECT post_id FROM {$wpdb->postmeta} 
            WHERE meta_key = '_anikoto_iframe_url' 
              AND meta_value LIKE '%megaplay.buzz/stream/s-2/%' 
            LIMIT 50
        ");
        if (!empty($broken_meta)) {
            foreach ($broken_meta as $b_id) {
                if (function_exists('dramastream_lazy_repair_episode_player')) {
                    dramastream_lazy_repair_episode_player((int)$b_id);
                }
            }
        }

        // 4. Update hash and stats
        update_option(self::OPTION_LAST_HASH, $currentHash);
        update_option(self::OPTION_STATS, $stats);

        $countPublished = count($publishedItems);
        $summaryMsg = ($countPublished > 0)
            ? "Â¡Ã‰xito! Se han auto-publicado {$countPublished} nuevo(s) episodio(s) al instante."
            : "ComprobaciÃ³n completada: Base de datos al dÃ­a con anikototv.to.";

        return [
            'status'    => ($countPublished > 0) ? 'updated' : 'no_change',
            'message'   => $summaryMsg,
            'timestamp' => current_time('H:i:s'),
            'stats'     => $stats,
            'published' => $publishedItems
        ];
    }

    /**
     * Store and rotate live log entries (keeps last 60 entries)
     */
    public static function append_log(array $entry) {
        $logs = get_option(self::OPTION_LOGS, []);
        if (!is_array($logs)) {
            $logs = [];
        }
        array_unshift($logs, $entry);
        if (count($logs) > 60) {
            $logs = array_slice($logs, 0, 60);
        }
        update_option(self::OPTION_LOGS, $logs);
    }

    /**
     * AJAX: Live Check Endpoint
     */
    public function ajax_auto_check() {
        if (!check_ajax_referer('dramastream_auto_nonce', 'nonce', false) && !check_ajax_referer('animestream_auto_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => 'Nonce invÃ¡lido']);
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permisos insuficientes']);
        }

        $force = !empty($_POST['force']);
        $result = self::run_sync_check($force);

        wp_send_json_success($result);
    }

    /**
     * AJAX: Save Settings
     */
    public function ajax_save_settings() {
        if (!check_ajax_referer('dramastream_auto_nonce', 'nonce', false) && !check_ajax_referer('animestream_auto_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => 'Nonce invÃ¡lido']);
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permisos insuficientes']);
        }

        $enabled  = !empty($_POST['enabled']) && $_POST['enabled'] === '1' ? '1' : '0';
        $interval = max(1, absint($_POST['interval'] ?? 1));

        update_option(self::OPTION_ENABLED, $enabled);
        update_option('animestream_auto_enabled', $enabled);

        update_option(self::OPTION_INTERVAL, $interval);
        update_option('animestream_auto_interval', $interval);

        wp_send_json_success([
            'message'  => 'ConfiguraciÃ³n guardada correctamente.',
            'enabled'  => $enabled,
            'interval' => $interval
        ]);
    }

    /**
     * AJAX: Clear Logs
     */
    public function ajax_clear_logs() {
        if (!check_ajax_referer('dramastream_auto_nonce', 'nonce', false) && !check_ajax_referer('animestream_auto_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => 'Nonce invÃ¡lido']);
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permisos insuficientes']);
        }

        update_option(self::OPTION_LOGS, []);
        wp_send_json_success(['message' => 'Logs limpiados con Ã©xito.']);
    }

    /**
     * Render Modern Real-Time Dashboard
     */
    public function render_admin_page() {
        $enabled  = get_option(self::OPTION_ENABLED, get_option('animestream_auto_enabled', '1')) === '1';
        $interval = (int) get_option(self::OPTION_INTERVAL, get_option('animestream_auto_interval', 1));
        $stats    = get_option(self::OPTION_STATS, [
            'total_episodes_published' => 0,
            'total_series_published'   => 0,
            'total_checks'             => 0,
            'last_published_title'     => 'Ninguno aÃºn',
            'last_published_time'      => 'AÃºn no registrado',
        ]);
        $logs = get_option(self::OPTION_LOGS, []);
        $workerScriptPath = get_template_directory() . '/auto-sync-worker.php';
        $nonce = wp_create_nonce('dramastream_auto_nonce');
        ?>
        <div class="wrap dramastream-auto-admin-wrap" style="max-width: 1040px; margin-top: 1.75rem; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
            
            <!-- Main Container -->
            <div style="background: #0e1013; color: #f1f5f9; border-radius: 0.65rem; padding: 2rem 2.25rem; border: 1px solid #23252a; box-shadow: 0 8px 32px rgba(0,0,0,0.6); border-left: 5px solid #d7385e;">
                
                <!-- Header -->
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 1.75rem; border-bottom: 1px solid #23252a; padding-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
                    <div>
                        <div style="display: flex; align-items: center; gap: 0.75rem;">
                            <span style="font-size: 2rem;">âš¡</span>
                            <h1 style="color: #ffffff; margin: 0; font-size: 1.85rem; font-weight: 800; letter-spacing: -0.02em;">
                                Anikoto <span style="color: #d7385e;">Auto Bot</span> en Tiempo Real
                            </h1>
                        </div>
                        <p style="margin: 0.4rem 0 0 2.75rem; color: #8c9094; font-size: 0.92rem;">
                            Monitoreo continuo y auto-publicaciÃ³n instantÃ¡nea de episodios y series en DramaStream desde <code style="color: #d7385e;">https://anikototv.to/home</code> sin alterar tu SEO.
                        </p>
                    </div>

                    <!-- Live Status Badge -->
                    <div style="display: flex; align-items: center; gap: 0.85rem;">
                        <div id="auto-status-indicator" style="display: inline-flex; align-items: center; gap: 0.55rem; padding: 0.55rem 1.15rem; border-radius: 9999px; font-weight: 800; font-size: 0.88rem; background: <?php echo $enabled ? 'rgba(215,56,94,0.15)' : 'rgba(239,68,68,0.15)'; ?>; color: <?php echo $enabled ? '#d7385e' : '#ef4444'; ?>; border: 1px solid <?php echo $enabled ? '#d7385e' : '#ef4444'; ?>;">
                            <span class="status-dot" style="width: 10px; height: 10px; border-radius: 50%; background: <?php echo $enabled ? '#d7385e' : '#ef4444'; ?>; display: inline-block; animation: pulseDot 1.5s infinite;"></span>
                            <span id="auto-status-text"><?php echo $enabled ? 'ACTIVO (MONITOREANDO)' : 'PAUSADO'; ?></span>
                        </div>
                    </div>
                </div>

                <!-- Stats Dashboard Grid -->
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 1rem; margin-bottom: 2rem;">
                    
                    <div style="background: #121417; border: 1px solid #23252a; border-radius: 0.5rem; padding: 1.25rem;">
                        <span style="display: block; font-size: 0.82rem; color: #8c9094; text-transform: uppercase; font-weight: 700; letter-spacing: 0.05em; margin-bottom: 0.4rem;">Episodios Auto-publicados</span>
                        <div id="stat-episodes" style="font-size: 2rem; font-weight: 900; color: #d7385e;"><?php echo esc_html($stats['total_episodes_published'] ?? 0); ?></div>
                        <span style="font-size: 0.78rem; color: #64748b;">PublicaciÃ³n 100% automÃ¡tica</span>
                    </div>

                    <div style="background: #121417; border: 1px solid #23252a; border-radius: 0.5rem; padding: 1.25rem;">
                        <span style="display: block; font-size: 0.82rem; color: #8c9094; text-transform: uppercase; font-weight: 700; letter-spacing: 0.05em; margin-bottom: 0.4rem;">Series Auto-publicadas</span>
                        <div id="stat-series" style="font-size: 2rem; font-weight: 900; color: #0dcaf0;"><?php echo esc_html($stats['total_series_published'] ?? 0); ?></div>
                        <span style="font-size: 0.78rem; color: #64748b;">Series y Portadas creadas</span>
                    </div>

                    <div style="background: #121417; border: 1px solid #23252a; border-radius: 0.5rem; padding: 1.25rem;">
                        <span style="display: block; font-size: 0.82rem; color: #8c9094; text-transform: uppercase; font-weight: 700; letter-spacing: 0.05em; margin-bottom: 0.4rem;">Comprobaciones en Vivo</span>
                        <div id="stat-checks" style="font-size: 2rem; font-weight: 900; color: #f1f5f9;"><?php echo esc_html($stats['total_checks'] ?? 0); ?></div>
                        <span id="stat-last-time" style="font-size: 0.78rem; color: #64748b;">Ãšltima: hace instantes</span>
                    </div>

                    <div style="background: #121417; border: 1px solid #23252a; border-radius: 0.5rem; padding: 1.25rem;">
                        <span style="display: block; font-size: 0.82rem; color: #8c9094; text-transform: uppercase; font-weight: 700; letter-spacing: 0.05em; margin-bottom: 0.4rem;">Ãšltimo Post Publicado</span>
                        <div id="stat-last-title" style="font-size: 0.95rem; font-weight: 700; color: #ffffff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="<?php echo esc_attr($stats['last_published_title'] ?? 'Ninguno aÃºn'); ?>">
                            <?php echo esc_html($stats['last_published_title'] ?? 'Ninguno aÃºn'); ?>
                        </div>
                        <span id="stat-last-pub-time" style="font-size: 0.78rem; color: #64748b;"><?php echo esc_html($stats['last_published_time'] ?? '-'); ?></span>
                    </div>
                </div>

                <!-- Controls & Live Configuration Card -->
                <div style="background: #121417; border: 1px solid #23252a; border-radius: 0.5rem; padding: 1.5rem; margin-bottom: 2rem;">
                    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem; margin-bottom: 1.25rem; border-bottom: 1px solid #1a1c21; padding-bottom: 1.25rem;">
                        <div>
                            <h3 style="color: #ffffff; margin: 0 0 0.3rem 0; font-size: 1.15rem; font-weight: 800;">
                                Panel de Control del Bot
                            </h3>
                            <p style="margin: 0; color: #8c9094; font-size: 0.86rem;">
                                Ajusta la velocidad de sondeo y activa o pausa la auto-publicaciÃ³n con 1 clic.
                            </p>
                        </div>

                        <!-- Action Buttons -->
                        <div style="display: flex; gap: 0.75rem;">
                            <button type="button" id="btn-manual-check" 
                                    style="background: #0dcaf0; color: #0e1013; border: none; font-weight: 800; padding: 0.7rem 1.35rem; border-radius: 0.4rem; cursor: pointer; font-size: 0.9rem; display: inline-flex; align-items: center; gap: 0.5rem; transition: opacity 0.2s;">
                                <span>ðŸš€ Comprobar Ahora (Manual)</span>
                            </button>

                            <button type="button" id="btn-toggle-auto"
                                    data-active="<?php echo $enabled ? '1' : '0'; ?>"
                                    style="background: <?php echo $enabled ? '#ef4444' : '#d7385e'; ?>; color: #ffffff; border: none; font-weight: 800; padding: 0.7rem 1.35rem; border-radius: 0.4rem; cursor: pointer; font-size: 0.9rem; display: inline-flex; align-items: center; gap: 0.5rem; transition: opacity 0.2s;">
                                <span id="toggle-btn-label"><?php echo $enabled ? 'â¸ï¸ Pausar Bot' : 'â–¶ï¸ Activar Bot'; ?></span>
                            </button>
                        </div>
                    </div>

                    <!-- Poller Interval Selector Form -->
                    <form id="auto-sync-settings-form" style="display: flex; align-items: center; gap: 1.25rem; flex-wrap: wrap;">
                        <label for="auto_interval_select" style="font-size: 0.88rem; color: #cbd5e1; font-weight: 600;">
                            Intervalo de ComprobaciÃ³n en Vivo:
                        </label>
                        <select id="auto_interval_select" name="interval" 
                                style="background: #090a0d; color: #f1f5f9; border: 1px solid #23252a; padding: 0.5rem 0.85rem; border-radius: 0.35rem; font-size: 0.88rem; font-weight: 700; cursor: pointer;">
                            <option value="1" <?php selected($interval, 1); ?>>âš¡ 1 Segundo (Tiempo Real InstantÃ¡neo)</option>
                            <option value="2" <?php selected($interval, 2); ?>>âš¡ 2 Segundos</option>
                            <option value="5" <?php selected($interval, 5); ?>>âš¡ 5 Segundos</option>
                            <option value="10" <?php selected($interval, 10); ?>>âš¡ 10 Segundos</option>
                            <option value="30" <?php selected($interval, 30); ?>>â±ï¸ 30 Segundos</option>
                            <option value="60" <?php selected($interval, 60); ?>>â±ï¸ 1 Minuto</option>
                        </select>

                        <button type="submit" id="btn-save-settings" 
                                style="background: #22c55e; color: #0e1013; border: none; font-weight: 800; padding: 0.55rem 1.15rem; border-radius: 0.35rem; cursor: pointer; font-size: 0.85rem;">
                            ðŸ’¾ Guardar Cambios
                        </button>
                    </form>
                </div>

                <!-- Live Terminal Console Box -->
                <div style="background: #090a0d; border: 1px solid #1a1c21; border-radius: 0.5rem; padding: 1.25rem; margin-bottom: 2rem;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.85rem; border-bottom: 1px solid #14171d; padding-bottom: 0.65rem;">
                        <div style="display: flex; align-items: center; gap: 0.5rem;">
                            <span style="width: 12px; height: 12px; border-radius: 50%; background: #ef4444; display: inline-block;"></span>
                            <span style="width: 12px; height: 12px; border-radius: 50%; background: #eab308; display: inline-block;"></span>
                            <span style="width: 12px; height: 12px; border-radius: 50%; background: #22c55e; display: inline-block;"></span>
                            <strong style="color: #8c9094; font-size: 0.86rem; font-family: monospace; margin-left: 0.5rem;">
                                CONSOLA DE MONITOREO EN VIVO (ANIKOTO RECENT-UPDATE)
                            </strong>
                        </div>
                        <button type="button" id="btn-clear-terminal" 
                                style="background: transparent; border: 1px solid #23252a; color: #8c9094; font-size: 0.78rem; padding: 0.25rem 0.65rem; border-radius: 0.35rem; cursor: pointer;">
                            Limpiar Logs
                        </button>
                    </div>

                    <div id="terminal-screen" style="max-height: 240px; min-height: 160px; overflow-y: auto; font-family: 'Consolas', 'Monaco', monospace; font-size: 0.82rem; line-height: 1.6; color: #cbd5e1; padding: 0.4rem 0;">
                        <?php if (empty($logs)): ?>
                            <div class="term-line" style="color: #64748b;">[<?php echo esc_html(current_time('H:i:s')); ?>] ðŸ¤– Bot inicializado. Conectado a anikototv.to/home...</div>
                        <?php else: ?>
                            <?php foreach ($logs as $l): ?>
                                <?php
                                $color = '#8c9094';
                                if ($l['type'] === 'published') $color = '#d7385e; font-weight: bold;';
                                elseif ($l['type'] === 'error') $color = '#ef4444;';
                                elseif ($l['type'] === 'info') $color = '#0dcaf0;';
                                ?>
                                <div class="term-line" style="color: <?php echo $color; ?>;">
                                    [<?php echo esc_html($l['time'] ?? ''); ?>] <?php echo esc_html($l['message'] ?? ''); ?>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Autonomous 24/7 Server Runner Details -->
                <div style="background: #121417; border-radius: 0.5rem; padding: 1.25rem 1.5rem; border: 1px solid #23252a;">
                    <div style="display: flex; align-items: flex-start; gap: 0.85rem;">
                        <span style="font-size: 1.6rem; line-height: 1;">ðŸ“»</span>
                        <div>
                            <strong style="color: #d7385e; font-size: 0.95rem; display: block; margin-bottom: 0.35rem;">
                                Â¿CÃ³mo funciona de forma 100% autÃ³noma sin que tengas que hacer nada?
                            </strong>
                            <p style="margin: 0 0 0.75rem 0; font-size: 0.85rem; color: #8c9094; line-height: 1.55;">
                                1. <strong>Modo Visitas AutomÃ¡ticas (Heartbeat):</strong> Cada vez que cualquier usuario entra a tu web, el sistema verifica en segundo plano si han pasado los segundos configurados y publica cualquier novedad al instante.<br>
                                2. <strong>Modo PestaÃ±a Abierta:</strong> Mientras tengas esta pÃ¡gina abierta, el navegador comprueba cada <strong>1 segundo</strong> en tiempo real con latencia de ~100ms.<br>
                                3. <strong>Modo Servidor 24/7 (Cron / CLI independiente opcional):</strong> Si deseas que funcione continuamente incluso sin visitas ni navegadores abiertos, puedes aÃ±adir esta lÃ­nea en el Cron de tu cPanel o VPS:
                            </p>
                            <div style="background: #090a0d; border-radius: 0.35rem; padding: 0.65rem 0.95rem; font-family: monospace; font-size: 0.82rem; color: #0dcaf0; border: 1px solid #1a1c21; word-break: break-all; user-select: all;">
                                * * * * * php "<?php echo esc_html($workerScriptPath); ?>" > /dev/null 2>&1
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <style>
            @keyframes pulseDot {
                0% { opacity: 1; transform: scale(1); }
                50% { opacity: 0.4; transform: scale(0.85); }
                100% { opacity: 1; transform: scale(1); }
            }
            #terminal-screen::-webkit-scrollbar {
                width: 6px;
            }
            #terminal-screen::-webkit-scrollbar-thumb {
                background: #23252a;
                border-radius: 9999px;
            }
        </style>

        <script>
        (function() {
            var ajaxUrl = "<?php echo esc_url(admin_url('admin-ajax.php')); ?>";
            var nonce   = "<?php echo esc_js($nonce); ?>";
            var isEnabled = <?php echo $enabled ? 'true' : 'false'; ?>;
            var intervalSeconds = <?php echo max(1, $interval); ?>;
            var isPolling = false;
            var pollTimer = null;

            // DOM Elements
            var $statusIndicator = document.getElementById('auto-status-indicator');
            var $statusText      = document.getElementById('auto-status-text');
            var $toggleBtn       = document.getElementById('btn-toggle-auto');
            var $toggleBtnLabel  = document.getElementById('toggle-btn-label');
            var $manualCheckBtn  = document.getElementById('btn-manual-check');
            var $settingsForm    = document.getElementById('auto-sync-settings-form');
            var $saveSettingsBtn = document.getElementById('btn-save-settings');
            var $clearTermBtn    = document.getElementById('btn-clear-terminal');
            var $termScreen      = document.getElementById('terminal-screen');
            var $statEpisodes    = document.getElementById('stat-episodes');
            var $statSeries      = document.getElementById('stat-series');
            var $statChecks      = document.getElementById('stat-checks');
            var $statLastTime    = document.getElementById('stat-last-time');
            var $statLastTitle   = document.getElementById('stat-last-title');
            var $statLastPubTime = document.getElementById('stat-last-pub-time');
            var $intervalSelect  = document.getElementById('auto_interval_select');

            function playNotificationSound() {
                try {
                    var AudioContext = window.AudioContext || window.webkitAudioContext;
                    if (!AudioContext) return;
                    var ctx = new AudioContext();
                    var osc = ctx.createOscillator();
                    var gain = ctx.createGain();
                    osc.type = 'sine';
                    osc.frequency.setValueAtTime(587.33, ctx.currentTime);
                    osc.frequency.setValueAtTime(880, ctx.currentTime + 0.1);
                    gain.gain.setValueAtTime(0.15, ctx.currentTime);
                    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.35);
                    osc.connect(gain);
                    gain.connect(ctx.destination);
                    osc.start();
                    osc.stop(ctx.currentTime + 0.35);
                } catch(e) {}
            }

            function logToTerminal(message, type) {
                var d = new Date();
                var time = String(d.getHours()).padStart(2,'0') + ':' + String(d.getMinutes()).padStart(2,'0') + ':' + String(d.getSeconds()).padStart(2,'0');
                var line = document.createElement('div');
                line.className = 'term-line';
                var color = '#cbd5e1';
                if (type === 'published') color = '#d7385e; font-weight: bold;';
                else if (type === 'error') color = '#ef4444;';
                else if (type === 'warn') color = '#eab308;';
                else if (type === 'info') color = '#0dcaf0;';
                else if (type === 'success') color = '#22c55e;';

                line.style.cssText = 'color: ' + color + ';';
                line.innerHTML = '[' + time + '] ' + message;
                $termScreen.appendChild(line);
                $termScreen.scrollTop = $termScreen.scrollHeight;
            }

            function updateStats(stats) {
                if (!stats) return;
                if (stats.total_episodes_published !== undefined && $statEpisodes) {
                    $statEpisodes.textContent = stats.total_episodes_published;
                }
                if (stats.total_series_published !== undefined && $statSeries) {
                    $statSeries.textContent = stats.total_series_published;
                }
                if (stats.total_checks !== undefined && $statChecks) {
                    $statChecks.textContent = stats.total_checks;
                }
                if (stats.last_published_title && $statLastTitle) {
                    $statLastTitle.textContent = stats.last_published_title;
                    $statLastTitle.title = stats.last_published_title;
                }
                if (stats.last_published_time && $statLastPubTime) {
                    $statLastPubTime.textContent = stats.last_published_time;
                }
                if ($statLastTime) {
                    $statLastTime.textContent = 'Ãšltima: ' + (new Date()).toLocaleTimeString();
                }
            }

            function updateStatusUI(active) {
                isEnabled = active;
                if (active) {
                    $statusIndicator.style.background = 'rgba(215,56,94,0.15)';
                    $statusIndicator.style.color = '#d7385e';
                    $statusIndicator.style.borderColor = '#d7385e';
                    $statusIndicator.querySelector('.status-dot').style.background = '#d7385e';
                    $statusText.textContent = 'ACTIVO (MONITOREANDO)';
                    $toggleBtn.style.background = '#ef4444';
                    $toggleBtn.style.color = '#ffffff';
                    $toggleBtnLabel.textContent = 'â¸ï¸ Pausar Bot';
                } else {
                    $statusIndicator.style.background = 'rgba(239,68,68,0.15)';
                    $statusIndicator.style.color = '#ef4444';
                    $statusIndicator.style.borderColor = '#ef4444';
                    $statusIndicator.querySelector('.status-dot').style.background = '#ef4444';
                    $statusText.textContent = 'PAUSADO';
                    $toggleBtn.style.background = '#d7385e';
                    $toggleBtn.style.color = '#ffffff';
                    $toggleBtnLabel.textContent = 'â–¶ï¸ Activar Bot';
                }
            }

            function performCheck(force) {
                if (isPolling) return;
                isPolling = true;

                var data = new FormData();
                data.append('action', 'dramastream_auto_check');
                data.append('nonce', nonce);
                data.append('force', force ? '1' : '0');

                fetch(ajaxUrl, {
                    method: 'POST',
                    body: data
                })
                .then(function(r) { return r.json(); })
                .then(function(res) {
                    if (res && res.success && res.data) {
                        var d = res.data;
                        updateStats(d.stats);

                        if (d.published && d.published.length > 0) {
                            playNotificationSound();
                            d.published.forEach(function(item) {
                                logToTerminal('âš¡ Â¡NUEVO EPISODIO PUBLICADO!: <a href="' + item.url + '" target="_blank" style="color: #d7385e; text-decoration: underline;">' + item.title + '</a>', 'published');
                            });
                        } else if (force) {
                            logToTerminal('ðŸ” ' + d.message, 'success');
                        }
                    } else {
                        var msg = (res.data && res.data.message) ? res.data.message : 'Error en la respuesta';
                        logToTerminal('âš ï¸ ' + msg, 'warn');
                    }
                })
                .catch(function(err) {
                    if (force) {
                        logToTerminal('âŒ Error de red: ' + err, 'error');
                    }
                })
                .finally(function() {
                    isPolling = false;
                });
            }

            function startTimer() {
                stopTimer();
                if (!isEnabled) return;
                performCheck(false);
                pollTimer = setInterval(function() {
                    if (isEnabled) {
                        performCheck(false);
                    }
                }, intervalSeconds * 1000);
            }

            function stopTimer() {
                if (pollTimer) {
                    clearInterval(pollTimer);
                    pollTimer = null;
                }
            }

            $toggleBtn.addEventListener('click', function(e) {
                e.preventDefault();
                var newState = !isEnabled;
                updateStatusUI(newState);

                if (newState) {
                    startTimer();
                    logToTerminal('â–¶ï¸ Auto-Publicador activado. Comprobando cada ' + intervalSeconds + 's...', 'success');
                } else {
                    stopTimer();
                    logToTerminal('â¸ï¸ Auto-Publicador pausado por el usuario.', 'warn');
                }

                var data = new FormData();
                data.append('action', 'dramastream_auto_save_settings');
                data.append('nonce', nonce);
                data.append('enabled', newState ? '1' : '0');
                data.append('interval', intervalSeconds);
                fetch(ajaxUrl, { method: 'POST', body: data });
            });

            $manualCheckBtn.addEventListener('click', function(e) {
                e.preventDefault();
                $manualCheckBtn.style.opacity = '0.6';
                $manualCheckBtn.disabled = true;
                logToTerminal('ðŸ” Comprobando anikototv.to/home en vivo...', 'info');

                performCheck(true);

                setTimeout(function() {
                    $manualCheckBtn.style.opacity = '1';
                    $manualCheckBtn.disabled = false;
                }, 1200);
            });

            $settingsForm.addEventListener('submit', function(e) {
                e.preventDefault();
                $saveSettingsBtn.textContent = 'Guardando...';
                $saveSettingsBtn.disabled = true;

                var newInterval = Math.max(1, parseInt($intervalSelect.value, 10) || 1);
                intervalSeconds = newInterval;

                var data = new FormData();
                data.append('action', 'dramastream_auto_save_settings');
                data.append('nonce', nonce);
                data.append('enabled', isEnabled ? '1' : '0');
                data.append('interval', intervalSeconds);

                fetch(ajaxUrl, { method: 'POST', body: data })
                .then(function(r) { return r.json(); })
                .then(function(res) {
                    logToTerminal('ðŸ’¾ ' + (res.data ? res.data.message : 'ConfiguraciÃ³n guardada.'), 'success');
                    if (isEnabled) {
                        startTimer();
                    }
                })
                .finally(function() {
                    $saveSettingsBtn.textContent = 'ðŸ’¾ Guardar Cambios';
                    $saveSettingsBtn.disabled = false;
                });
            });

            $clearTermBtn.addEventListener('click', function(e) {
                e.preventDefault();
                $termScreen.innerHTML = '';
                logToTerminal('ðŸ§¹ Logs del terminal limpiados.', 'info');

                var data = new FormData();
                data.append('action', 'dramastream_auto_clear_logs');
                data.append('nonce', nonce);
                fetch(ajaxUrl, { method: 'POST', body: data });
            });

            // Start poller on load
            updateStatusUI(isEnabled);
            if (isEnabled) {
                startTimer();
            }
        })();
        </script>
        <?php
    }
}

// Backwards compatibility alias
if (!class_exists('Animestream_Auto_Sync')) {
    class Animestream_Auto_Sync extends DramaStream_Auto_Sync {}
}

new DramaStream_Auto_Sync();