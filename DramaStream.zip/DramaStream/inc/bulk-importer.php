<?php
if (!defined('ABSPATH')) exit;

/**
 * Anikoto API Importer for the existing Anikoto/Gogo theme.
 *
 * Strategy:
 * - Do NOT probe ep-1, ep-2, ep-3 ... pages.
 * - Use the public Anikoto API catalog + /series/{id} endpoint.
 * - One /series/{id} response contains the complete episode list.
 * - Work is processed in short AJAX ticks so PHP never waits for hundreds of pages.
 * - Series and episodes are deduplicated by stable Anikoto IDs / source URL / series+episode.
 * - Public embed URLs returned by the API are stored in the theme's server fields.
 */

function ak_api_base(){ return 'https://anikotoapi.site'; }
function ak_source_base(){ return 'https://anikototv.to'; }
function ak_api_nonce(){ return 'anikoto_api_importer'; }

function ak_http_json($url){
    $r = wp_remote_get($url, [
        'timeout' => 12,
        'redirection' => 5,
        'headers' => [
            'Accept' => 'application/json,text/plain,*/*',
            'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/151 Safari/537.36'
        ]
    ]);
    if(is_wp_error($r)) return $r;
    $code=wp_remote_retrieve_response_code($r);
    $body=wp_remote_retrieve_body($r);
    if($code<200 || $code>=300) return new WP_Error('http','API HTTP '.$code);
    $data=json_decode($body,true);
    if(!is_array($data)) return new WP_Error('json','Invalid JSON from Anikoto API');
    return $data;
}
function ak_http_html($url){
    $r=wp_remote_get($url,[
        'timeout'=>12,'redirection'=>5,
        'headers'=>['User-Agent'=>'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/151 Safari/537.36']
    ]);
    if(is_wp_error($r)) return $r;
    $code=wp_remote_retrieve_response_code($r);
    if($code<200 || $code>=400) return new WP_Error('http','Source HTTP '.$code);
    return wp_remote_retrieve_body($r);
}
function ak_norm($s){
    $s=remove_accents(wp_strip_all_tags((string)$s));
    $s=preg_replace('/\s+/u',' ',trim($s));
    return mb_strtolower($s,'UTF-8');
}
function ak_slug($s){
    $s=sanitize_title($s); return trim($s,'-');
}
function ak_val($a,$keys,$default=''){
    foreach((array)$keys as $k){
        if(is_array($a) && array_key_exists($k,$a) && $a[$k]!==null && $a[$k]!=='') return $a[$k];
    }
    return $default;
}
function ak_text_value($v,$sep=', '){
    if(is_array($v)){
        $parts=[];
        foreach($v as $k=>$item){
            if(is_array($item)){
                $item=ak_val($item,['name','title','english','romaji','native','label','value'],'');
                if(is_array($item)) $item=ak_text_value($item,$sep);
            }
            if(is_scalar($item) && trim((string)$item)!=='') $parts[]=trim((string)$item);
        }
        return implode($sep,$parts);
    }
    return is_scalar($v)?trim((string)$v):'';
}
function ak_clean_display_text($v){
    if(is_array($v)) $v=ak_text_value($v);
    $v=trim((string)$v);
    if($v==='') return '';
    // Old imports could have serialized/rendered nested PHP arrays as the literal word "Array".
    $v=preg_replace('/(?:^|\s*,\s*)Array(?=\s*,|\s*$)/i','',$v);
    $v=preg_replace('/\s*,\s*,+/',' , ',$v);
    $v=preg_replace('/^\s*,\s*|\s*,\s*$/','',$v);
    $v=trim(preg_replace('/\s+/u',' ',$v));
    return $v;
}
function ak_deep_val($a,$paths,$default=''){
    foreach($paths as $path){
        $cur=$a;
        foreach(explode('.',$path) as $p){
            if(is_array($cur) && array_key_exists($p,$cur)) $cur=$cur[$p]; else { $cur=null; break; }
        }
        if($cur!==null && $cur!=='') return $cur;
    }
    return $default;
}
function ak_array_url($v){
    if(is_string($v)) return esc_url_raw($v);
    if(is_array($v)) return esc_url_raw(ak_val($v,['url','src','file','href'],''));
    return '';
}
function ak_image_url($data){
    $v=ak_deep_val($data,[
        'image','image_url','poster','poster_url','cover','cover_url','thumbnail','thumbnail_url','images.jpg.image_url','images.jpg.large_image_url','images.jpg.url','anime.image','anime.poster','anime.image_url'
    ],'');
    return ak_array_url($v);
}
function ak_extract_data($json){
    if(isset($json['data']) && is_array($json['data'])) return $json['data'];
    return $json;
}
function ak_rows_from_recent($json){
    $d=ak_extract_data($json);
    foreach(['anime','items','results','rows'] as $k){ if(isset($d[$k]) && is_array($d[$k])) return array_values($d[$k]); }
    if(isset($d['Page']['media']) && is_array($d['Page']['media'])) return array_values($d['Page']['media']);
    if(array_is_list($d)) return $d;
    if(array_is_list($json)) return $json;
    return [];
}
function ak_pagination($json){
    foreach(['pagination','meta'] as $k){
        if(isset($json[$k]) && is_array($json[$k])) return $json[$k];
        if(isset($json['data'][$k]) && is_array($json['data'][$k])) return $json['data'][$k];
    }
    return [];
}
function ak_row_id($row){
    return (string)ak_val($row,['anikoto_id','anime_id','series_id','id'], '');
}
function ak_row_title($row){
    $t=ak_val($row,['name','title','anime_name'], '');
    if(is_array($t)) $t=ak_val($t,['english','romaji','native','name','title'], '');
    if(is_array($t)) $t=ak_text_value($t);
    return trim(wp_strip_all_tags((string)$t));
}
function ak_row_slug($row){
    $s=ak_val($row,['slug','series_slug','anime_slug'], '');
    if($s) return sanitize_title($s);
    foreach(['url','link','watch_url','source_url'] as $k){
        $u=ak_val($row,[$k],'');
        if($u && preg_match('~/watch/([^/?#]+)~i',$u,$m)) return sanitize_title($m[1]);
    }
    return ak_slug(ak_row_title($row));
}
function ak_source_series_url($slug){ return $slug ? ak_source_base().'/watch/'.rawurlencode($slug) : ''; }
function ak_source_episode_url($slug,$ep){ return $slug!=='' ? ak_source_series_url($slug).'/ep-'.rawurlencode((string)$ep) : ''; }
function ak_find_series($title,$source_url='',$api_id=''){
    if($api_id){
        $q=new WP_Query(['post_type'=>'series','post_status'=>'any','posts_per_page'=>1,'fields'=>'ids','meta_key'=>'_anikoto_api_id','meta_value'=>(string)$api_id]);
        if(!empty($q->posts)) return (int)$q->posts[0];
    }
    if($source_url){
        $q=new WP_Query(['post_type'=>'series','post_status'=>'any','posts_per_page'=>1,'fields'=>'ids','meta_key'=>'_anikoto_source_url','meta_value'=>$source_url]);
        if(!empty($q->posts)) return (int)$q->posts[0];
    }
    $key=ak_norm($title);
    if($key==='') return 0;
    $q=new WP_Query(['post_type'=>'series','post_status'=>'any','posts_per_page'=>100,'fields'=>'ids','s'=>$title]);
    foreach($q->posts as $id){ if(ak_norm(get_the_title($id))===$key) return (int)$id; }
    return 0;
}
function ak_set_image($post_id,$url,$title=''){
    if(!$url) return false;
    $existing_thumb=get_post_thumbnail_id($post_id);
    if($existing_thumb) return (int)$existing_thumb;
    require_once ABSPATH.'wp-admin/includes/file.php';
    require_once ABSPATH.'wp-admin/includes/media.php';
    require_once ABSPATH.'wp-admin/includes/image.php';
    $tmp=download_url($url,20);
    if(is_wp_error($tmp)) return false;
    $name=wp_basename(parse_url($url,PHP_URL_PATH) ?: 'anikoto.jpg');
    if(!preg_match('/\.(jpe?g|png|gif|webp)$/i',$name)) $name.='.jpg';
    $file=['name'=>sanitize_file_name($name),'tmp_name'=>$tmp];
    $att=media_handle_sideload($file,$post_id,$title);
    if(is_wp_error($att)){ @unlink($tmp); return false; }
    set_post_thumbnail($post_id,$att);
    return (int)$att;
}

/**
 * Automatically populate the theme's Big Cover field for every Series.
 * Existing manually selected Big Covers are preserved. If none exists,
 * the Series featured image is used as the Big Cover attachment.
 */
function ak_auto_set_big_cover($post_id,$attachment_id=0){
    $post_id=(int)$post_id;
    if(!$post_id || get_post_type($post_id)!=='series') return false;

    // Meta Box image_advanced stores attachment IDs as an array.
    $current=get_post_meta($post_id,'ero_cover',true);
    if(is_string($current) && trim($current)!==''){
        $decoded=json_decode($current,true);
        if(is_array($decoded)) $current=$decoded;
    }
    if(is_array($current) && !empty($current)) return true;
    if(!empty($current) && is_numeric($current)) return true;

    $attachment_id=(int)$attachment_id;
    if(!$attachment_id) $attachment_id=(int)get_post_thumbnail_id($post_id);
    if(!$attachment_id || get_post_type($attachment_id)!=='attachment') return false;

    update_post_meta($post_id,'ero_cover',[$attachment_id]);
    clean_post_cache($post_id);
    return true;
}
function ak_apply_meta($post_id,$data){
    if(!is_array($data)) return;
    $map=[
        'format'=>['type','format'], 'episodes'=>['episode_count','total_episodes','episodes'], 'duration'=>['duration'],
        'status'=>['status'], 'season'=>['season'], 'season_year'=>['season_year','year'],
        'score'=>['score','rating'], 'start_date'=>['start_date','aired_from'], 'end_date'=>['end_date','aired_to'],
        'alternative'=>['alternative','synonyms'], 'japanese'=>['japanese','native'], 'studio'=>['studio','studios'],
        'director'=>['director'], 'producer'=>['producer','producers'], 'network'=>['network'],
    ];
    foreach($map as $meta=>$keys){
        $v=ak_val($data,$keys,'');
        if(is_array($v)) $v=ak_text_value($v);
        if($v!=='') update_post_meta($post_id,'_anikoto_'.$meta,sanitize_text_field((string)$v));
    }
    $genres=ak_val($data,['genres'],[]);
    if(is_string($genres)) $genres=preg_split('/[,|]/',$genres);
    if(is_array($genres)){
        $genres=array_values(array_filter(array_map(function($g){return is_array($g)?ak_val($g,['name','title'],''):$g;},$genres)));
        if($genres) update_post_meta($post_id,'_anikoto_tags',implode("\n",array_map('sanitize_text_field',$genres)));
    }
    $syn=ak_val($data,['synopsis','description','overview','plot'],'');
    if(is_array($syn)) $syn=ak_val($syn,['text','content'],'');
    if($syn!=='') update_post_meta($post_id,'_anikoto_synopsis',wp_kses_post($syn));
}
/**
 * Sync imported genres to the Series taxonomy without creating duplicate terms.
 * Existing terms are reused case-insensitively and existing assignments are preserved.
 */
function ak_sync_imported_genres($post_id,$data){
    if(!is_array($data) || !taxonomy_exists('genres') || !function_exists('wp_set_post_terms')) return;
    $genres=ak_val($data,['genres'],[]);
    if(is_string($genres)) $genres=preg_split('/[,|]/',$genres);
    if(!is_array($genres) || !$genres) return;

    $wanted=[];
    foreach($genres as $g){
        $name=is_array($g)?ak_val($g,['name','title','label'],''):$g;
        $name=sanitize_text_field(trim((string)$name));
        if($name==='') continue;
        $key=ak_norm($name);
        if($key==='') continue;
        $wanted[$key]=$name;
    }
    if(!$wanted) return;

    $term_ids=[];
    foreach($wanted as $key=>$name){
        // Reuse an existing genre even when capitalization differs.
        $terms=get_terms([
            'taxonomy'=>'genres',
            'hide_empty'=>false,
            'name__like'=>$name,
            'number'=>50,
        ]);
        $found=0;
        if(!is_wp_error($terms)){
            foreach($terms as $term){
                if(ak_norm($term->name)===$key){
                    $found=(int)$term->term_id;
                    break;
                }
            }
        }
        if(!$found){
            $created=wp_insert_term($name,'genres');
            if(!is_wp_error($created)) $found=(int)$created['term_id'];
            elseif($created->get_error_code()==='term_exists'){
                $found=(int)$created->get_error_data();
            }
        }
        if($found) $term_ids[]=$found;
    }

    if(!$term_ids) return;

    // Preserve manually assigned genres and add imported ones only once.
    $existing=wp_get_object_terms($post_id,'genres',['fields'=>'ids']);
    if(is_wp_error($existing)) $existing=[];
    $merged=array_values(array_unique(array_map('intval',array_merge($existing,$term_ids))));
    wp_set_post_terms($post_id,$merged,'genres',false);
}

function ak_sync_native_series_meta($post_id,$data){
    if(!is_array($data)) return;
    $map=[
        'ero_type'=>['type','format'],
        'ero_durasi'=>['duration'],
        'ero_skor'=>['score','rating'],
        'ero_tayang'=>['start_date','aired_from','aired'],
        'ero_episode'=>['episode_count','total_episodes','episodes'],
        'ero_alt'=>['alternative','synonyms','alternatives'],
        'ero_japanese'=>['japanese','native','alternative_titles'],
        'ero_lang'=>['language','languages'],
    ];
    foreach($map as $meta=>$keys){
        $v=ak_val($data,$keys,'');
        if($meta==='ero_episode') {
            if(is_numeric($v)) {
                $v=(int)$v;
            } elseif(is_array($v)) {
                $v=ak_val($v,['count','episode_count','total','total_episodes'],'');
            }
            // Never save a raw episode-title list in ero_episode.
            if(!is_numeric($v) || (int)$v<=0) {
                continue;
            }
        } elseif(is_array($v)) { $v=ak_text_value($v); }
        if($v!=='') { $v=ak_clean_display_text($v); if($v!=='') update_post_meta($post_id,$meta,sanitize_text_field((string)$v)); }
    }
    $status=ak_val($data,['status'],'');
    if($status!==''){
        $status_map=['Finished Airing'=>'Completed','Currently Airing'=>'Ongoing','not yet aired'=>'Upcoming'];
        $status=$status_map[$status]??$status;
        update_post_meta($post_id,'ero_status',sanitize_text_field($status));
    }
    // Never store raw PHP arrays in text meta: WordPress/theme templates would render them as "Array".
    foreach(['ero_alt','ero_japanese','ero_lang'] as $safe_meta){
        $safe_val=get_post_meta($post_id,$safe_meta,true);
        { $safe_val=ak_clean_display_text($safe_val); if($safe_val!=='') update_post_meta($post_id,$safe_meta,sanitize_text_field($safe_val)); else delete_post_meta($post_id,$safe_meta); }
    }
    $season=ak_val($data,['season'],'');
    $year=ak_val($data,['season_year','year'],'');
    if($season && $year) update_post_meta($post_id,'ero_premiered',sanitize_text_field(strtoupper($season).' '.$year));
    elseif($season) update_post_meta($post_id,'ero_premiered',sanitize_text_field($season));
    $syn=ak_val($data,['synopsis','description','overview','plot'],'');
    if(is_array($syn)) $syn=ak_val($syn,['text','content'],'');
    if($syn!=='') wp_update_post(['ID'=>$post_id,'post_content'=>wp_kses_post($syn)]);
}
function ak_sync_native_episode_meta($post_id,$series_id,$num,$ep_title='',$servers=[]){
    update_post_meta($post_id,'ero_seri',(int)$series_id);
    update_post_meta($post_id,'ero_episodebaru',sanitize_text_field((string)$num));
    if($ep_title!=='') update_post_meta($post_id,'ero_episodetitle',sanitize_text_field((string)$ep_title));
    $sub='';
    foreach((array)$servers as $sv){
        $type=strtoupper((string)($sv['type']??$sv['name']??''));
        if($type==='DUB'){ $sub='Dub'; break; }
        if($type==='SUB') $sub='Sub';
    }
    if($sub) update_post_meta($post_id,'ero_subepisode',$sub);
    if($servers){
        $group=[];
        foreach($servers as $sv){
            $url=esc_url_raw((string)($sv['url']??''));
            if(!$url) continue;
            $name=sanitize_text_field((string)($sv['name']??$sv['type']??'Server'));
            $group[]=['ab_hostname'=>$name,'ab_embed'=>$url];
        }
        if($group){
            update_post_meta($post_id,'ab_embedgroup',$group);
            update_post_meta($post_id,'ero_embed',array_map(function($g){return $g['ab_embed'];},$group));
        }
    }
}
function ak_sync_series_latest($series_id,$episode_id,$episode_number){
    $series_id=(int)$series_id; $episode_id=(int)$episode_id;
    if(!$series_id || !$episode_id) return;
    $new_num=(float)$episode_number;
    $old_num=get_post_meta($series_id,'ero_latest',true);
    $old_id=(int)get_post_meta($series_id,'ero_latestid',true);
    $should=$old_id<=0 || $new_num >= (float)$old_num;
    if($should){
        update_post_meta($series_id,'ero_latest',(string)$episode_number);
        update_post_meta($series_id,'ero_latestid',$episode_id);
        // Make the Series participate in the theme's "Latest Episodes" homepage ordering.
        wp_update_post(['ID'=>$series_id,'post_modified'=>current_time('mysql'),'post_modified_gmt'=>current_time('mysql',true)]);
    }
}

function ak_create_series($row,$auto=true,$details=[]){
    $row=is_array($row)?$row:[]; $details=is_array($details)?$details:[];
    $data=array_merge($row,$details);
    $title=ak_row_title($data); if($title==='') $title='Untitled Series';
    $api_id=ak_row_id($data);
    $slug=ak_row_slug($data);
    $source=ak_source_series_url($slug);
    $id=ak_find_series($title,$source,$api_id);
    if($id){
        if($auto && get_post_status($id)!=='publish') wp_update_post(['ID'=>$id,'post_status'=>'publish']);
    }else{
        $id=wp_insert_post(['post_type'=>'series','post_status'=>$auto?'publish':'draft','post_title'=>sanitize_text_field($title)],true);
        if(is_wp_error($id)) return 0;
    }
    update_post_meta($id,'_anikoto_series_title',sanitize_text_field($title));
    if($api_id!=='') update_post_meta($id,'_anikoto_api_id',$api_id);
    if($slug!=='') update_post_meta($id,'_anikoto_slug',$slug);
    if($source!=='') update_post_meta($id,'_anikoto_source_url',esc_url_raw($source));
    ak_apply_meta($id,$data);
    ak_sync_native_series_meta($id,$data);
    ak_sync_imported_genres($id,$data);
    if (function_exists('dramastream_ensure_series_category')) {
        dramastream_ensure_series_category($title, $id);
    }
    $img=ak_image_url($data);
    $attachment_id=0;
    if($img) $attachment_id=(int)ak_set_image($id,$img,$title);
    if(!$attachment_id) $attachment_id=(int)get_post_thumbnail_id($id);
    // Always make the Big Cover automatic when the field is empty.
    // A manually selected ero_cover is never overwritten.
    ak_auto_set_big_cover($id,$attachment_id);
    return (int)$id;
}
/**
 * Automatically set the episode SEO focus keyphrase from its post title.
 * Supports the common SEO plugins used with this theme. Existing/manual
 * keyphrases are preserved and never overwritten.
 */
function anikoto_sync_episode_keyphrase($post_id){
    $post_id=(int)$post_id;
    if(!$post_id) return;
    $title=trim(wp_strip_all_tags(get_the_title($post_id)));
    if($title==='') return;

    // Yoast SEO focus keyphrase.
    if(trim((string)get_post_meta($post_id,'_yoast_wpseo_focuskw',true))===''){
        update_post_meta($post_id,'_yoast_wpseo_focuskw',sanitize_text_field($title));
    }

    // Rank Math focus keyword.
    if(trim((string)get_post_meta($post_id,'rank_math_focus_keyword',true))===''){
        update_post_meta($post_id,'rank_math_focus_keyword',sanitize_text_field($title));
    }

    // All in One SEO: only fill the simple keywords field when it is empty.
    if(trim((string)get_post_meta($post_id,'_aioseo_keywords',true))===''){
        update_post_meta($post_id,'_aioseo_keywords',sanitize_text_field($title));
    }
}

function ak_episode_exists($series_id,$ep,$source_url='',$series_title=''){
    $series_id=(int)$series_id;
    $ep=trim((string)$ep);
    if($source_url){
        $q=new WP_Query(['post_type'=>'post','post_status'=>'any','posts_per_page'=>1,'fields'=>'ids','meta_key'=>'_anikoto_source_url','meta_value'=>$source_url]);
        if(!empty($q->posts)) return (int)$q->posts[0];
    }
    if($series_id){
        $q=new WP_Query(['post_type'=>'post','post_status'=>'any','posts_per_page'=>1,'fields'=>'ids','meta_query'=>[
            ['key'=>'_anikoto_series_id','value'=>$series_id,'compare'=>'='],
            ['key'=>'_anikoto_episode_number','value'=>$ep,'compare'=>'=']
        ]]);
        if(!empty($q->posts)) return (int)$q->posts[0];

        // Legacy/imported episodes may not have the importer meta yet.
        // Match the exact Series + Episode title before creating another post.
        if($series_title!==''){
            $title=trim($series_title).' Episode '.$ep;
            $q=new WP_Query([
                'post_type'=>'post','post_status'=>'any','posts_per_page'=>20,'fields'=>'ids',
                's'=>$title
            ]);
            foreach($q->posts as $candidate){
                if(ak_norm(get_the_title($candidate))===ak_norm($title)){
                    return (int)$candidate;
                }
            }
        }
    }
    return 0;
}

/**
 * Advanced Episode support.
 * An advanced episode is a published placeholder for the next episode. It is
 * hidden from homepage episode queries and shows NOT ARRIVED YET in the player
 * until the normal importer receives that episode.
 */
function ak_is_advanced_episode($post_id){
    return (bool)get_post_meta((int)$post_id,'_dramastream_advanced_episode',true);
}
function ak_activate_imported_episode($post_id,$series_id,$num,$ep_title='',$source='',$servers=[]){
    $post_id=(int)$post_id;
    if(!$post_id) return;
    if($source) update_post_meta($post_id,'_anikoto_source_url',esc_url_raw($source));
    if($servers){
        update_post_meta($post_id,'_anikoto_servers',wp_json_encode($servers));
        update_post_meta($post_id,'_anikoto_iframe_url',$servers[0]['url']);
    }
    if($ep_title) update_post_meta($post_id,'_anikoto_episode_title',sanitize_text_field($ep_title));
    delete_post_meta($post_id,'_dramastream_advanced_episode');
    delete_post_meta($post_id,'_dramastream_advanced_created_from');
    wp_update_post([
        'ID'=>$post_id,
        'post_status'=>'publish',
        'post_title'=>sanitize_text_field(ak_row_title(['title'=>get_the_title($series_id)]).' Episode '.$num)
    ]);
}

function ak_episode_rows($json){
    $d=ak_extract_data($json); $rows=[];
    if(isset($d['episodes'])&&is_array($d['episodes']))$rows=$d['episodes'];
    elseif(isset($json['episodes'])&&is_array($json['episodes']))$rows=$json['episodes'];
    return array_values($rows);
}
function ak_episode_number($e){ return (string)ak_val($e,['number','episode','episode_number','ep'],''); }
function ak_episode_servers($e){
    $out=[]; $emb=ak_val($e,['embed_url','embed','embeds'],[]);
    if(is_array($emb)){
        foreach(['sub'=>'SUB','dub'=>'DUB'] as $k=>$label){
            $u=ak_array_url(is_array($emb)&&array_key_exists($k,$emb)?$emb[$k]:'');
            if($u) $out[]=['name'=>$label,'type'=>$label,'url'=>$u];
        }
        foreach($emb as $k=>$v){
            if(in_array((string)$k,['sub','dub'],true)) continue;
            $u=ak_array_url($v); if($u)$out[]=['name'=>sanitize_text_field((string)$k),'type'=>strtoupper(sanitize_text_field((string)$k)),'url'=>$u];
        }
    }elseif(is_string($emb) && filter_var($emb,FILTER_VALIDATE_URL)) $out[]=['name'=>'SUB','type'=>'SUB','url'=>esc_url_raw($emb)];
    foreach(['iframe','iframe_url','embed_url_sub','sub_url','dub_url'] as $k){$u=ak_val($e,[$k],'');if($u&&filter_var($u,FILTER_VALIDATE_URL))$out[]=['name'=>strtoupper(strpos($k,'dub')!==false?'DUB':'SUB'),'type'=>strtoupper(strpos($k,'dub')!==false?'DUB':'SUB'),'url'=>esc_url_raw($u)];}
    $seen=[];$out=array_values(array_filter($out,function($x)use(&$seen){$u=$x['url']??'';if(!$u||isset($seen[$u]))return false;$seen[$u]=1;return true;}));
    return $out;
}
function ak_import_series_by_id($api_id,$row=[],$auto=true){
    if(!$api_id) return ['ok'=>false,'message'=>'Missing Anikoto series ID'];
    $json=ak_http_json(ak_api_base().'/series/'.rawurlencode($api_id));
    if(is_wp_error($json)) return ['ok'=>false,'message'=>$json->get_error_message()];
    $d=ak_extract_data($json);
    $anime=is_array($d)&&isset($d['anime'])&&is_array($d['anime'])?$d['anime']:[];
    $merged=array_merge(is_array($row)?$row:[],$anime);
    // Resolve the existing Series BEFORE any insert/update.
    // If it already exists, reuse it; never create a second Series post.
    $series_title=ak_row_title($merged);
    $series_api_id=ak_row_id($merged);
    $series_slug=ak_row_slug($merged);
    $series_source=ak_source_series_url($series_slug);
    $existing_series_id=ak_find_series($series_title,$series_source,$series_api_id);
    $series_was_existing=(bool)$existing_series_id;
    $series_id=$existing_series_id ? $existing_series_id : ak_create_series($merged,$auto,$d);
    if(!$series_id) return ['ok'=>false,'message'=>'Could not create/find series '.$series_title];
    $slug=ak_row_slug($merged); if(!$slug){$s=get_post_meta($series_id,'_anikoto_slug',true);$slug=$s;}
    $eps=ak_episode_rows($json); $created=0;$skipped=0;
    foreach($eps as $e){
        $num=ak_episode_number($e); if($num==='')continue;
        $source=ak_val($e,['url','watch_url','source_url','link'],'');
        if(!$source) $source=ak_source_episode_url($slug,$num);
        $existing=ak_episode_exists($series_id,$num,$source,ak_row_title($merged));
        if($existing){
            $ep_title=ak_val($e,['title','name','episode_title'],'');
            if(is_array($ep_title)) $ep_title=ak_val($ep_title,['english','romaji','native'],'');
            $srv=ak_episode_servers($e);
            $was_advanced=ak_is_advanced_episode($existing);
            if($auto&&get_post_status($existing)!=='publish') wp_update_post(['ID'=>$existing,'post_status'=>'publish']);
            if($was_advanced){
                // Convert the pre-created Advanced Episode into the real episode.
                ak_activate_imported_episode($existing,$series_id,$num,$ep_title,$source,$srv);
                $created++;
            } else {
                if($srv){update_post_meta($existing,'_anikoto_servers',wp_json_encode($srv));update_post_meta($existing,'_anikoto_iframe_url',$srv[0]['url']);}
                $skipped++;
            }
            ak_sync_native_episode_meta($existing,$series_id,$num,$ep_title,$srv);
            anikoto_sync_episode_keyphrase($existing);
            ak_sync_series_latest($series_id,$existing,$num);
            if(!has_post_thumbnail($existing)&&has_post_thumbnail($series_id))set_post_thumbnail($existing,get_post_thumbnail_id($series_id));
            continue;
        }
        $ep_title=ak_val($e,['title','name','episode_title'],'');
        if(is_array($ep_title))$ep_title=ak_val($ep_title,['english','romaji','native'],'');
        $post_title=$ep_title?($merged['title']??$merged['name']??'').' Episode '.$num:($merged['title']??$merged['name']??'').' Episode '.$num;
        $id=wp_insert_post(['post_type'=>'post','post_status'=>$auto?'publish':'draft','post_title'=>sanitize_text_field($post_title),'post_content'=>''],true);
        if(is_wp_error($id))continue;
        update_post_meta($id,'_anikoto_series_id',$series_id);
        update_post_meta($id,'_anikoto_series_title',sanitize_text_field(ak_row_title($merged)));
        update_post_meta($id,'_anikoto_episode_number',sanitize_text_field($num));
        if($ep_title)update_post_meta($id,'_anikoto_episode_title',sanitize_text_field($ep_title));
        if($source)update_post_meta($id,'_anikoto_source_url',esc_url_raw($source));
        $srv=ak_episode_servers($e); if($srv){update_post_meta($id,'_anikoto_servers',wp_json_encode($srv));update_post_meta($id,'_anikoto_iframe_url',$srv[0]['url']);}
        ak_sync_native_episode_meta($id,$series_id,$num,$ep_title,$srv);
        anikoto_sync_episode_keyphrase($id);
        if (function_exists('dramastream_ensure_series_category')) {
            dramastream_ensure_series_category($series_id, $id);
        }
        ak_sync_series_latest($series_id,$id,$num);
        if(!has_post_thumbnail($id)&&has_post_thumbnail($series_id))set_post_thumbnail($id,get_post_thumbnail_id($series_id));
        if(function_exists('anikoto_sync_episode_seo_title'))anikoto_sync_episode_seo_title($id);
        $created++;
    }
    // Repair legacy imports: if latest fields were missing, derive them from the episodes we just scanned.
    $latest_id=(int)get_post_meta($series_id,'ero_latestid',true);
    if(!$latest_id && $eps){
        $best_num=-1; $best_id=0;
        foreach($eps as $e){
            $en=ak_episode_number($e); if($en==='') continue;
            $src=ak_val($e,['url','watch_url','source_url','link'],''); if(!$src) $src=ak_source_episode_url($slug,$en);
            $eid=ak_episode_exists($series_id,$en,$src,ak_row_title($merged));
            if($eid && (float)$en>$best_num){$best_num=(float)$en;$best_id=(int)$eid;}
        }
        if($best_id) ak_sync_series_latest($series_id,$best_id,(string)$best_num);
    }
    $series_status=$series_was_existing ? 'Already have Series' : 'Series imported';
    $episode_status=$skipped>0 ? ('Already have '.$skipped.' episode'.($skipped===1?'':'s')) : '';
    $parts=array_filter([$series_status,$created.' new episode'.($created===1?'':'s'),$episode_status,count($eps).' total episodes']);
    return ['ok'=>true,'message'=>ak_row_title($merged).' — '.implode(' / ',$parts).'.','series_id'=>$series_id,'episodes'=>count($eps),'series_existing'=>$series_was_existing,'episodes_existing'=>$skipped];
}

/**
 * Import exactly one episode from a resolved Series API response.
 * The existing Series post is reused when found; otherwise it is created.
 * No other episodes are created by this function.
 */
function ak_import_single_episode_by_id($api_id,$episode_number,$row=[],$auto=true){
    if(!$api_id) return ['ok'=>false,'message'=>'Missing Anikoto series ID'];
    $episode_number=trim((string)$episode_number);
    if($episode_number==='') return ['ok'=>false,'message'=>'Missing episode number'];

    $json=ak_http_json(ak_api_base().'/series/'.rawurlencode($api_id));
    if(is_wp_error($json)) return ['ok'=>false,'message'=>$json->get_error_message()];

    $d=ak_extract_data($json);
    $anime=(is_array($d)&&isset($d['anime'])&&is_array($d['anime']))?$d['anime']:[];
    $merged=array_merge(is_array($row)?$row:[],$anime);
    // Resolve the existing Series BEFORE any insert/update.
    // A second import must reuse the existing Series and never create a duplicate.
    $series_title=ak_row_title($merged);
    $series_api_id=ak_row_id($merged);
    $series_slug=ak_row_slug($merged);
    $series_source=ak_source_series_url($series_slug);
    $existing_series_id=ak_find_series($series_title,$series_source,$series_api_id);
    $series_was_existing=(bool)$existing_series_id;
    $series_id=$existing_series_id ? $existing_series_id : ak_create_series($merged,$auto,$d);
    if(!$series_id) return ['ok'=>false,'message'=>'Could not create/find series '.$series_title];

    $slug=ak_row_slug($merged);
    if(!$slug) $slug=get_post_meta($series_id,'_anikoto_slug',true);

    $eps=ak_episode_rows($json);
    $target=null;
    foreach($eps as $e){
        $num=trim(ak_episode_number($e));
        if($num!=='' && (string)intval((float)$num)===(string)intval((float)$episode_number)){
            $target=$e;
            break;
        }
    }
    if(!$target){
        foreach($eps as $e){
            if(trim(ak_episode_number($e))===$episode_number){$target=$e;break;}
        }
    }
    if(!$target){
        return ['ok'=>false,'message'=>ak_row_title($merged).' — Episode '.$episode_number.' was not found in the API.','series_id'=>$series_id];
    }

    $num=trim(ak_episode_number($target));
    $source=ak_val($target,['url','watch_url','source_url','link'],'');
    if(!$source) $source=ak_source_episode_url($slug,$num);

    $existing=ak_episode_exists($series_id,$num,$source,ak_row_title($merged));
    if($existing){
        $was_advanced=ak_is_advanced_episode($existing);
        if($was_advanced){
            $ep_title=ak_val($target,['title','name','episode_title'],'');
            if(is_array($ep_title)) $ep_title=ak_val($ep_title,['english','romaji','native'],'');
            $srv=ak_episode_servers($target);
            ak_activate_imported_episode($existing,$series_id,$num,$ep_title,$source,$srv);
            ak_sync_native_episode_meta($existing,$series_id,$num,$ep_title,$srv);
            anikoto_sync_episode_keyphrase($existing);
            ak_sync_series_latest($series_id,$existing,$num);
            if(!has_post_thumbnail($existing)&&has_post_thumbnail($series_id)) set_post_thumbnail($existing,get_post_thumbnail_id($series_id));
            if(function_exists('anikoto_sync_episode_seo_title')) anikoto_sync_episode_seo_title($existing);
            return [
                'ok'=>true,
                'message'=>ak_row_title($merged).' — Advanced Episode '.$num.' is now live.',
                'series_id'=>$series_id,'episode_id'=>$existing,'created'=>1,'existing'=>0,'advanced_activated'=>1
            ];
        }
        // Repair SEO focus keyphrase on legacy/existing episodes without changing manual values.
        anikoto_sync_episode_keyphrase($existing);
        return [
            'ok'=>true,
            'message'=>ak_row_title($merged).' — Already have: Series and Episode '.$num.'. Nothing was created.',
            'series_id'=>$series_id,'episode_id'=>$existing,'created'=>0,'existing'=>1
        ];
    }

    $ep_title=ak_val($target,['title','name','episode_title'],'');
    if(is_array($ep_title)) $ep_title=ak_val($ep_title,['english','romaji','native'],'');
    $series_title=ak_row_title($merged);
    $post_title=$series_title.' Episode '.$num;

    $id=wp_insert_post([
        'post_type'=>'post',
        'post_status'=>$auto?'publish':'draft',
        'post_title'=>sanitize_text_field($post_title),
        'post_content'=>''
    ],true);
    if(is_wp_error($id)) return ['ok'=>false,'message'=>$id->get_error_message()];

    update_post_meta($id,'_anikoto_series_id',$series_id);
    update_post_meta($id,'_anikoto_series_title',sanitize_text_field($series_title));
    update_post_meta($id,'_anikoto_episode_number',sanitize_text_field($num));
    if($ep_title) update_post_meta($id,'_anikoto_episode_title',sanitize_text_field($ep_title));
    if($source) update_post_meta($id,'_anikoto_source_url',esc_url_raw($source));

    $srv=ak_episode_servers($target);
    if($srv){
        update_post_meta($id,'_anikoto_servers',wp_json_encode($srv));
        update_post_meta($id,'_anikoto_iframe_url',$srv[0]['url']);
    }
    ak_sync_native_episode_meta($id,$series_id,$num,$ep_title,$srv);
    anikoto_sync_episode_keyphrase($id);
    ak_sync_series_latest($series_id,$id,$num);
    if(!has_post_thumbnail($id)&&has_post_thumbnail($series_id)){
        set_post_thumbnail($id,get_post_thumbnail_id($series_id));
    }
    if(function_exists('anikoto_sync_episode_seo_title')) anikoto_sync_episode_seo_title($id);

    return [
        'ok'=>true,
        'message'=>ak_row_title($merged).' — Episode '.$num.' imported and connected to Series.',
        'series_id'=>$series_id,'episode_id'=>$id,'created'=>1,'existing'=>0
    ];
}

function ak_recent_page($page,$per=40){ return ak_http_json(ak_api_base().'/recent-anime?page='.absint($page).'&per_page='.absint($per)); }
function ak_match_row_for_slug($rows,$slug,$title=''){
    $nk=ak_norm($title);
    foreach($rows as $r){
        $rs=ak_row_slug($r); if($slug && $rs && $rs===$slug)return$r;
    }
    if($nk){foreach($rows as $r){if(ak_norm(ak_row_title($r))===$nk)return$r;}}
    return [];
}
function ak_job_default(){return['mode'=>'','import_mode'=>'all','page'=>1,'per_page'=>40,'row_queue'=>[],'series_index'=>0,'target_slug'=>'','target_ep'=>'','target_title'=>'','target_url'=>'','target_row'=>[],'auto'=>1,'running'=>0,'done'=>0,'catalog_pages'=>0,'series_done'=>0,'episodes_created'=>0,'episodes_existing'=>0,'errors'=>[]];}
function ak_job_get(){ $j=get_option('anikoto_api_import_job',[]);return array_merge(ak_job_default(),is_array($j)?$j:[]); }
function ak_job_set($j){update_option('anikoto_api_import_job',$j,false);}
function ak_ajax_guard(){check_ajax_referer(ak_api_nonce());if(!current_user_can('manage_options'))wp_send_json_error('Forbidden');}
function ak_admin_menu(){add_submenu_page('edit.php?post_type=series','Anikoto API Importer','Anikoto API Importer','manage_options','anikoto-api-importer','ak_admin_page');}
add_action('admin_menu','ak_admin_menu');
function ak_admin_page(){if(!current_user_can('manage_options'))return; $nonce=wp_create_nonce(ak_api_nonce());?>
<div class="wrap"><h1>Anikoto API Importer</h1>
<p class="description" style="max-width:1000px">Choose exactly what you want to import. Existing Series are reused automatically; a missing Series is created first and the episode is connected to it.</p>
<div id="ak-import-slots" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(360px,1fr));gap:18px;max-width:1000px;margin-top:18px">
  <div class="ak-import-slot" style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:20px">
    <h2 style="margin-top:0">Import All Episodes</h2>
    <p>Import the complete episode list for one Series. If the Series already exists, only missing episodes are added.</p>
    <input type="url" id="ak-all-url" style="width:100%;box-sizing:border-box" placeholder="https://anikoto.../watch/series-slug">
    <p><label><input type="checkbox" id="ak-all-auto" checked> Auto Publish</label></p>
    <button class="button button-primary" id="ak-all-go">Import All Episodes</button>
  </div>
  <div class="ak-import-slot" style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:20px">
    <h2 style="margin-top:0">Import Single Episode</h2>
    <p>Import only one episode. The importer will connect it to the existing Series, or create the Series if it does not exist.</p>
    <input type="url" id="ak-single-url" style="width:100%;box-sizing:border-box" placeholder="https://anikoto.../watch/series-slug/ep-18">
    <p><label><input type="checkbox" id="ak-single-auto" checked> Auto Publish</label></p>
    <button class="button button-primary" id="ak-single-go">Import Single Episode</button>
  </div>
</div>
<div style="max-width:1000px;margin-top:18px">
  <button class="button" id="ak-stop">Stop Current Import</button>
  <div id="ak-status" style="background:#111;color:#ddd;padding:14px;min-height:150px;white-space:pre-wrap;margin-top:10px"></div>
  <div style="height:18px;background:#ddd;margin-top:10px"><div id="ak-progress" style="height:18px;width:0;background:#2271b1"></div></div>
</div>
<script>
(()=>{const ajax=window.ajaxurl,nonce=<?php echo wp_json_encode($nonce);?>,log=document.getElementById('ak-status'),bar=document.getElementById('ak-progress');let stop=false;
function say(s){log.textContent+=s+'\n';log.scrollTop=log.scrollHeight;}
async function call(action,data={}){let f=new FormData();f.append('action',action);f.append('_ajax_nonce',nonce);for(const[k,v]of Object.entries(data))f.append(k,typeof v==='object'?JSON.stringify(v):v);let r=await fetch(ajax,{method:'POST',body:f});return r.json();}
document.getElementById('ak-stop').onclick=async()=>{stop=true;await call('anikoto_api_stop');say('Stop requested.');};
async function run(url,auto,mode){
  stop=false;log.textContent='';bar.style.width='0%';
  if(!url){say('Please enter a URL.');return;}
  let s=await call('anikoto_api_start',{url,auto:auto?'1':'0',import_mode:mode});
  if(!s.success){say('START ERROR: '+s.data);return;}
  say(s.data.message||'Started.');
  for(;;){
    if(stop)break;
    await new Promise(r=>setTimeout(r,1200));
    let x=await call('anikoto_api_tick');
    if(!x.success){say('ERROR: '+x.data);break;}
    if(x.data.message)say(x.data.message);
    if(x.data.percent!==null&&x.data.percent!==undefined)bar.style.width=x.data.percent+'%';
    if(x.data.done)break;
  }
  say(stop?'STOPPED':'DONE');
}
document.getElementById('ak-all-go').onclick=()=>run(document.getElementById('ak-all-url').value.trim(),document.getElementById('ak-all-auto').checked,'all');
document.getElementById('ak-single-go').onclick=()=>run(document.getElementById('ak-single-url').value.trim(),document.getElementById('ak-single-auto').checked,'single');
})();
</script><?php }

function ak_start(){
    ak_ajax_guard();
    $url=esc_url_raw(wp_unslash($_POST['url']??''));
    $auto=!empty($_POST['auto']);
    $import_mode=sanitize_key(wp_unslash($_POST['import_mode']??'all'));
    if(!$url) wp_send_json_error('URL required');
    if(!in_array($import_mode,['all','single'],true)) $import_mode='all';

    $j=ak_job_default();
    $j['auto']=$auto?1:0;
    $j['running']=1;
    $j['import_mode']=$import_mode;

    if($import_mode==='single'){
        if(!preg_match('~^https?://[^/]+/watch/([^/?#]+)/ep[-_/]?([0-9]+(?:\.[0-9]+)*)/?(?:\?.*)?$~i',$url,$m)){
            wp_send_json_error('Single Episode Import requires an Episode URL like /watch/series-slug/ep-18.');
        }
        $j['mode']='resolve';
        $j['target_slug']=sanitize_title($m[1]);
        $j['target_ep']=sanitize_text_field($m[2]);
        $j['target_url']=$url;
        $j['page']=1;
        ak_job_set($j);
        wp_send_json_success(['message'=>'Single Episode import started. Resolving the Series and Episode from the API...']);
    }

    if(preg_match('~^https?://[^/]+/home(?:/)?(?:\?.*)?$~i',$url)){
        $j['mode']='full';$j['page']=1;ak_job_set($j);
        wp_send_json_success(['message'=>'Full catalogue import started.']);
    }
    if(preg_match('~^https?://[^/]+/watch/([^/?#]+)(?:/)?$~i',$url,$m)){
        $j['mode']='resolve_series';
        $j['target_slug']=sanitize_title($m[1]);
        $j['target_url']=$url;
        $j['page']=1;
        ak_job_set($j);
        wp_send_json_success(['message'=>'Series URL received. Resolving Series from the API catalogue...']);
    }
    wp_send_json_error('Use a Series /watch/... URL, /home for the catalogue, or an Episode /watch/.../ep-N URL.');
}
add_action('wp_ajax_anikoto_api_start','ak_start');
function ak_stop(){ak_ajax_guard();$j=ak_job_get();$j['running']=0;ak_job_set($j);wp_send_json_success();}add_action('wp_ajax_anikoto_api_stop','ak_stop');
function ak_tick(){ak_ajax_guard();$j=ak_job_get();if(empty($j['running']))wp_send_json_success(['message'=>'No active job.','done'=>true,'percent'=>100]);$auto=!empty($j['auto']);$messages=[];
// Resolve a Series or Single Episode URL by walking API catalogue pages until slug/title matches.
if(in_array($j['mode'],['resolve','resolve_series'],true)){
    $res=ak_recent_page($j['page'],$j['per_page']);
    if(is_wp_error($res)){wp_send_json_error($res->get_error_message());}
    $rows=ak_rows_from_recent($res);
    $match=ak_match_row_for_slug($rows,$j['target_slug'],$j['target_title']);
    if($match){
        $j['target_row']=$match;
        $j['row_queue']=[$match];
        $j['series_index']=0;
        if(($j['import_mode']??'all')==='single'){
            $j['mode']='single';
            $messages[]='Series resolved: '.ak_row_title($match).' — Episode '.esc_html($j['target_ep']).' selected.';
        }else{
            $j['mode']='series';
            $messages[]='Series resolved: '.ak_row_title($match).' (API ID '.ak_row_id($match).')';
        }
    }else{
        $j['page']++;
        $p=ak_pagination($res);
        $last=(int)ak_val($p,['total_pages','last_page','pages'],'0');
        if(!$rows||($last&&$j['page']>$last)){
            $j['running']=0;ak_job_set($j);
            wp_send_json_error('Could not resolve this Series from the Anikoto API catalogue.');
        }else{
            $messages[]='Searching API catalogue page '.$j['page'].'...';
            ak_job_set($j);
            wp_send_json_success(['message'=>implode(' ',$messages),'done'=>false,'percent'=>null]);
        }
    }
}

// For full catalogue, fetch one catalogue page per tick and enqueue its series rows.
if($j['mode']==='full' && empty($j['row_queue'])){
    $res=ak_recent_page($j['page'],$j['per_page']);
    if(is_wp_error($res)){wp_send_json_error($res->get_error_message());}
    $rows=ak_rows_from_recent($res);$j['catalog_pages']++;$p=ak_pagination($res);$last=(int)ak_val($p,['total_pages','last_page','pages'],'0');
    foreach($rows as $r){$id=ak_row_id($r);if($id)$j['row_queue'][]=$r;}
    $messages[]='Catalog page '.$j['page'].' loaded: '.count($rows).' Series.';
    $j['page']++;
    if(!$rows || ($last && $j['page']>$last))$j['mode']='series_end';
}
if($j['mode']==='single' && !empty($j['target_row'])){
    $row=$j['target_row'];
    $id=ak_row_id($row);
    $r=ak_import_single_episode_by_id($id,$j['target_ep'],$row,$auto);
    if($r['ok']){
        $j['series_done']++;
        $j['episodes_created']+=(int)($r['created']??0);
        $j['episodes_existing']+=(int)($r['existing']??0);
        $messages[]=$r['message'];
    }else{
        $j['errors'][]=$r['message'];
        $messages[]='ERROR: '.$r['message'];
    }
    $j['running']=0;
}

if(in_array($j['mode'],['series','full','series_end'],true) && !empty($j['row_queue'])){
    $processed=0;while($processed<2 && !empty($j['row_queue'])){
        $row=array_shift($j['row_queue']);$id=ak_row_id($row);$r=ak_import_series_by_id($id,$row,$auto);if($r['ok']){$j['series_done']++;$messages[]=$r['message'];$j['episodes_created']+=0;}else{$j['errors'][]=$r['message'];$messages[]='ERROR: '.$r['message'];}$processed++;}
    if(empty($j['row_queue']) && $j['mode']==='series_end'){$j['running']=0;}
}
if($j['mode']==='series' && empty($j['row_queue'])){$j['running']=0;}
if($j['mode']==='resolve' && !empty($j['target_row'])){$j['mode']='series';}
$percent=null;if($j['mode']==='full'){$p=$j['catalog_pages'];$percent=min(95,$p?5+$p:5);}elseif(($j['import_mode']??'all')==='single' && !$j['running'])$percent=100;elseif(!$j['running'])$percent=100;ak_job_set($j);
wp_send_json_success(['message'=>implode(' ',$messages)?:'Working...','done'=>empty($j['running']),'percent'=>$percent,'series_done'=>$j['series_done'],'errors'=>count($j['errors'])]);}
add_action('wp_ajax_anikoto_api_tick','ak_tick');
