<?php defined("ABSPATH") || die("!"); 

function themesia_assets() {
	wp_enqueue_style( 'style', get_stylesheet_uri(),[], THEMESIA_VERSION);
	wp_enqueue_style( 'darkstyle', get_template_directory_uri() . '/assets/css/darkmode.css',[], THEMESIA_VERSION,'all');
	
	if (get_option('tsrtl') == '1') {
		wp_enqueue_style('rtl', get_template_directory_uri() . '/assets/css/rtl.css', [], THEMESIA_VERSION, 'all');
	}
	
	wp_deregister_script('jquery');
   	wp_register_script('jquery', get_template_directory_uri() . '/assets/js/jquery.min.js', [], '3.6.0');
   	wp_enqueue_script('jquery');
	
	
	if(is_singular('series')){ 
		if(get_option('galleryanime')=='1'){wp_enqueue_script( 'ts-blueimp', get_template_directory_uri() . '/assets/js/blueimp-gallery.min.js', array( 'jquery' ), '3.4.0', false );}
		if(get_option('traileranime')=='1'){ wp_enqueue_script( 'ts-fancybox', get_template_directory_uri() . '/assets/js/fancybox.js', array( 'jquery' ), '4.0.19', false ); }
	}
	if(is_home()){
		if(get_option('homerecommend')=='1'){wp_enqueue_script( 'tabs', get_template_directory_uri() . '/assets/js/tabs.js', array( 'jquery' ), THEMESIA_VERSION, false );}
	}
	if(is_singular('post') && get_option('episodelist')=='1'){
		wp_enqueue_script( 'tsmedia', get_template_directory_uri() . '/assets/js/tsmedia.js', array( 'jquery' ), THEMESIA_VERSION, false );
	}
	wp_enqueue_script( 'ts-functions', get_template_directory_uri() . '/assets/js/tsfn.js', array( 'jquery' ), THEMESIA_VERSION, false );
    wp_enqueue_script( 'ts-filter', get_template_directory_uri() . '/assets/js/filter.js', array( 'jquery' ), THEMESIA_VERSION, true );
	wp_enqueue_script( 'ts-events', get_template_directory_uri() . '/assets/js/tsevents.js', array( 'ts-functions' ), THEMESIA_VERSION, true );
	
}
add_action( 'wp_enqueue_scripts', 'themesia_assets' );

function remove_wp_block_library_css(){
    wp_dequeue_style( 'wp-block-library' );
    wp_dequeue_style( 'wp-block-library-theme' );
    wp_dequeue_style( 'wc-blocks-style' );
	wp_dequeue_style( 'global-styles' );
} 
add_action( 'wp_enqueue_scripts', 'remove_wp_block_library_css', 100 );

function themesia_footer_assets() {
	wp_enqueue_script( 'ts-owl-carousel', get_template_directory_uri() . '/assets/js/owl.carousel.min.js', array( 'jquery' ), '2.3.4.1', false );
	wp_enqueue_style( 'ts-fontawesome', get_template_directory_uri() . '/assets/css/font-awesome.min.css',[],'5.13.0','all');
	wp_enqueue_style( 'ts-owl-carousel', get_template_directory_uri() . '/assets/css/owl.carousel.css',[], THEMESIA_VERSION,'all');
	
	if(is_singular('series')){ 
		if(get_option('traileranime')=='1'){wp_enqueue_style( 'ts-fancybox', get_template_directory_uri() . '/assets/css/fancybox.css',[],'4.0.19','all');}
		if(get_option('galleryanime')=='1'){wp_enqueue_style( 'ts-blueimp', get_template_directory_uri() . '/assets/css/blueimp-gallery.min.css',[],'3.4.0','all');}
	}
}
add_action( 'get_footer', 'themesia_footer_assets' );

add_action ('wp_head','themesiaHeader');
function themesiaHeader(){ ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fira+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700&family=Poppins:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">
<?php echo get_option('tsscriptheader'); ?>
<script>
	$(document).ready(function(){
		$(".shme").click(function(){
			$(".mm").toggleClass("shwx");
		});
		$(".expand").click(function(){
			$(".megavid").toggleClass("xp");
			$(".pd-expand").toggleClass("sxp");
		});
		$('.expand').click(function() {
			if ($('.expand').hasClass('slamdown')){
				$('.expand').removeClass('slamdown');
				jQuery(".mvelement").prependTo(jQuery(".megavid"));
			} else {
				$('.expand').addClass('slamdown');
				jQuery(".mvelement").appendTo(jQuery(".pd-expand"));
			  }
		});
		$(".gnr").click(function(){
			$(".gnrx").toggleClass("shwgx");
		});
		$(".light").click(function(){
			$(".lowvid").toggleClass("highvid");
		});
		$(".colap").click(function(){
			$(".mindes").toggleClass("alldes");
		});
		$(".topmobile").click(function(){
			$(".topmobcon").toggleClass("topmobshow");
		});
		$(".srcmob").click(function(){
			$(".minmb").toggleClass("minmbx");
		});
	});
	</script>
	
	<?php $tc = get_option('themecolor'); if($tc) { ?>
		<style>
			body {background: #ededed;}
			.darkmode .bxcl ul li span.dt a{background:#30353c;}
			#main-menu,.soraddlx .sorattlx,.releases .vl,.serieslist.pop ul li.topone .limit .bw .ctr,#footer .footermenu,.bigcontent .infox .spe span:before,.commentx #submit,.naveps .nvsc a,.radiox input:checked ~ .checkmarkx,.advancedsearch button.searchz,.lista a:hover,.bxcl ul li span.dt a:hover,.bookmark,.bs .bsx .limit .typez.Drama,.hpage a,.slider:before,.darkmode .naveps .nvsc a,.darkmode .lista a,.darkmode .nav_apb a:hover,#sidebar .section ul.season li:before,#sidebar .section ul.season::-webkit-scrollbar-thumb,#sidebar .section .ongoingseries ul li a .l .fa, #sidebar .section .ongoingseries ul li a .r,.releases.latesthome,.quickfilter .filters .filter.submit button,.footer-az .az-list li a,.stylesix .bsx .upscore,.stylefor .bsx .tt span i,.soraddlx .soraurlx strong,.bxcl ul li:hover,.darkmode .quickfilter .filters .filter.submit button,.darkmode .bxcl ul li:hover,#sidebar .section .ongoingseries ul::-webkit-scrollbar-thumb,.bxcl ul::-webkit-scrollbar-thumb,.bigcontent .infox .genxed a:hover,.lastend .inepcx a,.single-info.bixbox .infox .spe span:before,.single-info.bixbox .infox .genxed a:hover,.series-gen .nav-tabs li.active a,.naveps.bignav .nvs.nvsc a,.darkmode .naveps.bignav .nvs.nvsc a,#top-menu li a:hover,.topmobile,#sidebar .section .ongoingseries ul li a .l .fas,.comment-list .comment-body .reply a:hover,.bloglist .blogbox .innerblog .thumb .btags,.bixbox .bvl,.tsboxedwrap .releases.latesthome, .darkmode .tsboxedwrap .releases.latesthome,#sidebar .section .ts-wpop-series-gen .ts-wpop-nav-tabs li.active span,.darkmode .tsboxedwrap .th,.bixbox .bvlcen .bvl,.paginationjs ul li.active a{background:<?php echo $tc; ?>;}
			.pagination span.page-numbers.current,#gallery.owl-loaded .owl-dots .owl-dot.active span,.gov-multipart .gov-the-embed:hover, .darkmode .gov-multipart .gov-the-embed:hover,.gov-multipart .gov-the-embed.active, .darkmode .gov-multipart .gov-the-embed.active,.taxindex li a:hover,.darkmode .taxindex li a:hover{background:<?php echo $tc; ?> !important;}
			.releases span,.advancedsearch button.searchz,.lista a:hover,.darkmode .lista a,.stylefor .bsx:hover,.bxcl ul li:hover,.single-info.bixbox .infox .genxed a:hover,.comment-list .comment-body .reply a {border-color:<?php echo $tc; ?>;}
			.surprise:hover {color: #FFF;background: #333;}
			a:hover,.listupd .lexa .dtl h2 a:hover,.live-search_result_container a:hover,.footer-az .az-list li a:hover,.bxcl ul li span.dt a .dashicons .darkmode #sidebar .section .serieslist ul li .leftseries span a,.stylefor a:hover,.seventh .main-seven .tt .sosev span a:hover,.stylesix .bsx .inf span a,.epl-num a,.bixbox.episodedl .epwrapper .epheader .entry-info a,.darkmode a:hover,.dlbox ul li span a,.single-info.bixbox .infox .infolimit h2,.comment-list .comment-body .reply a,.single-info.bixbox .infox .spe span a,.cmt .must-log-in a, .bigcontent .infox .spe span a,.stylesix .bsx .inf ul li a,.stylenine .bsx .inf span a,.meta .year a,.darkmode .meta .year a:hover,.blogpost .entry-header .entry-meta a,.darkmode .blogpost .entry-header .entry-meta a:hover{color:<?php echo $tc; ?>;}
			.footer-az .az-list li a:hover{color:<?php echo $tc; ?> !important;}
			.releases h1,.releases h3,#sidebar .section h4 {color:#333}
			.bs .bsx .limit .ply {background:rgba(0,0,0,0.5);}
			#main-menu ul li a:hover {text-decoration:none;color:#FFF;background:#333}
			.serieslist ul li .ctr,.bigcontent .infox .genxed a,.single-info.bixbox .infox .genxed a{color:<?php echo $tc; ?>;border-color:<?php echo $tc; ?>;}
			.darkmode .bigcontent .infox .genxed a,.darkmode .single-info.bixbox .infox .genxed a{color:#CCC}
			.darkmode .bigcontent .infox .genxed a:hover,.darkmode .single-info.bixbox .infox .genxed a:hover,.darkmode .single-info.bixbox .infox .infolimit h2{color:#FFF}
			.modex a {background: #333;}
			.modex a:hover,.stylefor .bsx .tt span i,.darkmode .naveps.bignav .nvs.nvsc a {color: #FFF;}
			.bigcontent .rt .rating,.bxcl ul li span.dt a{background: #f8f8f8;}
			.bookmark:hover{background:#1d1b26}
			.darkmode .lista a:hover{background:#333}
			@media only screen and (max-width: 800px){
				.th,.darkmode .th{background:<?php echo $tc; ?>;}
				#main-menu{background:#222;}
				.surprise{background:<?php echo $tc; ?>;}
			}
		</style>
	<?php } ?>
	<?php $hc = get_option('hotupdatecolor'); if($hc) { ?><style>.releases.hothome,.tsboxedwrap .releases.hothome, .darkmode .tsboxedwrap .releases.hothome{background:<?php echo $hc; ?>;}</style><?php } ?>

	<script type='text/javascript'>
	//<![CDATA[
	$(document).ready(function(){
	   $("#shadow").css("height", $(document).height()).hide();
	   $(".light").click(function(){
		  $("#shadow").toggle();
			 if ($("#shadow").is(":hidden"))
				$(this).html("<i class='far fa-lightbulb' aria-hidden='true'></i> <span><?php echo GOV_lang::get('episode_page_turn_off_light'); ?></span>").removeClass("turnedOff");
			 else
				$(this).html("<i class='fas fa-lightbulb' aria-hidden='true'></i> <span><?php echo GOV_lang::get('episode_page_turn_on_light'); ?></span>").addClass("turnedOff");
			 });

	  });
	//]]>
	</script>
<?php }

add_action ('wp_footer','themesiaFooter');
function themesiaFooter(){ ?>
<?php if(get_option('galleryanime')=='1'){ if(is_singular('series')){ ?>
<script>
$(document).ready(function() {
	$('.owl-carousel').owlCarousel({
		stagePadding: 50,
		loop:true,
		margin:10,
		responsive:{
			0:{
				items:1
			},
			600:{
				items:4
			},
			1000:{
				items:4
			}
		}
	});
});

	var isGalleryDragging = false;
	$("#gallery").on("mousedown touchstart", function() {
		isGalleryDragging = false;
	}).on("mousemove touchmove", function() {
		isGalleryDragging = true;
	}).on("mouseup touchend", function(event) {
		event.preventDefault();
		var wasGallerDragging = isGalleryDragging;
		isGalleryDragging = false;
		if (!wasGallerDragging) {
			event = event || window.event;
			var target = event.target || event.srcElement;
			var link = target.src ? target.parentNode : target;
			var options = { index: link, event: event };
			var links = this.getElementsByTagName('a');
			blueimp.Gallery(links, options);
		}
	});
	$("#gallery a").on("click", function(){return false;});
</script>
<div id="blueimp-gallery" class="blueimp-gallery blueimp-gallery-controls">
      <div class="slides"></div>
      <h3 class="title"></h3>
      <span class="prev">‹</span>
      <span class="next">›</span>
      <span class="close">×</span>
      <span class="play-pause"></span>
      <ol class="indicator"></ol>
</div>
<?php } } ?>
<?php floating(); ?>
<script>
var dmlogo1 = '<?php echo get_option('logo')?:""; ?>';
var dmlogo2 = '<?php echo get_option('logox')?:""; ?>';
jQuery("#thememode input[type='checkbox']").on('change', function(){
	var is_on = jQuery("#thememode input[type='checkbox']").prop("checked");
	if (is_on == false){
		if (dmlogo2) {
			jQuery(".logos img").attr('src', dmlogo2);
			//jQuery(".footer-logo img").attr('src', dmlogo2);
		}
		localStorage.setItem("thememode", "lightmode");
		jQuery("body").addClass("lightmode");
		jQuery("body").removeClass("darkmode");
		
	}else{
		if (dmlogo1) {
			jQuery(".logos img").attr('src', dmlogo1);
			//jQuery(".footer-logo img").attr('src', dmlogo1);
		}
		localStorage.setItem("thememode", "darkmode");
		jQuery("body").removeClass("lightmode");
		jQuery("body").addClass("darkmode");
	}
	updateFooterLogo();
});
</script>
<?php echo get_option('tsscriptfooter'); ?>

<script>
jQuery.event.special.touchstart = {
    setup: function( _, ns, handle ) {
        this.addEventListener("touchstart", handle, { passive: !ns.includes("noPreventDefault") });
    }
};
jQuery.event.special.touchmove = {
    setup: function( _, ns, handle ) {
        this.addEventListener("touchmove", handle, { passive: !ns.includes("noPreventDefault") });
    }
};
jQuery.event.special.wheel = {
    setup: function( _, ns, handle ){
        this.addEventListener("wheel", handle, { passive: true });
    }
};
jQuery.event.special.mousewheel = {
    setup: function( _, ns, handle ){
        this.addEventListener("mousewheel", handle, { passive: true });
    }
};
</script>
<?php } 
function ts_list_mode_add_rewrite_rules(){
	$slug = get_option('changeslug'); 
	if ( ! $slug || ! strlen($slug)) $slug = "series";
	add_rewrite_rule("^{$slug}/list-mode/?$", "index.php?themesia-animelist=true", "top");
}
add_action("init", "ts_list_mode_add_rewrite_rules");

function ts_list_mode_add_var( $query_vars ) {
	$query_vars[] = "themesia-animelist";
	return $query_vars;
}
add_filter( "query_vars", "ts_list_mode_add_var" );

add_action( 'template_include', 'ts_list_mode_catch_page' );
function ts_list_mode_catch_page($original){
    if($page = get_query_var( 'themesia-animelist' )){
		remove_filter( 'wp_title', 'filter_wp_title' );
		add_filter('wp_title', function($title){
			return "List Mode - " . get_bloginfo('name');
		},99999);
		add_filter('pre_get_document_title', function($title){
			return "List Mode - " . get_bloginfo('name');
		},99999);
		$_GET['list'] = "list";
		return get_template_directory(). "/archive-series.php";
    }
	return $original;
}

add_filter('manage_post_posts_columns', 'add_ts_views_column');
add_filter('manage_series_posts_columns', 'add_ts_views_column');
add_action('manage_post_posts_custom_column', 'add_ts_views_column_content');
add_action('manage_series_posts_custom_column', 'add_ts_views_column_content');
function add_ts_views_column($defaults) {
	$defaults['ts-views'] = __( 'Views', 'ts_post_views' );
	return $defaults;
}

function add_ts_views_column_content($column_name) {
	if ($column_name === 'ts-views' ) {
		echo get_post_meta(get_the_ID(),'wpb_post_views_count',true);
	}
}

add_filter( 'manage_edit-post_sortable_columns', 'sort_ts_postviews_column');
add_filter( 'manage_edit-series_sortable_columns', 'sort_ts_postviews_column' );
function sort_ts_postviews_column( $defaults ) {
	$defaults['ts-views'] = 'views';
	return $defaults;
}
add_action('pre_get_posts', 'sort_ts_views');
function sort_ts_views($query) {
	if ( ! is_admin() ) {
		return;
	}
	$orderby = $query->get('orderby');
	if ( 'views' === $orderby ) {
		$query->set( 'meta_key', 'wpb_post_views_count' );
		$query->set( 'orderby', 'meta_value_num' );
	}
}

define("THEMESIA_DS_MIRROR_EP", "v");
add_action('init', 'ts_add_mirror_endpoints');
function ts_add_mirror_endpoints(){
    add_rewrite_endpoint(THEMESIA_DS_MIRROR_EP, EP_PERMALINK | EP_PAGES);
}

add_filter('front-ts-config-js', function($value){
	global $wpdb;
	if ( ! is_array($value)) $value = [];
	// merge lang array if exists
	if (isset($value['lang']) && is_array($value['lang'])) {
		$value['lang'] = array_merge($value['lang'], GOV_lang::front_languages());
	} else {
		$value['lang'] = GOV_lang::front_languages();
	}
	if ( ! isset($value['general'])) $value['general'] = [];
	$value['general']['site_url'] = get_site_url();
	$value['general']['defaultTheme'] = get_option('defaulttheme');
	$value['general']['ajaxUrl'] = admin_url('admin-ajax.php');
	$value['general']['mirrorJsLoad'] = (get_option('tsmjsload') === "0" || get_option('tsmjsload') === 0) ? false : true;

	/*
	$value['general']['homeUrl'] = esc_url( home_url( '/' ) );
	// is homepage 
	$value['general']['isHome'] = is_home() || is_front_page();
	// is series page
	$value['general']['isSeriesPage'] = is_singular('series');
	// is chapter page
	$value['general']['isPostPage'] = is_singular('post');

	// latest update hash 
	if (!$last_update = GOV_cache::object_cache_get('ts-config-last-update')) {
		$last_update = $wpdb->get_var("SELECT post_modified_gmt FROM {$wpdb->posts} WHERE post_type = 'series' AND post_status = 'publish' ORDER BY post_modified_gmt DESC LIMIT 1");
	}
	
	$value['general']['lastUpdate'] = GOV_cache::object_cache("ts-config-last-update", ($last_update ? $last_update : ''), 3600 * 24 * 1); // cache for 30 days
	*/
	
	return $value;
}, 99);

function add_ts_configs_inline_script() {
	$data = apply_filters('front-ts-config-js', []);
	$data = apply_filters('ts_front_config_js', $data);

	$js = 'const ts_configs={params:%s,exists(p){if(!p||typeof p!=="string")return!1;const k=p.split(".");let o=this.params;for(let i of k){if(o==null||!Object.prototype.hasOwnProperty.call(o,i))return!1;o=o[i];}return!0;},get(p,f=void 0){if(!p||typeof p!=="string")return typeof f==="function"?f(p):f;try{const v=p.split(".").reduce((o,k)=>o[k],this.params);return v!==void 0?v:typeof f==="function"?f(p):f;}catch{return typeof f==="function"?f(p):f;}},set(p,v){if(!p||typeof p!=="string")return;const k=p.split(".");let o=this.params;while(k.length>1){const i=k.shift();if(!o[i]||typeof o[i]!=="object")o[i]={};o=o[i];}o[k[0]]=v;},delete(p){if(!this.exists(p))return!1;const k=p.split(".");let o=this.params;for(let i=0;i<k.length-1;i++)o=o[k[i]];return delete o[k[k.length-1]];}};';

	$script = sprintf($js, json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
	wp_add_inline_script('jquery', $script);
}
add_action('admin_enqueue_scripts', 'add_ts_configs_inline_script', 98);
add_action('wp_enqueue_scripts', 'add_ts_configs_inline_script', 98);


add_filter('ts-post-is-pushing', function($value){
	return $value;
});

ts_core_hooks();
ts_core_hooks_one();
ts_core_hooks_ole();