<?php
if (!defined('ABSPATH')) exit;

/**
 * Advanced Episode system.
 * The button is intentionally available from the Series' CURRENT LATEST REAL episode.
 * Advanced placeholders are hidden from homepage episode queries and become real episodes
 * when the Anikoto importer receives that episode number.
 */
function dramastream_is_advanced_episode($post_id=0){
    $post_id = $post_id ? (int)$post_id : get_the_ID();
    return (bool) get_post_meta($post_id, '_dramastream_advanced_episode', true);
}


/** Return a reliable public Series URL for an episode. The importer stores the
 * Series ID in _anikoto_series_id, while older posts use ero_seri. Always use
 * the registered /series/<slug>/ rewrite instead of trusting legacy values. */
function dramastream_get_series_url_from_episode($episode_id=0){
    $episode_id = $episode_id ? (int)$episode_id : get_the_ID();
    if(!$episode_id) return home_url('/');

    $series_id = (int)get_post_meta($episode_id, '_anikoto_series_id', true);
    if(!$series_id || get_post_type($series_id)!=='series'){
        $series_id = (int)get_post_meta($episode_id, 'ero_seri', true);
    }

    // Legacy/imported posts can contain a stale series pointer. Resolve it from
    // the importer metadata before falling back to the legacy pointer.
    if(!$series_id || get_post_type($series_id)!=='series'){
        $series_title = trim((string)get_post_meta($episode_id, '_anikoto_series_title', true));
        if($series_title===''){
            $legacy_id = (int)get_post_meta($episode_id, 'ero_seri', true);
            if($legacy_id) $series_title = trim((string)get_the_title($legacy_id));
        }
        if($series_title!==''){
            $q = new WP_Query([
                'post_type'=>'series','post_status'=>'publish','posts_per_page'=>1,
                'fields'=>'ids','title'=>$series_title, 'no_found_rows'=>true
            ]);
            if(!empty($q->posts)) $series_id=(int)$q->posts[0];
            wp_reset_postdata();
        }
    }

    if($series_id && get_post_type($series_id)==='series'){
        $slug = get_post_field('post_name',$series_id);
        if($slug!=='') return home_url(user_trailingslashit('series/'.$slug));
        return get_permalink($series_id);
    }

    return home_url('/');
}

function dramastream_episode_number_value($post_id){
    $v = get_post_meta((int)$post_id, 'ero_episodebaru', true);
    if ($v === '' || $v === null) $v = get_post_meta((int)$post_id, '_anikoto_episode_number', true);
    return $v === '' ? null : (float)$v;
}

/** Find the highest numbered NON-advanced episode belonging to a Series. */
function dramastream_get_current_latest_episode_id($series_id){
    $series_id = (int)$series_id;
    if (!$series_id) return 0;

    $stored = (int)get_post_meta($series_id, 'ero_latestid', true);
    if ($stored && !dramastream_is_advanced_episode($stored) && (int)get_post_meta($stored, 'ero_seri', true) === $series_id) {
        return $stored;
    }

    $posts = get_posts([
        'post_type'      => 'post',
        'post_status'    => ['publish','draft','pending','future','private'],
        'posts_per_page' => -1,
        'fields'         => 'ids',
        'meta_query'     => [
            ['key'=>'ero_seri','value'=>$series_id,'compare'=>'='],
            ['key'=>'_dramastream_advanced_episode','compare'=>'NOT EXISTS'],
        ],
        'orderby' => 'ID',
        'order'   => 'DESC',
    ]);

    $best_id = 0;
    $best_num = -1;
    foreach ((array)$posts as $id) {
        $num = dramastream_episode_number_value($id);
        if ($num === null) continue;
        if ($num > $best_num) {
            $best_num = $num;
            $best_id = (int)$id;
        }
    }
    return $best_id;
}


/** Return the highest numbered published NON-advanced episode for a Series. */
function dramastream_get_latest_real_episode_id($series_id){
    $series_id=(int)$series_id;
    if(!$series_id) return 0;
    $stored=(int)get_post_meta($series_id,'ero_latestid',true);
    if($stored && !dramastream_is_advanced_episode($stored) && (int)get_post_meta($stored,'ero_seri',true)===$series_id && get_post_status($stored)==='publish') return $stored;
    $q=new WP_Query([
        'post_type'=>'post','post_status'=>'publish','posts_per_page'=>1,'fields'=>'ids','no_found_rows'=>true,
        'meta_query'=>[
            ['key'=>'ero_seri','value'=>$series_id,'compare'=>'='],
            ['key'=>'_dramastream_advanced_episode','compare'=>'NOT EXISTS'],
        ],
        'meta_key'=>'ero_episodebaru','orderby'=>'meta_value_num','order'=>'DESC',
    ]);
    $id=!empty($q->posts)?(int)$q->posts[0]:0;
    if($id){
        $num=get_post_meta($id,'ero_episodebaru',true);
        update_post_meta($series_id,'ero_latest',(string)$num);
        update_post_meta($series_id,'ero_latestid',$id);
    }
    return $id;
}

function dramastream_get_latest_real_episode_number($series_id){
    $id=dramastream_get_latest_real_episode_id($series_id);
    return $id ? dramastream_episode_number_value($id) : null;
}

/** Render the series episode list without relying on the protected epls() helper. */

function dramastream_episode_language_badges($episode_id,$series_id=0){
    $episode_id=(int)$episode_id; $series_id=(int)$series_id;
    $found=[];
    $raw=get_post_meta($episode_id,'_anikoto_servers',true);
    if(is_string($raw)) $raw=json_decode($raw,true);
    foreach((array)$raw as $sv){
        $type=strtoupper(trim((string)($sv['type']??$sv['name']??'')));
        if($type==='SUB') $found['Sub']='Sub';
        if($type==='DUB') $found['Dub']='Dub';
    }
    if(!$found){
        $v=get_post_meta($episode_id,'ero_subepisode',true);
        if($v==='' || $v==='None') $v=$series_id?get_post_meta($series_id,'ero_sub',true):'';
        $v=strtoupper(trim((string)$v));
        if(strpos($v,'DUB')!==false) $found['Dub']='Dub';
        if(strpos($v,'SUB')!==false || !$found) $found['Sub']='Sub';
    }
    return array_values($found);
}

function dramastream_render_episode_list($series_id){
    $series_id=(int)$series_id;
    if(!$series_id) return;
    $q=new WP_Query([
        'post_type'=>'post','post_status'=>'publish','posts_per_page'=>5000,'no_found_rows'=>true,
        'meta_query'=>[
            ['key'=>'ero_seri','value'=>$series_id,'compare'=>'='],
            ['key'=>'_dramastream_advanced_episode','compare'=>'NOT EXISTS'],
        ],
        'meta_key'=>'ero_episodebaru','orderby'=>'meta_value_num','order'=>'DESC',
    ]);
    $count=0;
    foreach($q->posts as $ep){
        $id=(int)$ep->ID;
        $num=dramastream_episode_number_value($id);
        if($num===null) continue;
        $title=get_post_meta($id,'ero_episodetitle',true);
        if($title==='') $title=get_the_title($id);
        $sub=get_post_meta($id,'ero_subepisode',true);
        if($sub==='' || $sub==='None') $sub=get_post_meta($series_id,'ero_sub',true);
        $sub_label=$sub;
        if(function_exists('rwmb_the_value')){
            $tmp=rwmb_the_value('ero_subepisode','',$id,false);
            if($tmp!=='') $sub_label=$tmp;
            elseif($sub==='Sub') $sub_label='Sub';
            elseif($sub==='Dub') $sub_label='Dub';
        }
        $class=$sub ? ' '.sanitize_html_class($sub) : '';
        $count++;
        echo '<li data-index="'.esc_attr($count).'">';
        echo '<a href="'.esc_url(get_permalink($id)).'">';
        echo '<div class="epl-num">'.esc_html(dramastream_format_episode_number($num)).'</div>';
        echo '<div class="epl-title">'.esc_html($title).'</div>';
        if(get_option('eplsub')==='1' && $sub_label!=='') echo '<div class="epl-sub"><span class="status'.esc_attr($class).'">'.esc_html($sub_label).'</span></div>';
        echo '<div class="epl-date">'.esc_html(get_the_date(get_option('date_format'),$id)).'</div>';
        echo '</a></li>';
    }
    wp_reset_postdata();
}

function dramastream_format_episode_number($num){
    $num = (float)$num;
    return rtrim(rtrim(number_format($num, 2, '.', ''), '0'), '.');
}

function dramastream_advanced_button_url($post_id){
    return wp_nonce_url(
        admin_url('admin-post.php?action=dramastream_create_advanced_episode&post_ID='.(int)$post_id),
        'dramastream_create_advanced_episode_'.(int)$post_id,
        '_advanced_nonce'
    );
}

/** Prominent Advanced Episode panel in the editor sidebar. */
function dramastream_advanced_meta_box($post){
    $post_id  = (int)$post->ID;
    $series_id = (int)get_post_meta($post_id, 'ero_seri', true);
    $ep = dramastream_episode_number_value($post_id);
    $latest_id = $series_id ? dramastream_get_current_latest_episode_id($series_id) : 0;
    $is_latest = $latest_id === $post_id;
    $is_advanced = dramastream_is_advanced_episode($post_id);

    echo '<div class="dramastream-advanced-box">';
    echo '<p><strong style="font-size:15px;">Advanced Episode</strong></p>';

    if ($is_advanced) {
        echo '<p style="color:#d63638;font-weight:600;">This is an Advanced Episode.</p>';
        echo '<p>Player: <code>NOT ARRIVED YET!</code></p>';
        echo '<p class="description">When the importer receives this episode, this same post automatically becomes the live episode.</p>';
        echo '</div>';
        return;
    }

    if (!$series_id) {
        echo '<p class="description">Select a Series first. The Advanced Episode button appears on the current Latest Episode.</p>';
        echo '</div>';
        return;
    }

    echo '<p>Current Episode: <strong>'.esc_html($ep !== null ? dramastream_format_episode_number($ep) : '—').'</strong></p>';

    if ($is_latest) {
        $next = (int)$ep + 1;
        $url = dramastream_advanced_button_url($post_id);
        echo '<p><a class="button button-primary button-large" style="width:100%;text-align:center;" href="'.esc_url($url).'">+ Create Advanced Episode '.esc_html($next).'</a></p>';
        echo '<p class="description">Creates Episode '.esc_html($next).' now. It stays hidden from the homepage and shows <code>NOT ARRIVED YET!</code> until imported.</p>';
    } else {
        echo '<p class="description">This is not the current Latest Episode. Open the latest episode post to create the next Advanced Episode.</p>';
        if ($latest_id) {
            echo '<p><a class="button" href="'.esc_url(get_edit_post_link($latest_id)).'">Open Latest Episode</a></p>';
        }
    }
    echo '</div>';
}

function dramastream_add_advanced_meta_box(){
    add_meta_box(
        'dramastream_advanced_episode',
        'Advanced Episode',
        'dramastream_advanced_meta_box',
        'post',
        'side',
        'high'
    );
}
add_action('add_meta_boxes', 'dramastream_add_advanced_meta_box');

/** Also put a clear button directly in the Publish box, so it cannot be missed. */
function dramastream_advanced_submitbox_button(){
    global $post;
    if (!$post || $post->post_type !== 'post' || !current_user_can('edit_post', $post->ID)) return;

    $series_id = (int)get_post_meta($post->ID, 'ero_seri', true);
    $ep = dramastream_episode_number_value($post->ID);
    if (!$series_id || $ep === null || dramastream_is_advanced_episode($post->ID)) return;
    if (dramastream_get_current_latest_episode_id($series_id) !== (int)$post->ID) return;

    $next = (int)$ep + 1;
    $url = dramastream_advanced_button_url($post->ID);
    echo '<div class="misc-pub-section" style="padding:12px 0 4px;">';
    echo '<a href="'.esc_url($url).'" class="button button-primary" style="width:100%;text-align:center;font-weight:600;">+ Advanced Episode '.$next.'</a>';
    echo '<p style="font-size:11px;margin:7px 0 0;color:#646970;">Create the next episode as NOT ARRIVED YET. It will go live automatically when imported.</p>';
    echo '</div>';
}
add_action('post_submitbox_misc_actions', 'dramastream_advanced_submitbox_button');

function dramastream_create_advanced_episode(){
    if (!current_user_can('edit_posts')) wp_die('Forbidden');

    $post_id = absint($_GET['post_ID'] ?? $_POST['post_ID'] ?? 0);
    $nonce = $_GET['_advanced_nonce'] ?? $_POST['_advanced_nonce'] ?? '';
    if (!$post_id || !wp_verify_nonce($nonce, 'dramastream_create_advanced_episode_'.$post_id)) wp_die('Security check failed');
    if (!current_user_can('edit_post', $post_id)) wp_die('Forbidden');

    $series_id = (int)get_post_meta($post_id, 'ero_seri', true);
    $current = dramastream_episode_number_value($post_id);
    $latest_id = dramastream_get_current_latest_episode_id($series_id);

    if (!$series_id || $current === null || $latest_id !== $post_id) {
        wp_die('Advanced Episode can only be created from the current Latest Episode.');
    }

    $next = (string)((int)$current + 1);
    $existing = get_posts([
        'post_type'=>'post', 'post_status'=>'any', 'posts_per_page'=>1, 'fields'=>'ids',
        'meta_query'=>[
            ['key'=>'ero_seri','value'=>$series_id,'compare'=>'='],
            ['key'=>'ero_episodebaru','value'=>$next,'compare'=>'='],
        ]
    ]);

    if (!empty($existing)) {
        $existing_id = (int)$existing[0];
        // If it is already a real episode, simply open it; never duplicate it.
        wp_safe_redirect(get_edit_post_link($existing_id, 'url'));
        exit;
    }

    $series_title = get_the_title($series_id);
    $new_id = wp_insert_post([
        'post_type'=>'post',
        'post_status'=>'publish',
        'post_title'=>sanitize_text_field($series_title.' Episode '.$next),
        'post_content'=>'',
    ], true);
    if (is_wp_error($new_id)) wp_die(esc_html($new_id->get_error_message()));

    update_post_meta($new_id, 'ero_seri', $series_id);
    update_post_meta($new_id, 'ero_episodebaru', $next);
    update_post_meta($new_id, 'ero_episodetitle', '');
    update_post_meta($new_id, '_anikoto_series_id', $series_id);
    update_post_meta($new_id, '_anikoto_series_title', sanitize_text_field($series_title));
    update_post_meta($new_id, '_anikoto_episode_number', $next);
    update_post_meta($new_id, '_dramastream_advanced_episode', 1);
    update_post_meta($new_id, '_dramastream_advanced_created_from', $post_id);
    update_post_meta($new_id, '_dramastream_advanced_created_at', current_time('mysql'));

    if (has_post_thumbnail($series_id)) set_post_thumbnail($new_id, get_post_thumbnail_id($series_id));
    if (function_exists('anikoto_sync_episode_keyphrase')) anikoto_sync_episode_keyphrase($new_id);

    wp_safe_redirect(get_edit_post_link($new_id, 'url'));
    exit;
}
add_action('admin_post_dramastream_create_advanced_episode', 'dramastream_create_advanced_episode');

/** Never let an Advanced placeholder become the Series latest pointer. */
function dramastream_protect_latest_pointer($q){
    if (is_admin() || !$q->is_main_query()) return;
    if (!$q->is_home() && !$q->is_front_page()) return;
    $meta = $q->get('meta_query');
    if (!is_array($meta)) $meta = [];
    $meta[] = ['key'=>'_dramastream_advanced_episode','compare'=>'NOT EXISTS'];
    $q->set('meta_query', $meta);
}
add_action('pre_get_posts', 'dramastream_protect_latest_pointer', 20);
