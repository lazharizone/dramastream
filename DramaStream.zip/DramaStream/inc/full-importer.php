<?php
/**
 * Anikoto All-Data Bulk Importer for DramaStream Theme
 * Dedicated Admin Slot for importing all data from https://anikototv.to/home and catalog.
 *
 * @package AnimeStream_Theme
 * Version: 2.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class DramaStream_Full_Data_Importer {

    const SOURCE_HOME_URL = 'https://anikototv.to/home';
    const API_CATALOG_URL = 'https://anikotoapi.site/recent-anime';
    const API_SERIES_URL  = 'https://anikotoapi.site/series/';

    public function __construct() {
        add_action('admin_menu', [$this, 'register_admin_menu']);
        add_action('wp_ajax_animestream_full_get_queue', [$this, 'ajax_get_queue']);
        add_action('wp_ajax_animestream_full_import_item', [$this, 'ajax_import_item']);
        add_action('wp_ajax_animestream_full_purge_demo', [$this, 'ajax_purge_demo']);
    }

    /**
     * Register dedicated Admin Menu slot
     */
    public function register_admin_menu() {
        add_menu_page(
            __('Anikoto All-Data Importer', 'animestream'),
            __('ðŸ“¦ Anikoto All-Data', 'animestream'),
            'manage_options',
            'anikoto-all-data-importer',
            [$this, 'render_admin_page'],
            'dashicons-database-import',
            6
        );
    }

    /**
     * Helper to count AnimeStream episodes (post type 'post' with 'ero_seri')
     */
    public static function count_imported_episodes() {
        global $wpdb;
        $count = $wpdb->get_var("
            SELECT COUNT(DISTINCT p.ID) 
            FROM {$wpdb->posts} p
            INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
            WHERE p.post_type = 'post' 
              AND p.post_status = 'publish' 
              AND (pm.meta_key = 'ero_seri' OR pm.meta_key = '_anikoto_series_id')
        ");
        return (int) $count;
    }

    /**
     * Render modern DramaStream-styled Admin Page
     */
    public function render_admin_page() {
        $total_series   = wp_count_posts('series')->publish ?? 0;
        $total_episodes = self::count_imported_episodes();
        $nonce          = wp_create_nonce('animestream_full_import_nonce');
        ?>
        <div class="wrap dramastream-full-admin-wrap" style="max-width: 1040px; margin-top: 25px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
            
            <!-- Header Banner -->
            <div style="background: linear-gradient(135deg, #0e1014 0%, #171b24 100%); color: #fff; padding: 24px 28px; border-radius: 8px; border: 1px solid #232a36; margin-bottom: 24px; box-shadow: 0 8px 30px rgba(0,0,0,0.5); border-left: 5px solid #00c0fa;">
                <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
                    <div>
                        <h1 style="color: #fff; margin: 0 0 6px 0; font-size: 24px; display: flex; align-items: center; gap: 10px;">
                            <span>ðŸ“¦ Anikoto All-Data Importer</span>
                            <span style="font-size: 11px; background: #00c0fa; color: #000; padding: 3px 9px; border-radius: 4px; font-weight: 800; letter-spacing: 0.5px;">FULL DATA ENGINE</span>
                        </h1>
                        <p style="color: #8c98a9; margin: 0; font-size: 13px;">
                            <code>https://anikototv.to/home</code> aur pure catalog ka saara data (Series, Posters, Synopsis, Episodes aur working VideoJS players) 1-Click mein apni site mein daalein.
                        </p>
                    </div>
                    <div style="display: flex; gap: 12px;">
                        <div style="background: rgba(0,0,0,0.4); border: 1px solid #2c3545; padding: 8px 16px; border-radius: 6px; text-align: center;">
                            <div style="color: #8c98a9; font-size: 11px; text-transform: uppercase;">Series en Base de Datos</div>
                            <div id="stat-series-count" style="color: #00c0fa; font-size: 20px; font-weight: 700;"><?php echo esc_html($total_series); ?></div>
                        </div>
                        <div style="background: rgba(0,0,0,0.4); border: 1px solid #2c3545; padding: 8px 16px; border-radius: 6px; text-align: center;">
                            <div style="color: #8c98a9; font-size: 11px; text-transform: uppercase;">Episodios Activos</div>
                            <div id="stat-episodes-count" style="color: #d7385e; font-size: 20px; font-weight: 700;"><?php echo esc_html($total_episodes); ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Configuration Card -->
            <div style="background: #11141a; border: 1px solid #202735; border-radius: 8px; padding: 24px; margin-bottom: 24px;">
                <h3 style="color: #fff; margin: 0 0 16px 0; font-size: 16px; display: flex; align-items: center; gap: 8px;">
                    <span style="color: #00c0fa;">âš™ï¸</span> Seleccionar Origen de Datos (Source Selection)
                </h3>

                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px; margin-bottom: 20px;">
                    <!-- Option 1: Entire Home Page -->
                    <label style="background: #161b24; border: 2px solid #00c0fa; border-radius: 6px; padding: 16px; cursor: pointer; display: block; position: relative;">
                        <input type="radio" name="anikoto_source_mode" value="home" checked style="margin-right: 8px;">
                        <strong style="color: #fff; font-size: 14px;">ðŸ  Todo el Home de Anikoto</strong>
                        <p style="color: #8c98a9; font-size: 12px; margin: 8px 0 0 24px; line-height: 1.4;">
                            <code>anikototv.to/home</code> ki saari ~45-50 featured series (Recent Updates + Top Airing + Trending) aur unke sabhi episodes import karein.
                        </p>
                    </label>

                    <!-- Option 2: Full Catalog by Pages -->
                    <label style="background: #161b24; border: 1px solid #283243; border-radius: 6px; padding: 16px; cursor: pointer; display: block; position: relative;">
                        <input type="radio" name="anikoto_source_mode" value="catalog" style="margin-right: 8px;">
                        <strong style="color: #fff; font-size: 14px;">ðŸŒ CatÃ¡logo Completo (Por PÃ¡ginas)</strong>
                        <p style="color: #8c98a9; font-size: 12px; margin: 8px 0 0 24px; line-height: 1.4;">
                            Official catalog se jitne chahein utne pages import karein (Total 9,000+ anime uplabdh hain).
                        </p>
                    </label>

                    <!-- Option 3: Single URL -->
                    <label style="background: #161b24; border: 1px solid #283243; border-radius: 6px; padding: 16px; cursor: pointer; display: block; position: relative;">
                        <input type="radio" name="anikoto_source_mode" value="single" style="margin-right: 8px;">
                        <strong style="color: #fff; font-size: 14px;">ðŸŽ¯ URL EspecÃ­fica</strong>
                        <p style="color: #8c98a9; font-size: 12px; margin: 8px 0 0 24px; line-height: 1.4;">
                            Kisi ek anime series ya episode ka URL daalkar foran import karein.
                        </p>
                    </label>
                </div>

                <!-- Catalog Page Range Controls (hidden if Home selected) -->
                <div id="catalog-range-box" style="display: none; background: #0c0e12; border: 1px solid #232b3a; border-radius: 6px; padding: 14px 18px; margin-bottom: 20px; align-items: center; gap: 15px; flex-wrap: wrap;">
                    <span style="color: #c7d2e0; font-size: 13px; font-weight: 600;">Rango de PÃ¡ginas del CatÃ¡logo:</span>
                    <label style="color: #8c98a9; font-size: 12px;">
                        Desde PÃ¡gina: <input type="number" id="catalog-page-start" value="1" min="1" max="450" style="width: 70px; background: #161b24; border: 1px solid #2d384c; color: #fff; padding: 4px 8px; border-radius: 4px;">
                    </label>
                    <label style="color: #8c98a9; font-size: 12px;">
                        Hasta PÃ¡gina: <input type="number" id="catalog-page-end" value="3" min="1" max="450" style="width: 70px; background: #161b24; border: 1px solid #2d384c; color: #fff; padding: 4px 8px; border-radius: 4px;">
                    </label>
                    <span style="color: #556276; font-size: 11px;">(Har page mein ~20 anime series hoti hain)</span>
                </div>

                <!-- Single URL Input Box -->
                <div id="single-url-box" style="display: none; background: #0c0e12; border: 1px solid #232b3a; border-radius: 6px; padding: 14px 18px; margin-bottom: 20px;">
                    <label style="display: block; color: #c7d2e0; font-size: 13px; font-weight: 600; margin-bottom: 6px;">URL de Anikoto (Series o Episodio):</label>
                    <input type="url" id="single-url-input" placeholder="https://anikototv.to/watch/solo-leveling" style="width: 100%; box-sizing: border-box; background: #161b24; border: 1px solid #2d384c; color: #fff; padding: 8px 12px; border-radius: 4px; font-size: 13px;">
                </div>

                <!-- Feature Badges -->
                <div style="display: flex; gap: 15px; flex-wrap: wrap; margin-bottom: 22px;">
                    <label style="color: #00e676; font-size: 12px; font-weight: 600; display: inline-flex; align-items: center; gap: 6px;">
                        <input type="checkbox" id="opt-videojs-players" checked disabled>
                        <span>âœ“ Reproductores VideoJS MegaPlay (Cero Error 410)</span>
                    </label>
                    <label style="color: #00c0fa; font-size: 12px; font-weight: 600; display: inline-flex; align-items: center; gap: 6px;">
                        <input type="checkbox" id="opt-strip-seo" checked disabled>
                        <span>âœ“ Cero Copia de SEO Ajeno (Aislamiento Total)</span>
                    </label>
                    <label style="color: #ffd166; font-size: 12px; font-weight: 600; display: inline-flex; align-items: center; gap: 6px;">
                        <input type="checkbox" id="opt-skip-existing" checked>
                        <span>Omitir episodios ya existentes (Acelera importaciÃ³n)</span>
                    </label>
                </div>

                <!-- Action Buttons -->
                <div style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
                    <button type="button" id="btn-start-full-import" class="button button-primary" style="background: #00c0fa; border-color: #00a4d6; color: #000; font-weight: 800; font-size: 15px; padding: 8px 26px; height: auto; border-radius: 4px; display: inline-flex; align-items: center; gap: 8px; box-shadow: 0 4px 15px rgba(0,192,250,0.3);">
                        <span id="btn-start-icon">â–¶</span> <span id="btn-start-text">INICIAR IMPORTACIÃ“N COMPLETA</span>
                    </button>
                    <button type="button" id="btn-pause-import" class="button" style="display: none; background: #ffd166; border-color: #e0b349; color: #000; font-weight: 700; font-size: 14px; padding: 8px 18px; height: auto; border-radius: 4px;">
                        â¸ Pausar
                    </button>
                    <button type="button" id="btn-stop-import" class="button" style="display: none; background: #d7385e; border-color: #b8284b; color: #fff; font-weight: 700; font-size: 14px; padding: 8px 18px; height: auto; border-radius: 4px;">
                        â¹ Detener
                    </button>
                    <button type="button" id="btn-purge-demo" class="button" style="background: transparent; border: 1px dashed #3a4659; color: #8c98a9; font-size: 12px; padding: 6px 14px; height: auto; border-radius: 4px; margin-left: auto;">
                        ðŸ—‘ Limpiar datos demo / UUID antiguos
                    </button>
                </div>
            </div>

            <!-- Live Progress Card -->
            <div id="progress-card" style="background: #11141a; border: 1px solid #202735; border-radius: 8px; padding: 22px; margin-bottom: 24px; display: none;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                    <span id="progress-status-label" style="color: #fff; font-size: 14px; font-weight: 700;">Iniciando cola de importaciÃ³n...</span>
                    <span id="progress-percent" style="color: #00c0fa; font-size: 16px; font-weight: 800;">0%</span>
                </div>

                <!-- Animated Progress Bar Container -->
                <div style="background: #080a0d; border-radius: 6px; height: 16px; overflow: hidden; border: 1px solid #232b3a; margin-bottom: 16px;">
                    <div id="progress-bar-fill" style="width: 0%; height: 100%; background: linear-gradient(90deg, #00c0fa 0%, #00e676 100%); transition: width 0.3s ease;"></div>
                </div>

                <!-- Live Mini Stats Counters -->
                <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; text-align: center;">
                    <div style="background: #161b24; padding: 10px; border-radius: 6px; border: 1px solid #232b3a;">
                        <div style="color: #8c98a9; font-size: 11px;">TOTAL EN COLA</div>
                        <div id="count-queue-total" style="color: #fff; font-size: 18px; font-weight: 700;">0</div>
                    </div>
                    <div style="background: #161b24; padding: 10px; border-radius: 6px; border: 1px solid #232b3a;">
                        <div style="color: #8c98a9; font-size: 11px;">PROCESADOS</div>
                        <div id="count-processed" style="color: #00c0fa; font-size: 18px; font-weight: 700;">0</div>
                    </div>
                    <div style="background: #161b24; padding: 10px; border-radius: 6px; border: 1px solid #232b3a;">
                        <div style="color: #8c98a9; font-size: 11px;">EPISODIOS CREADOS</div>
                        <div id="count-episodes-created" style="color: #00e676; font-size: 18px; font-weight: 700;">0</div>
                    </div>
                    <div style="background: #161b24; padding: 10px; border-radius: 6px; border: 1px solid #232b3a;">
                        <div style="color: #8c98a9; font-size: 11px;">FALLIDOS</div>
                        <div id="count-failed" style="color: #d7385e; font-size: 18px; font-weight: 700;">0</div>
                    </div>
                </div>
            </div>

            <!-- Terminal Console Box -->
            <div style="background: #080a0d; border: 1px solid #1c222e; border-radius: 8px; padding: 18px; box-shadow: inset 0 2px 10px rgba(0,0,0,0.8);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; border-bottom: 1px solid #161b24; padding-bottom: 8px;">
                    <span style="color: #8c98a9; font-size: 12px; font-weight: 600; display: flex; align-items: center; gap: 6px;">
                        <span style="width: 8px; height: 8px; background: #00e676; border-radius: 50%; display: inline-block;"></span>
                        Consola de ImportaciÃ³n en Vivo
                    </span>
                    <button type="button" onclick="document.getElementById('console-log').innerHTML='';" style="background: none; border: none; color: #556276; font-size: 11px; cursor: pointer;">Limpiar Consola</button>
                </div>
                <div id="console-log" style="height: 240px; overflow-y: auto; font-family: 'Consolas', 'Courier New', monospace; font-size: 12px; line-height: 1.6; color: #a0aec0; scroll-behavior: smooth;">
                    <div style="color: #556276;">[Sistema] Listo para iniciar. Seleccione el modo y presione "Iniciar ImportaciÃ³n Completa".</div>
                </div>
            </div>

        </div>

        <script>
        (function() {
            var ajaxUrl = "<?php echo esc_url(admin_url('admin-ajax.php')); ?>";
            var nonce   = "<?php echo esc_js($nonce); ?>";
            var isRunning = false;
            var isPaused = false;
            var queue = [];
            var currentIndex = 0;
            var totalProcessed = 0;
            var totalEpisodes = 0;
            var totalFailed = 0;

            // Toggle Source options
            var radios = document.querySelectorAll('input[name="anikoto_source_mode"]');
            var rangeBox = document.getElementById('catalog-range-box');
            var singleBox = document.getElementById('single-url-box');

            radios.forEach(function(r) {
                r.addEventListener('change', function() {
                    radios.forEach(function(rb) { rb.closest('label').style.borderColor = '#283243'; });
                    r.closest('label').style.borderColor = '#00c0fa';
                    rangeBox.style.display = (r.value === 'catalog') ? 'flex' : 'none';
                    singleBox.style.display = (r.value === 'single') ? 'block' : 'none';
                });
            });

            function log(msg, type) {
                var box = document.getElementById('console-log');
                var d = new Date();
                var time = String(d.getHours()).padStart(2,'0') + ':' + String(d.getMinutes()).padStart(2,'0') + ':' + String(d.getSeconds()).padStart(2,'0');
                var color = '#a0aec0';
                if (type === 'success') color = '#00e676';
                if (type === 'info') color = '#00c0fa';
                if (type === 'warn') color = '#ffd166';
                if (type === 'error') color = '#d7385e';
                
                var el = document.createElement('div');
                el.style.color = color;
                el.innerHTML = '<span style="color:#556276;">[' + time + ']</span> ' + msg;
                box.appendChild(el);
                box.scrollTop = box.scrollHeight;
            }

            // Start Full Import
            document.getElementById('btn-start-full-import').addEventListener('click', function() {
                if (isRunning && isPaused) {
                    // Resume
                    isPaused = false;
                    document.getElementById('btn-pause-import').textContent = 'â¸ Pausar';
                    log('â–¶ Reanudando importaciÃ³n...', 'info');
                    processNext();
                    return;
                }

                if (isRunning) return;

                var mode = document.querySelector('input[name="anikoto_source_mode"]:checked').value;
                var pageStart = parseInt(document.getElementById('catalog-page-start').value, 10) || 1;
                var pageEnd   = parseInt(document.getElementById('catalog-page-end').value, 10) || 3;
                var singleUrl = document.getElementById('single-url-input').value.trim();

                if (mode === 'single' && !singleUrl) {
                    alert('Por favor introduce un URL de Anikoto vÃ¡lido.');
                    return;
                }

                isRunning = true;
                isPaused = false;
                queue = [];
                currentIndex = 0;
                totalProcessed = 0;
                totalEpisodes = 0;
                totalFailed = 0;

                document.getElementById('progress-card').style.display = 'block';
                document.getElementById('btn-pause-import').style.display = 'inline-block';
                document.getElementById('btn-stop-import').style.display = 'inline-block';
                document.getElementById('btn-start-full-import').disabled = true;

                log('ðŸš€ Preparando cola de anime desde ' + (mode === 'home' ? 'anikototv.to/home' : (mode === 'single' ? singleUrl : 'CatÃ¡logo API (PÃ¡gs ' + pageStart + '-' + pageEnd + ')')) + '...', 'info');

                var data = new FormData();
                data.append('action', 'animestream_full_get_queue');
                data.append('_nonce', nonce);
                data.append('mode', mode);
                data.append('page_start', pageStart);
                data.append('page_end', pageEnd);
                data.append('single_url', singleUrl);

                fetch(ajaxUrl, { method: 'POST', body: data })
                .then(function(r) { return r.json(); })
                .then(function(res) {
                    if (!res.success || !res.data || !res.data.queue || res.data.queue.length === 0) {
                        log('âŒ No se encontraron series para importar.', 'error');
                        finishImport();
                        return;
                    }

                    queue = res.data.queue;
                    document.getElementById('count-queue-total').textContent = queue.length;
                    log('âœ“ Cola lista: ' + queue.length + ' anime series encontradas. Iniciando procesamiento por lotes...', 'success');
                    processNext();
                })
                .catch(function(err) {
                    log('âŒ Error al obtener la cola: ' + err, 'error');
                    finishImport();
                });
            });

            // Pause
            document.getElementById('btn-pause-import').addEventListener('click', function() {
                if (!isRunning) return;
                isPaused = !isPaused;
                this.textContent = isPaused ? 'â–¶ Reanudar' : 'â¸ Pausar';
                log(isPaused ? 'â¸ ImportaciÃ³n pausada.' : 'â–¶ Reanudando...', 'warn');
                if (!isPaused) {
                    processNext();
                }
            });

            // Stop
            document.getElementById('btn-stop-import').addEventListener('click', function() {
                if (!isRunning) return;
                log('â¹ Deteniendo importaciÃ³n por solicitud del usuario...', 'warn');
                finishImport();
            });

            // Purge Demo Data
            document.getElementById('btn-purge-demo').addEventListener('click', function() {
                if (!confirm('Â¿EstÃ¡s seguro de que deseas limpiar series y episodios de prueba / UUID antiguos?')) return;
                var self = this;
                self.disabled = true;
                self.textContent = 'Limpiando...';

                var data = new FormData();
                data.append('action', 'animestream_full_purge_demo');
                data.append('_nonce', nonce);

                fetch(ajaxUrl, { method: 'POST', body: data })
                .then(function(r) { return r.json(); })
                .then(function(res) {
                    alert(res.data ? res.data.message : 'Listo');
                    location.reload();
                })
                .catch(function() {
                    alert('Error al limpiar datos');
                    self.disabled = false;
                    self.textContent = 'ðŸ—‘ Limpiar datos demo / UUID antiguos';
                });
            });

            function processNext() {
                if (!isRunning || isPaused) return;

                if (currentIndex >= queue.length) {
                    log('ðŸŽ‰ Â¡IMPORTACIÃ“N COMPLETA FINALIZADA CON Ã‰XITO! Todos los anime y episodios estÃ¡n listos.', 'success');
                    finishImport();
                    return;
                }

                var item = queue[currentIndex];
                var pct = Math.round(((currentIndex) / queue.length) * 100);
                document.getElementById('progress-bar-fill').style.width = pct + '%';
                document.getElementById('progress-percent').textContent = pct + '%';
                document.getElementById('progress-status-label').textContent = 'Importando (' + (currentIndex + 1) + '/' + queue.length + '): ' + (item.title || item.slug) + '...';

                var skipExisting = document.getElementById('opt-skip-existing').checked ? 1 : 0;

                var data = new FormData();
                data.append('action', 'animestream_full_import_item');
                data.append('_nonce', nonce);
                data.append('item[id]', item.id || 0);
                data.append('item[slug]', item.slug || '');
                data.append('item[title]', item.title || '');
                data.append('item[poster]', item.poster || '');
                data.append('item[url]', item.url || '');
                data.append('skip_existing', skipExisting);

                fetch(ajaxUrl, { method: 'POST', body: data })
                .then(function(r) { return r.json(); })
                .then(function(res) {
                    if (res.success && res.data) {
                        totalProcessed++;
                        totalEpisodes += (res.data.episodes_created || 0);
                        document.getElementById('count-processed').textContent = totalProcessed;
                        document.getElementById('count-episodes-created').textContent = totalEpisodes;

                        var epsMsg = res.data.episodes_created + ' episodios listos con VideoJS';
                        log('âœ¨ <strong>' + (res.data.title || item.title) + '</strong> (' + epsMsg + ')', 'success');
                    } else {
                        totalFailed++;
                        document.getElementById('count-failed').textContent = totalFailed;
                        log('âš ï¸ Error en ' + (item.title || item.slug) + ': ' + (res.data ? res.data.message : 'Error desconocido'), 'warn');
                    }
                })
                .catch(function(err) {
                    totalFailed++;
                    document.getElementById('count-failed').textContent = totalFailed;
                    log('âŒ Error de red con ' + (item.title || item.slug) + ': ' + err, 'error');
                })
                .finally(function() {
                    currentIndex++;
                    setTimeout(processNext, 200);
                });
            }

            function finishImport() {
                isRunning = false;
                isPaused = false;
                document.getElementById('btn-start-full-import').disabled = false;
                document.getElementById('btn-pause-import').style.display = 'none';
                document.getElementById('btn-stop-import').style.display = 'none';
                document.getElementById('progress-bar-fill').style.width = '100%';
                document.getElementById('progress-percent').textContent = '100%';
                document.getElementById('progress-status-label').textContent = 'Completado.';
            }

        })();
        </script>
        <?php
    }

    /**
     * AJAX: Get Anime Queue for Selected Source
     */
    public function ajax_get_queue() {
        check_ajax_referer('animestream_full_import_nonce', '_nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'No autorizado']);
        }

        $mode      = sanitize_key($_POST['mode'] ?? 'home');
        $pageStart = max(1, absint($_POST['page_start'] ?? 1));
        $pageEnd   = max($pageStart, absint($_POST['page_end'] ?? 3));
        $singleUrl = esc_url_raw(trim($_POST['single_url'] ?? ''));

        $queue = [];
        $seen  = [];

        if ($mode === 'single' && !empty($singleUrl)) {
            // Single URL Mode
            $slug = '';
            if (preg_match('~/watch/([^/?#]+)~i', $singleUrl, $sm)) {
                $slug = sanitize_title($sm[1]);
            }
            if (!$slug && preg_match('~/anime/([^/?#]+)~i', $singleUrl, $sm2)) {
                $slug = sanitize_title($sm2[1]);
            }
            if (!$slug) {
                $slug = sanitize_title(wp_basename(parse_url($singleUrl, PHP_URL_PATH)));
            }

            if ($slug) {
                $queue[] = [
                    'slug'   => $slug,
                    'title'  => ucwords(str_replace('-', ' ', $slug)),
                    'url'    => $singleUrl,
                    'poster' => '',
                ];
            }
        } elseif ($mode === 'home') {
            // Scrape https://anikototv.to/home
            $response = wp_remote_get(self::SOURCE_HOME_URL, [
                'timeout' => 20,
                'headers' => ['User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36']
            ]);

            if (is_wp_error($response)) {
                wp_send_json_error(['message' => 'No se pudo conectar con anikototv.to/home']);
            }

            $html = wp_remote_retrieve_body($response);

            // 1. Extract from item cards
            if (preg_match_all('/<div class="item"[\s\S]*?href="([^"]+)"[\s\S]*?alt="([^"]+)"[\s\S]*?src="([^"]+)"/i', $html, $matches, PREG_SET_ORDER)) {
                foreach ($matches as $m) {
                    $url = esc_url_raw($m[1]);
                    $title = html_entity_decode(trim($m[2]), ENT_QUOTES, 'UTF-8');
                    $poster = esc_url_raw($m[3]);
                    if (preg_match('#/(?:watch|anime)/([^/]+)#i', $url, $sm)) {
                        $slug = sanitize_title($sm[1]);
                        if (!isset($seen[$slug])) {
                            $seen[$slug] = true;
                            $queue[] = [
                                'slug'   => $slug,
                                'title'  => $title,
                                'url'    => $url,
                                'poster' => $poster,
                            ];
                        }
                    }
                }
            }

            // 2. Extract from all other /watch/ links on home page
            if (preg_match_all('/href="(https:\/\/anikototv\.to\/(?:watch|anime)\/([^"\/]+)[^"]*)"/i', $html, $allMatches, PREG_SET_ORDER)) {
                foreach ($allMatches as $m) {
                    $url = esc_url_raw($m[1]);
                    $slug = sanitize_title($m[2]);
                    if (!isset($seen[$slug])) {
                        $seen[$slug] = true;
                        $title = ucwords(str_replace('-', ' ', $slug));
                        $queue[] = [
                            'slug'   => $slug,
                            'title'  => $title,
                            'url'    => $url,
                            'poster' => '',
                        ];
                    }
                }
            }

        } else {
            // Catalog API mode across specified page range
            for ($p = $pageStart; $p <= $pageEnd; $p++) {
                $apiUrl = self::API_CATALOG_URL . '?page=' . $p . '&per_page=20';
                $resp = wp_remote_get($apiUrl, [
                    'timeout' => 15,
                    'headers' => ['Accept' => 'application/json', 'User-Agent' => 'Mozilla/5.0 WordPress Anikoto Importer']
                ]);

                if (is_wp_error($resp)) continue;
                $code = (int) wp_remote_retrieve_response_code($resp);
                if ($code !== 200) continue;

                $json = json_decode(wp_remote_retrieve_body($resp), true);
                if (!is_array($json) || empty($json['data'])) continue;

                foreach ($json['data'] as $row) {
                    if (empty($row['id'])) continue;
                    $id    = absint($row['id']);
                    $slug  = !empty($row['slug']) ? sanitize_title($row['slug']) : sanitize_title($row['title']);
                    $title = !empty($row['title']) ? sanitize_text_field($row['title']) : $slug;
                    $poster = !empty($row['poster']) ? esc_url_raw($row['poster']) : '';

                    if (!isset($seen[$id])) {
                        $seen[$id] = true;
                        $queue[] = [
                            'id'     => $id,
                            'slug'   => $slug,
                            'title'  => $title,
                            'poster' => $poster,
                        ];
                    }
                }
            }
        }

        wp_send_json_success(['queue' => $queue, 'total' => count($queue)]);
    }

    /**
     * AJAX: Import ONE anime series with all episodes & VideoJS players
     */
    public function ajax_import_item() {
        check_ajax_referer('animestream_full_import_nonce', '_nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'No autorizado']);
        }

        $item         = isset($_POST['item']) && is_array($_POST['item']) ? $_POST['item'] : [];
        $skipExisting = !empty($_POST['skip_existing']);

        $numericId = !empty($item['id']) ? absint($item['id']) : 0;
        $slug      = !empty($item['slug']) ? sanitize_title($item['slug']) : '';
        $titleHint = !empty($item['title']) ? sanitize_text_field($item['title']) : '';

        if (!$numericId && !$slug) {
            wp_send_json_error(['message' => 'Identificador de serie no vÃ¡lido']);
        }

        // 1. Resolve numeric Anikoto ID if missing
        if (!$numericId && $slug) {
            $watchUrl = 'https://anikototv.to/watch/' . $slug;
            $res = wp_remote_get($watchUrl, [
                'timeout' => 10,
                'headers' => ['User-Agent' => 'Mozilla/5.0']
            ]);
            if (!is_wp_error($res) && wp_remote_retrieve_response_code($res) === 200) {
                $html = wp_remote_retrieve_body($res);
                if (preg_match('/data-id=["\'](\d+)["\']/i', $html, $dm)) {
                    $numericId = absint($dm[1]);
                }
            }
        }

        // 2. Query Anikoto Series API
        $seriesData = null;
        if ($numericId) {
            $apiUrl = self::API_SERIES_URL . $numericId;
            $res = wp_remote_get($apiUrl, [
                'timeout' => 12,
                'headers' => ['Accept' => 'application/json', 'User-Agent' => 'Mozilla/5.0 WordPress Anikoto Importer']
            ]);
            if (!is_wp_error($res) && wp_remote_retrieve_response_code($res) === 200) {
                $json = json_decode(wp_remote_retrieve_body($res), true);
                if (!empty($json['ok']) && !empty($json['data'])) {
                    $seriesData = $json['data'];
                }
            }
        }

        if (!$seriesData || empty($seriesData['anime'])) {
            wp_send_json_error(['message' => 'No se encontraron datos en API para ' . ($titleHint ?: $slug)]);
        }

        $anime    = $seriesData['anime'];
        $episodes = !empty($seriesData['episodes']) && is_array($seriesData['episodes']) ? $seriesData['episodes'] : [];

        $title = !empty($anime['title']) ? sanitize_text_field($anime['title']) : ($titleHint ?: $slug);
        $finalSlug = !empty($anime['slug']) ? sanitize_title($anime['slug']) : sanitize_title($title);
        $poster = !empty($anime['poster']) ? esc_url_raw($anime['poster']) : (!empty($item['poster']) ? esc_url_raw($item['poster']) : '');
        $synopsis = !empty($anime['description']) ? wp_kses_post($anime['description']) : '';
        $type = !empty($anime['type']) ? sanitize_text_field($anime['type']) : 'TV';
        $status = !empty($anime['status']) ? sanitize_text_field($anime['status']) : 'Ongoing';
        if ($status === 'Finished Airing') $status = 'Completed';
        elseif ($status === 'Currently Airing') $status = 'Ongoing';
        $totalEps = count($episodes);

        // Strict SEO strip keys
        $seo_keys = [
            '_yoast_wpseo_title', '_yoast_wpseo_metadesc', '_yoast_wpseo_focuskw',
            'rank_math_title', 'rank_math_description', 'rank_math_focus_keyword',
            '_aioseo_title', '_aioseo_description', '_aioseo_keywords'
        ];

        // 3. Find or Create parent Series (CPT: 'anime')
        $existing = get_posts([
            'post_type'      => 'anime',
            'post_status'    => 'any',
            'posts_per_page' => 1,
            'title'          => $title,
        ]);

        if (empty($existing)) {
            $existing = get_posts([
                'post_type'      => 'anime',
                'post_status'    => 'any',
                'posts_per_page' => 1,
                'name'           => $finalSlug,
            ]);
        }

        if (!empty($existing)) {
            $series_id = (int) $existing[0]->ID;
            if ($synopsis && empty($existing[0]->post_content)) {
                wp_update_post(['ID' => $series_id, 'post_content' => $synopsis]);
            }
        } else {
            $series_id = wp_insert_post([
                'post_title'   => $title,
                'post_name'    => $finalSlug,
                'post_content' => $synopsis,
                'post_status'  => 'publish',
                'post_type'    => 'series',
            ]);
        }

        if (!$series_id || is_wp_error($series_id)) {
            wp_send_json_error(['message' => 'Error al crear serie en WordPress']);
        }

        // Auto-create and attach Anime / Series Category
        if (function_exists('dramastream_ensure_series_category')) {
            dramastream_ensure_series_category($title, $series_id);
        }

        // Save series meta
        update_post_meta($series_id, 'ero_type', $type);
        update_post_meta($series_id, 'ero_status', $status);
        update_post_meta($series_id, 'ero_episode', $totalEps);
        update_post_meta($series_id, '_anikoto_series_title', $title);
        update_post_meta($series_id, '_anikoto_slug', $finalSlug);
        if ($numericId) {
            update_post_meta($series_id, '_anikoto_api_id', $numericId);
        }
        if (!empty($anime['duration'])) {
            update_post_meta($series_id, 'ero_durasi', sanitize_text_field($anime['duration']));
        }
        if (!empty($anime['score'])) {
            update_post_meta($series_id, 'ero_skor', sanitize_text_field((string)$anime['score']));
        }
        if (!empty($anime['season'])) {
            $seasonStr = sanitize_text_field($anime['season']) . (!empty($anime['year']) ? ' ' . absint($anime['year']) : '');
            update_post_meta($series_id, 'ero_premiered', $seasonStr);
        }

        // Sideload poster and set Big Cover if not already set
        if ($poster && !has_post_thumbnail($series_id) && function_exists('ak_set_image')) {
            $att = ak_set_image($series_id, $poster, $title);
            if ($att && function_exists('ak_auto_set_big_cover')) {
                ak_auto_set_big_cover($series_id, $att);
            }
        }

        // Sync genres to 'genres' taxonomy
        if (function_exists('ak_sync_imported_genres')) {
            ak_sync_imported_genres($series_id, $anime);
        }

        foreach ($seo_keys as $sk) {
            delete_post_meta($series_id, $sk);
        }

        // 4. Create / Update all Episode posts (CPT: 'post' linked via 'ero_seri')
        $episodesCreated = 0;
        $baseTime = time();

        foreach ($episodes as $idx => $ep) {
            $epNum = absint($ep['number'] ?? ($idx + 1));
            if (!$epNum) continue;

            $epTitle = sprintf('%s Episode %d', $title, $epNum);

            // Check if episode already exists
            $existingEp = get_posts([
                'post_type'      => 'post',
                'post_status'    => 'any',
                'posts_per_page' => 1,
                'meta_query'     => [
                    'relation' => 'AND',
                    [
                        'relation' => 'OR',
                        ['key' => 'ero_seri', 'value' => $series_id, 'compare' => '='],
                        ['key' => '_anikoto_series_id', 'value' => $series_id, 'compare' => '='],
                    ],
                    [
                        'relation' => 'OR',
                        ['key' => 'ero_episodebaru', 'value' => (string)$epNum, 'compare' => '='],
                        ['key' => '_anikoto_episode_number', 'value' => (string)$epNum, 'compare' => '='],
                    ]
                ],
                'fields' => 'ids',
            ]);

            // Embed player format with active VideoJS endpoint
            $embedUrl = '';
            if (!empty($ep['episode_embed_id'])) {
                $eid = preg_replace('/[^0-9A-Za-z_-]/', '', (string)$ep['episode_embed_id']);
                if ($eid !== '') {
                    $embedUrl = 'https://megaplay.buzz/videojs/stream/s-2/' . rawurlencode($eid) . '/sub';
                }
            } elseif (!empty($ep['embed_url']['sub'])) {
                $embedUrl = str_replace('megaplay.buzz/stream/s-2/', 'megaplay.buzz/videojs/stream/s-2/', $ep['embed_url']['sub']);
            } elseif (!empty($ep['embed_url']['dub'])) {
                $embedUrl = str_replace('megaplay.buzz/stream/s-2/', 'megaplay.buzz/videojs/stream/s-2/', $ep['embed_url']['dub']);
            }

            if (!empty($existingEp)) {
                $ep_id = (int) $existingEp[0];
                if ($skipExisting) {
                    // Update embed URL if missing or legacy /stream/s-2/
                    $curr = get_post_meta($ep_id, '_anikoto_iframe_url', true);
                    if (empty($curr) || strpos($curr, 'megaplay.buzz/stream/s-2/') !== false) {
                        if ($embedUrl) {
                            self::set_episode_videojs_player($ep_id, $embedUrl);
                        }
                    }
                    continue;
                }
            } else {
                $epTime = $baseTime - (($totalEps - $epNum) * 3600);
                $epDate = gmdate('Y-m-d H:i:s', $epTime + (get_option('gmt_offset') * 3600));
                $epDateGmt = gmdate('Y-m-d H:i:s', $epTime);

                $ep_id = wp_insert_post([
                    'post_title'    => $epTitle,
                    'post_name'     => sanitize_title($finalSlug . '-episode-' . $epNum),
                    'post_status'   => 'publish',
                    'post_type'     => 'post',
                    'post_date'     => $epDate,
                    'post_date_gmt' => $epDateGmt,
                ]);
            }

            if ($ep_id && !is_wp_error($ep_id)) {
                update_post_meta($ep_id, 'ero_seri', $series_id);
                update_post_meta($ep_id, 'ero_episodebaru', (string)$epNum);
                update_post_meta($ep_id, 'ero_episodetitle', 'Episode ' . $epNum);
                update_post_meta($ep_id, 'ero_subepisode', 'Sub');
                update_post_meta($ep_id, '_anikoto_series_id', $series_id);
                update_post_meta($ep_id, '_anikoto_series_title', $title);
                update_post_meta($ep_id, '_anikoto_episode_number', (string)$epNum);
                update_post_meta($ep_id, '_anikoto_source_url', 'https://anikototv.to/watch/' . $finalSlug . '/ep-' . $epNum);

                // Auto-attach anime category to episode
                if (function_exists('dramastream_ensure_series_category')) {
                    dramastream_ensure_series_category($title, $ep_id);
                }

                if ($embedUrl) {
                    self::set_episode_videojs_player($ep_id, $embedUrl);
                }

                if (has_post_thumbnail($series_id) && !has_post_thumbnail($ep_id)) {
                    set_post_thumbnail($ep_id, get_post_thumbnail_id($series_id));
                }

                foreach ($seo_keys as $sk) {
                    delete_post_meta($ep_id, $sk);
                }
                $episodesCreated++;
            }
        }

        // Update latest pointers on series
        if ($episodes) {
            $lastEp = end($episodes);
            $lastNum = absint($lastEp['number'] ?? count($episodes));
            update_post_meta($series_id, 'ero_latest', (string)$lastNum);
            $lastEpPost = get_posts([
                'post_type'      => 'post',
                'post_status'    => 'publish',
                'posts_per_page' => 1,
                'meta_query'     => [
                    ['key' => 'ero_seri', 'value' => $series_id, 'compare' => '='],
                    ['key' => 'ero_episodebaru', 'value' => (string)$lastNum, 'compare' => '='],
                ],
                'fields' => 'ids',
            ]);
            if (!empty($lastEpPost)) {
                update_post_meta($series_id, 'ero_latestid', (int)$lastEpPost[0]);
            }
        }

        wp_send_json_success([
            'title'            => $title,
            'episodes_created' => $episodesCreated,
            'series_url'       => get_permalink($series_id),
        ]);
    }

    /**
     * Helper to set AnimeStream VideoJS stream embeds
     */
    public static function set_episode_videojs_player($ep_id, $embedUrl) {
        $embedUrl = str_replace('megaplay.buzz/stream/s-2/', 'megaplay.buzz/videojs/stream/s-2/', $embedUrl);
        $group = [
            ['ab_hostname' => 'MegaPlay', 'ab_embed' => $embedUrl]
        ];
        $servers = [
            ['name' => 'MegaPlay', 'type' => 'SUB', 'url' => $embedUrl]
        ];
        update_post_meta($ep_id, 'ab_embedgroup', $group);
        update_post_meta($ep_id, 'ero_embed', [$embedUrl]);
        update_post_meta($ep_id, '_anikoto_servers', wp_json_encode($servers));
        update_post_meta($ep_id, '_anikoto_iframe_url', $embedUrl);
    }

    /**
     * AJAX: Purge demo data
     */
    public function ajax_purge_demo() {
        check_ajax_referer('animestream_full_import_nonce', '_nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'No autorizado']);
        }

        global $wpdb;
        $deleted = $wpdb->query("
            DELETE FROM {$wpdb->posts} 
            WHERE post_type IN ('series', 'post') 
              AND post_name REGEXP '^[0-9a-f]{8}-[0-9a-f]{4}'
        ");

        wp_send_json_success(['message' => "Se eliminaron {$deleted} elementos de prueba."]);
    }
}

new DramaStream_Full_Data_Importer();


// Backwards compatibility alias
if (!class_exists('Animestream_Full_Data_Importer')) {
    class Animestream_Full_Data_Importer extends DramaStream_Full_Data_Importer {}
}