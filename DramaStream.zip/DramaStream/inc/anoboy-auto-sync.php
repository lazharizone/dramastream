<?php
/**
 * anoBoy Module - Deactivated for Turbo Speed
 * Anikoto Auto-Sync is the active engine.
 */

if (!defined('ABSPATH')) {
    exit;
}

class DramaStream_AnoBoy_Sync {
    public function __construct() {
        // Completely inactive stub
    }
}